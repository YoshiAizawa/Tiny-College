insert into School (SchoolId, School_Name) values ('SCHL2018-00001', 'Business and Accounting');
insert into School (SchoolId, School_Name) values ('SCHL2018-00002', 'Nursing');
insert into School (SchoolId, School_Name) values ('SCHL2018-00003', 'Engineering and Architecture');
insert into School (SchoolId, School_Name) values ('SCHL2018-00004', 'Natural Sciences and Mathematics');
insert into School (SchoolId, School_Name) values ('SCHL2018-00005', 'Social Science and Education');