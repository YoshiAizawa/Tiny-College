insert into Building (BuildingId, Building_Name, BuildingNameAcronym, Floors, NumberOfRooms_PerFloor) values ('BLDG2018-00001', 'Tuny', 'TUN', 1, 5);
insert into Building (BuildingId, Building_Name, BuildingNameAcronym, Floors, NumberOfRooms_PerFloor) values ('BLDG2018-00002', 'Mazillius', 'MAZ', 2, 3);
insert into Building (BuildingId, Building_Name, BuildingNameAcronym, Floors, NumberOfRooms_PerFloor) values ('BLDG2018-00003', 'Finster', 'FIN', 7, 13);
insert into Building (BuildingId, Building_Name, BuildingNameAcronym, Floors, NumberOfRooms_PerFloor) values ('BLDG2018-00004', 'Canisius', 'CAN', 5, 6);

