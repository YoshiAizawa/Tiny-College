insert into Chair (ChairId, Chair_StartedDate, Chair_EndedDate, DepartmentId, ProfessorId) values ('PROF-C2019-00001', '02/22/2019', null, 'DEPT2018-00008', 'PROF2018-00078');
insert into Chair (ChairId, Chair_StartedDate, Chair_EndedDate, DepartmentId, ProfessorId) values ('PROF-C2018-00002', '08/04/2018', null, 'DEPT2018-00001', 'PROF2018-00090');
insert into Chair (ChairId, Chair_StartedDate, Chair_EndedDate, DepartmentId, ProfessorId) values ('PROF-C2018-00003', '09/27/2018', null, 'DEPT2018-00015', 'PROF2018-00086');
insert into Chair (ChairId, Chair_StartedDate, Chair_EndedDate, DepartmentId, ProfessorId) values ('PROF-C2019-00004', '08/07/2019', null, 'DEPT2018-00005', 'PROF2018-00028');
insert into Chair (ChairId, Chair_StartedDate, Chair_EndedDate, DepartmentId, ProfessorId) values ('PROF-C2019-00005', '02/24/2019', null, 'DEPT2018-00010', 'PROF2018-00041');
