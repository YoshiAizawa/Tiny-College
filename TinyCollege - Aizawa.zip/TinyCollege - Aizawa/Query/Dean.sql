insert into Dean (DeanId, Dean_StartedDate, Dean_EndedDate, SchoolId, ProfessorId) values ('PROF-D2019-00001', '06/10/2019', null, 'SCHL2018-00001', 'PROF2018-00019');
insert into Dean (DeanId, Dean_StartedDate, Dean_EndedDate, SchoolId, ProfessorId) values ('PROF-D2018-00002', '09/30/2018', null, 'SCHL2018-00002', 'PROF2018-00065');
insert into Dean (DeanId, Dean_StartedDate, Dean_EndedDate, SchoolId, ProfessorId) values ('PROF-D2018-00003', '07/26/2018', null, 'SCHL2018-00003', 'PROF2018-00100');
insert into Dean (DeanId, Dean_StartedDate, Dean_EndedDate, SchoolId, ProfessorId) values ('PROF-D2019-00004', '08/29/2019', null, 'SCHL2018-00004', 'PROF2018-00079');
insert into Dean (DeanId, Dean_StartedDate, Dean_EndedDate, SchoolId, ProfessorId) values ('PROF-D2018-00005', '06/14/2018', null, 'SCHL2018-00005', 'PROF2018-00082');
