﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFClasses.Context;
using NUnit.Framework;

namespace Test
{
    [TestFixture]
    public class AddSchoolTests
    {
        [Test]
        public void AddSchool_WithIdGenerator()
        {
            using var context = new TinyCollegeContext();
            var newSchool = new School
            {
                School_Name = "School of Engineering and Architecture"
            };
            context.Schools.Add(newSchool);
            context.SaveChanges();

            var generatedSchoolId = newSchool.SchoolId;

            Console.WriteLine($"The school has been saved {generatedSchoolId}");
        }
    }
}
