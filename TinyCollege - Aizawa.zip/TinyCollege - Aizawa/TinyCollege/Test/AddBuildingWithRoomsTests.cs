﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using NUnit.Framework;

namespace Test
{
    [TestFixture]
    public class AddBuildingWithRoomsTests
    {
        [Test]
        public void AddBuilding_WithRooms()
        {
            using var context = new TinyCollegeContext();
            var newBuilding = new Building
            {
                Building_Name = "Finster",
                Floors = 3,
                NumberOfRooms_PerFloor = 1
            };

            context.Buildings.Add(newBuilding);
            context.SaveChanges();

            var generatedBuildingId = newBuilding.BuildingId;
            var appendedStringId = (newBuilding.Building_Name.Substring(0, 3)).ToUpper();
            var newRoom = new Room();
            for (var Floor = 1; Floor <= newBuilding.Floors; Floor++)
            {
                for (var RoomNumber = 1; RoomNumber <= newBuilding.NumberOfRooms_PerFloor; RoomNumber++)
                {
                    var roomId = $"{RoomNumber.ToString().PadLeft(3 - RoomNumber.ToString().Length, '0')}";
                    newRoom.Room_Code = $"{appendedStringId}{Floor}{roomId}";
                    newRoom.BuildingId = generatedBuildingId;

                    context.Rooms.Add(newRoom);
                    context.SaveChanges();
                }
            }

            Console.WriteLine($"The {newBuilding.Building_Name} Building has been added, with {newBuilding.Floors * newBuilding.NumberOfRooms_PerFloor} rooms.");
        }
    }
}
