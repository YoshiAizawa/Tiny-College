using System;
using DataLayer.EFClasses.TC;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using NUnit.Framework;

namespace Test
{
    [TestFixture]
    public class AddEmployeeTests
    {
        [Test]
        public void AddEmployee_WithIdGenerator()
        {
            using var context = new TinyCollegeContext();
            // Step 1: Create an instance of a MovieType
            // No need to set the MovieTypeIf since it is auto generated
            var newEmployee = new Employee
            {
                Emp_FirstName = "Cedrick",
                Emp_Lastname = "Sederiosa",
                Emp_MiddleName = "Hoops",
                Emp_ContactNumber = "09999999999",
                Emp_Address = "Universe"
            };

            // Step 2: Attach the instance to the EF context
            // This step will not yet add the instance to the database
            context.Employees.Add(newEmployee);

            // Step 3: Call context.SaveChanges()
            // This will save the object to the database if here is no error
            context.SaveChanges();

            // Optional: if you want to check the generated if of the object
            // Access the id via the Id property
            var generatedEmployeeId = newEmployee.EmployeeId;

            Console.WriteLine($"The employee has been saved {generatedEmployeeId}");
        }
    }
}