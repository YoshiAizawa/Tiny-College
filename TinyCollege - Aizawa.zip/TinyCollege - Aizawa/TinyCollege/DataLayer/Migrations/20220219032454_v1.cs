﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DataLayer.Migrations
{
    public partial class v1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Building",
                columns: table => new
                {
                    BuildingId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Building_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BuildingNameAcronym = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Floors = table.Column<int>(type: "int", nullable: false),
                    NumberOfRooms_PerFloor = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Building", x => x.BuildingId);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    EmployeeId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Emp_FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Emp_Lastname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Emp_MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Emp_Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Emp_ContactNumber = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.EmployeeId);
                });

            migrationBuilder.CreateTable(
                name: "Part",
                columns: table => new
                {
                    PartId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Part_Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Part_Quantity = table.Column<int>(type: "int", nullable: false),
                    Part_Minimum_Quantity = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Part", x => x.PartId);
                });

            migrationBuilder.CreateTable(
                name: "Schedule",
                columns: table => new
                {
                    ScheduleId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    StartTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    EndTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    DayName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Schedule", x => x.ScheduleId);
                });

            migrationBuilder.CreateTable(
                name: "School",
                columns: table => new
                {
                    SchoolId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    School_Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_School", x => x.SchoolId);
                });

            migrationBuilder.CreateTable(
                name: "Vehicle",
                columns: table => new
                {
                    VehicleId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Vehicle_Type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Available_Passenger = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vehicle", x => x.VehicleId);
                });

            migrationBuilder.CreateTable(
                name: "Room",
                columns: table => new
                {
                    Room_Code = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    BuildingId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Room", x => x.Room_Code);
                    table.ForeignKey(
                        name: "FK_Room_Building_BuildingId",
                        column: x => x.BuildingId,
                        principalTable: "Building",
                        principalColumn: "BuildingId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Mechanic",
                columns: table => new
                {
                    MechanicId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EmployeeId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Mec_StartedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    Mec_EndedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Mechanic", x => x.MechanicId);
                    table.ForeignKey(
                        name: "FK_Mechanic_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "EmployeeId");
                });

            migrationBuilder.CreateTable(
                name: "Parts_Manager",
                columns: table => new
                {
                    PartsManagerId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EmployeeId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    PartMgr_StartedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    PartMgr_EndedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Parts_Manager", x => x.PartsManagerId);
                    table.ForeignKey(
                        name: "FK_Parts_Manager_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "EmployeeId");
                });

            migrationBuilder.CreateTable(
                name: "Department",
                columns: table => new
                {
                    DepartmentId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Dept_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Dept_Acronym = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SchoolId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Department", x => x.DepartmentId);
                    table.ForeignKey(
                        name: "FK_Department_School_SchoolId",
                        column: x => x.SchoolId,
                        principalTable: "School",
                        principalColumn: "SchoolId");
                });

            migrationBuilder.CreateTable(
                name: "Maintenance",
                columns: table => new
                {
                    MaintenanceId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    VehicleId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    MechanicId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Maintenance_EntryDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    Maintenance_CompletedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Details = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Maintenance", x => x.MaintenanceId);
                    table.ForeignKey(
                        name: "FK_Maintenance_Mechanic_MechanicId",
                        column: x => x.MechanicId,
                        principalTable: "Mechanic",
                        principalColumn: "MechanicId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Maintenance_Vehicle_VehicleId",
                        column: x => x.VehicleId,
                        principalTable: "Vehicle",
                        principalColumn: "VehicleId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Course",
                columns: table => new
                {
                    CourseId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Course_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DepartmentId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Course", x => x.CourseId);
                    table.ForeignKey(
                        name: "FK_Course_Department_DepartmentId",
                        column: x => x.DepartmentId,
                        principalTable: "Department",
                        principalColumn: "DepartmentId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Professor",
                columns: table => new
                {
                    ProfessorId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Pro_FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pro_LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pro_MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pro_Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pro_ContactNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DepartmentId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Professor", x => x.ProfessorId);
                    table.ForeignKey(
                        name: "FK_Professor_Department_DepartmentId",
                        column: x => x.DepartmentId,
                        principalTable: "Department",
                        principalColumn: "DepartmentId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Part_Used",
                columns: table => new
                {
                    PartUsedId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    PartId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    PartQuantity = table.Column<int>(type: "int", nullable: false),
                    PartsManagerId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    PartUsed_Date = table.Column<DateTime>(type: "datetime", nullable: false),
                    MaintenanceId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Part_Used", x => x.PartUsedId);
                    table.ForeignKey(
                        name: "FK_Part_Used_Maintenance_MaintenanceId",
                        column: x => x.MaintenanceId,
                        principalTable: "Maintenance",
                        principalColumn: "MaintenanceId");
                    table.ForeignKey(
                        name: "FK_Part_Used_Part_PartId",
                        column: x => x.PartId,
                        principalTable: "Part",
                        principalColumn: "PartId");
                    table.ForeignKey(
                        name: "FK_Part_Used_Parts_Manager_PartsManagerId",
                        column: x => x.PartsManagerId,
                        principalTable: "Parts_Manager",
                        principalColumn: "PartsManagerId");
                });

            migrationBuilder.CreateTable(
                name: "Chair",
                columns: table => new
                {
                    ChairId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Chair_StartedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    Chair_EndedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    DepartmentId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProfessorId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Chair", x => x.ChairId);
                    table.ForeignKey(
                        name: "FK_Chair_Department_DepartmentId",
                        column: x => x.DepartmentId,
                        principalTable: "Department",
                        principalColumn: "DepartmentId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Chair_Professor_ProfessorId",
                        column: x => x.ProfessorId,
                        principalTable: "Professor",
                        principalColumn: "ProfessorId");
                });

            migrationBuilder.CreateTable(
                name: "Class",
                columns: table => new
                {
                    ClassId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    CourseId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Room_Code = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ScheduleId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ProfessorId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Class", x => x.ClassId);
                    table.ForeignKey(
                        name: "FK_Class_Course_CourseId",
                        column: x => x.CourseId,
                        principalTable: "Course",
                        principalColumn: "CourseId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Class_Professor_ProfessorId",
                        column: x => x.ProfessorId,
                        principalTable: "Professor",
                        principalColumn: "ProfessorId");
                    table.ForeignKey(
                        name: "FK_Class_Room_Room_Code",
                        column: x => x.Room_Code,
                        principalTable: "Room",
                        principalColumn: "Room_Code",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Class_Schedule_ScheduleId",
                        column: x => x.ScheduleId,
                        principalTable: "Schedule",
                        principalColumn: "ScheduleId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Dean",
                columns: table => new
                {
                    DeanId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Dean_StartedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    Dean_EndedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    SchoolId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ProfessorId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Dean", x => x.DeanId);
                    table.ForeignKey(
                        name: "FK_Dean_Professor_ProfessorId",
                        column: x => x.ProfessorId,
                        principalTable: "Professor",
                        principalColumn: "ProfessorId");
                    table.ForeignKey(
                        name: "FK_Dean_School_SchoolId",
                        column: x => x.SchoolId,
                        principalTable: "School",
                        principalColumn: "SchoolId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Research_Contract",
                columns: table => new
                {
                    ResearchContractId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Contract_StartedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Contract_EndedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Research_Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProfessorId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Research_Contract", x => x.ResearchContractId);
                    table.ForeignKey(
                        name: "FK_Research_Contract_Professor_ProfessorId",
                        column: x => x.ProfessorId,
                        principalTable: "Professor",
                        principalColumn: "ProfessorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Reservation",
                columns: table => new
                {
                    ReservationId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProfessorId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    VehicleId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    EmployeeId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    DepartureDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    Destination = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ArrivalDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    TravelledDistance = table.Column<double>(type: "float", nullable: true),
                    MaintenanceComplaints = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservation", x => x.ReservationId);
                    table.ForeignKey(
                        name: "FK_Reservation_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "EmployeeId");
                    table.ForeignKey(
                        name: "FK_Reservation_Professor_ProfessorId",
                        column: x => x.ProfessorId,
                        principalTable: "Professor",
                        principalColumn: "ProfessorId");
                    table.ForeignKey(
                        name: "FK_Reservation_Vehicle_VehicleId",
                        column: x => x.VehicleId,
                        principalTable: "Vehicle",
                        principalColumn: "VehicleId");
                });

            migrationBuilder.CreateTable(
                name: "Student",
                columns: table => new
                {
                    StudentId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Stu_FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Stu_LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Stu_MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Stu_Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Stu_ContactNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DepartmentId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ProfessorId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Student", x => x.StudentId);
                    table.ForeignKey(
                        name: "FK_Student_Department_DepartmentId",
                        column: x => x.DepartmentId,
                        principalTable: "Department",
                        principalColumn: "DepartmentId");
                    table.ForeignKey(
                        name: "FK_Student_Professor_ProfessorId",
                        column: x => x.ProfessorId,
                        principalTable: "Professor",
                        principalColumn: "ProfessorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Receipt_Fuel",
                columns: table => new
                {
                    ReceiptFuelId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ReservationId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    FuelType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Cost = table.Column<double>(type: "float", nullable: false),
                    Gallons_of_Fuel = table.Column<double>(type: "float", nullable: false),
                    CardNumber = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Receipt_Fuel", x => x.ReceiptFuelId);
                    table.ForeignKey(
                        name: "FK_Receipt_Fuel_Reservation_ReservationId",
                        column: x => x.ReservationId,
                        principalTable: "Reservation",
                        principalColumn: "ReservationId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Enroll",
                columns: table => new
                {
                    EnrollId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    StudentId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ClassId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Enrolled_Date = table.Column<DateTime>(type: "datetime", nullable: false),
                    Semester = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Enroll", x => x.EnrollId);
                    table.ForeignKey(
                        name: "FK_Enroll_Class_ClassId",
                        column: x => x.ClassId,
                        principalTable: "Class",
                        principalColumn: "ClassId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Enroll_Student_StudentId",
                        column: x => x.StudentId,
                        principalTable: "Student",
                        principalColumn: "StudentId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Chair_DepartmentId",
                table: "Chair",
                column: "DepartmentId");

            migrationBuilder.CreateIndex(
                name: "IX_Chair_ProfessorId",
                table: "Chair",
                column: "ProfessorId");

            migrationBuilder.CreateIndex(
                name: "IX_Class_CourseId",
                table: "Class",
                column: "CourseId");

            migrationBuilder.CreateIndex(
                name: "IX_Class_ProfessorId",
                table: "Class",
                column: "ProfessorId");

            migrationBuilder.CreateIndex(
                name: "IX_Class_Room_Code",
                table: "Class",
                column: "Room_Code");

            migrationBuilder.CreateIndex(
                name: "IX_Class_ScheduleId",
                table: "Class",
                column: "ScheduleId");

            migrationBuilder.CreateIndex(
                name: "IX_Course_DepartmentId",
                table: "Course",
                column: "DepartmentId");

            migrationBuilder.CreateIndex(
                name: "IX_Dean_ProfessorId",
                table: "Dean",
                column: "ProfessorId");

            migrationBuilder.CreateIndex(
                name: "IX_Dean_SchoolId",
                table: "Dean",
                column: "SchoolId");

            migrationBuilder.CreateIndex(
                name: "IX_Department_SchoolId",
                table: "Department",
                column: "SchoolId");

            migrationBuilder.CreateIndex(
                name: "IX_Enroll_ClassId",
                table: "Enroll",
                column: "ClassId");

            migrationBuilder.CreateIndex(
                name: "IX_Enroll_StudentId",
                table: "Enroll",
                column: "StudentId");

            migrationBuilder.CreateIndex(
                name: "IX_Maintenance_MechanicId",
                table: "Maintenance",
                column: "MechanicId");

            migrationBuilder.CreateIndex(
                name: "IX_Maintenance_VehicleId",
                table: "Maintenance",
                column: "VehicleId");

            migrationBuilder.CreateIndex(
                name: "IX_Mechanic_EmployeeId",
                table: "Mechanic",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Part_Used_MaintenanceId",
                table: "Part_Used",
                column: "MaintenanceId");

            migrationBuilder.CreateIndex(
                name: "IX_Part_Used_PartId",
                table: "Part_Used",
                column: "PartId");

            migrationBuilder.CreateIndex(
                name: "IX_Part_Used_PartsManagerId",
                table: "Part_Used",
                column: "PartsManagerId");

            migrationBuilder.CreateIndex(
                name: "IX_Parts_Manager_EmployeeId",
                table: "Parts_Manager",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Professor_DepartmentId",
                table: "Professor",
                column: "DepartmentId");

            migrationBuilder.CreateIndex(
                name: "IX_Receipt_Fuel_ReservationId",
                table: "Receipt_Fuel",
                column: "ReservationId");

            migrationBuilder.CreateIndex(
                name: "IX_Research_Contract_ProfessorId",
                table: "Research_Contract",
                column: "ProfessorId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservation_EmployeeId",
                table: "Reservation",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservation_ProfessorId",
                table: "Reservation",
                column: "ProfessorId");

            migrationBuilder.CreateIndex(
                name: "IX_Reservation_VehicleId",
                table: "Reservation",
                column: "VehicleId");

            migrationBuilder.CreateIndex(
                name: "IX_Room_BuildingId",
                table: "Room",
                column: "BuildingId");

            migrationBuilder.CreateIndex(
                name: "IX_Student_DepartmentId",
                table: "Student",
                column: "DepartmentId");

            migrationBuilder.CreateIndex(
                name: "IX_Student_ProfessorId",
                table: "Student",
                column: "ProfessorId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Chair");

            migrationBuilder.DropTable(
                name: "Dean");

            migrationBuilder.DropTable(
                name: "Enroll");

            migrationBuilder.DropTable(
                name: "Part_Used");

            migrationBuilder.DropTable(
                name: "Receipt_Fuel");

            migrationBuilder.DropTable(
                name: "Research_Contract");

            migrationBuilder.DropTable(
                name: "Class");

            migrationBuilder.DropTable(
                name: "Student");

            migrationBuilder.DropTable(
                name: "Maintenance");

            migrationBuilder.DropTable(
                name: "Part");

            migrationBuilder.DropTable(
                name: "Parts_Manager");

            migrationBuilder.DropTable(
                name: "Reservation");

            migrationBuilder.DropTable(
                name: "Course");

            migrationBuilder.DropTable(
                name: "Room");

            migrationBuilder.DropTable(
                name: "Schedule");

            migrationBuilder.DropTable(
                name: "Mechanic");

            migrationBuilder.DropTable(
                name: "Professor");

            migrationBuilder.DropTable(
                name: "Vehicle");

            migrationBuilder.DropTable(
                name: "Building");

            migrationBuilder.DropTable(
                name: "Employee");

            migrationBuilder.DropTable(
                name: "Department");

            migrationBuilder.DropTable(
                name: "School");
        }
    }
}
