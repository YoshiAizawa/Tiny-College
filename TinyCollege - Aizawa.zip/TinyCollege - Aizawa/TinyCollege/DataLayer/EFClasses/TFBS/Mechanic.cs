﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TFBS
{
    public class Mechanic
    {
        public string MechanicId { get; set; }
        public string EmployeeId { get; set; }
        public DateTime Mec_StartedDate { get; set; }
        public DateTime? Mec_EndedDate { get; set; }
        public Employee EmployeeLink { get; set; }
        public ICollection<Maintenance> Maintenances { get; set; }
    }
}
