﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TFBS
{
    public class Receipt_Fuel
    {
        public string ReceiptFuelId { get; set; }
        public string ReservationId { get; set; }
        public Reservation ReservationLink { get; set; }
        public string FuelType { get; set; }
        public double Cost { get; set; }
        public double Gallons_of_Fuel { get; set; }
        public string CardNumber { get; set; }

    }
}
