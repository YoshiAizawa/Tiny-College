﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;

namespace DataLayer.EFClasses.TFBS
{
    public class Reservation
    {
        public string ReservationId { get; set; }
        public string ProfessorId { get; set; }
        public Professor ProfessorLink { get; set; }
        public string VehicleId { get; set; }
        public Vehicle VehicleLink { get; set; }
        public string? EmployeeId { get; set; }
        public Employee EmployeeLink { get; set; }
        public DateTime DepartureDate { get; set; }
        public string Destination { get; set; }
        public DateTime? ArrivalDate { get; set; }
        public double? TravelledDistance { get; set; }
        public string? MaintenanceComplaints { get; set; }
        public ICollection<Receipt_Fuel> ReceiptFuels { get; set; }

    }
}
