﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TFBS
{
    public class Part_Used
    {
        public string PartUsedId { get; set; }
        public string PartId { get; set; }
        public int PartQuantity { get; set; }
        public Part PartLink { get; set; }
        public string PartsManagerId { get; set; }
        public Parts_Manager PartsManagerLink { get; set; }
        public DateTime PartUsed_Date { get; set; }
        public string MaintenanceId { get; set; }
        public Maintenance MaintenanceLink { get; set; }
    }
}
