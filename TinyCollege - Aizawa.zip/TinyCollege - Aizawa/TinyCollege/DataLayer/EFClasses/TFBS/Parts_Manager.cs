﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFClasses.TFBS
{
    public class Parts_Manager
    {
        public string PartsManagerId { get; set; }
        public string EmployeeId { get; set; }
        public DateTime PartMgr_StartedDate { get; set; }
        public DateTime? PartMgr_EndedDate { get; set; }
        public Employee EmployeeLink { get; set; }
        public ICollection<Part_Used> PartUses { get; set; }
    }
}
