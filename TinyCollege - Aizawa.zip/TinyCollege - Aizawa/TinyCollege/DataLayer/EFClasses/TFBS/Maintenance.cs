﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.EFClasses.TFBS
{
    public class Maintenance
    {
        public string MaintenanceId { get; set; }
        public string VehicleId { get; set; }
        public Vehicle VehicleLink { get; set; }
        public string MechanicId { get; set; }
        public Mechanic MechanicLink { get; set; }
        public DateTime Maintenance_EntryDate { get; set; }
        public DateTime? Maintenance_CompletedDate { get; set; }
        public string Details { get; set; }
        public ICollection<Part_Used> PartUses { get; set; }
    }
}
