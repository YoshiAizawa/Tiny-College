﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TFBS
{
    public class Employee
    {
        public string EmployeeId { get; set; }
        public string Emp_FirstName { get; set; }
        public string Emp_Lastname { get; set; }
        public string Emp_MiddleName { get; set; }
        public string Emp_Address { get; set; }
        public string Emp_ContactNumber { get; set; }
        public ICollection<Reservation> Reservations { get; set; }
        public ICollection<Mechanic> Mechanics { get; set; }
        public ICollection<Parts_Manager> PartsManagers { get; set; }
    }
}
