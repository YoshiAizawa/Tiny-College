﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TFBS
{
    public class Vehicle
    {
        public string VehicleId { get; set; }
        public string Vehicle_Type { get; set; }
        public int Available_Passenger { get; set; }
        public ICollection<Reservation> Reservations { get; set; }
        public ICollection<Maintenance> Maintenances { get; set; }
    }
}
