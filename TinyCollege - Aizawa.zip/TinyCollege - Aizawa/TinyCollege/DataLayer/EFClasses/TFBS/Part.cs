﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TFBS
{
    public class Part
    {
        public string PartId { get; set; }
        public string Part_Description { get; set; }
        public int Part_Quantity { get; set; }
        public int Part_Minimum_Quantity { get; set; }
        public ICollection<Part_Used> PartUses { get; set; }
    }
}
