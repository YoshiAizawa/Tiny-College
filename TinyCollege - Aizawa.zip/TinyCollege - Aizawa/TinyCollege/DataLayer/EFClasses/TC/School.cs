﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class School
    {
        public string SchoolId { get; set; }
        public string School_Name { get; set; }
        public ICollection<Department> Departments { get; set; }
        public ICollection<Dean> Deans { get; set; }
    }
}
