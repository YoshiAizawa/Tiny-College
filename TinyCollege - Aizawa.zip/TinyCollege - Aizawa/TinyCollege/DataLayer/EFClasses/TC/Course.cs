﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Course
    {
        public string CourseId { get; set; }
        public string Course_Name { get; set; }
        public Department DepartmentLink { get; set; }
        public string DepartmentId { get; set; }
        public ICollection<Class> Classes { get; set; }
    }
}
