﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Dean
    {
        public string DeanId { get; set; }
        public DateTime Dean_StartedDate { get; set; }
        public DateTime? Dean_EndedDate { get; set; }
        public School SchoolLink { get; set; }
        public string SchoolId { get; set; }
        public Professor ProfessorLink { get; set; }
        public string? ProfessorId { get; set; }
    }
}
