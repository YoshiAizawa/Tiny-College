﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Class
    {
        public string ClassId { get; set; }
        public Course CourseLink { get; set; }
        public string CourseId { get; set; }
        public Room RoomLink { get; set; }
        public string Room_Code { get; set; }
        public Schedule ScheduleLink { get; set; }
        public string ScheduleId { get; set; }
        public Professor ProfessorLink { get; set; }
        public string ProfessorId { get; set; }
        public ICollection<Enroll> Enrolls { get; set; }
    }
}
