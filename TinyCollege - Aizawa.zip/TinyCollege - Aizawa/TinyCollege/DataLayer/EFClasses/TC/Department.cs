﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Department
    {
        public string DepartmentId { get; set; }
        public string Dept_Name { get; set; }
        public string Dept_Acronym { get; set; }
        public School SchoolLink { get; set; }
        public string SchoolId { get; set; }
        public ICollection<Student> Students { get; set; }
        public ICollection<Chair> Chairs { get; set; }
        public ICollection<Course> Courses { get; set; }
        public ICollection<Professor> Professors { get; set; }
    }
}
