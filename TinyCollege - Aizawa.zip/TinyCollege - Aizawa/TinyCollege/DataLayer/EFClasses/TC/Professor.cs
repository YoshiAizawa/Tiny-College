﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;

namespace DataLayer.EFClasses.TC
{
    public class Professor
    {
        public string ProfessorId { get; set; }
        public string Pro_FirstName { get; set; }
        public string Pro_LastName { get; set; }
        public string Pro_MiddleName { get; set; }
        public string Pro_Address { get; set; }
        public string Pro_ContactNumber { get; set; }
        public string DepartmentId { get; set; }
        public Department DepartmentLink { get; set; }
        public ICollection<Student> Students { get; set; }
        public ICollection<Chair> Chairs { get; set; }
        public ICollection<Dean> Deans { get; set; }
        public ICollection<Class> Classes { get; set; }
        public ICollection<Research_Contract> ResearchContracts { get; set; }
        public ICollection<Reservation> Reservations { get; set; }

    }
}
