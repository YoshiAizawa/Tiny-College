﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Room
    {
        public string Room_Code { get; set; }
        public string BuildingId { get; set; }
        public Building BuildingLink { get; set; }
        public ICollection<Class> Classes { get; set; }
    }
}
