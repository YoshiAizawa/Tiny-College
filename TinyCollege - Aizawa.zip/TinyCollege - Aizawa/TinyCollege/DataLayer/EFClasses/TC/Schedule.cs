﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Schedule
    {
        public string ScheduleId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string DayName { get; set; }
        public ICollection<Class> Classes { get; set; }
    }
}
