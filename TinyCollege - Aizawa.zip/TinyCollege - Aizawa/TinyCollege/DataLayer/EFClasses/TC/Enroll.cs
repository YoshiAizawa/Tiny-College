﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Enroll
    {
        public string EnrollId { get; set; }
        public string StudentId { get; set; }
        public Student StudentLink { get; set; }
        public string ClassId { get; set; }
        public Class ClassLink { get; set; }
        public DateTime Enrolled_Date { get; set; }
        public string Semester { get; set; }
    }
}
