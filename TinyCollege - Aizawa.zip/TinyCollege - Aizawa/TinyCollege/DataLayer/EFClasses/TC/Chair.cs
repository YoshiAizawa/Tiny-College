﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Chair
    {
        public string ChairId { get; set; }
        public DateTime Chair_StartedDate { get; set; }
        public DateTime? Chair_EndedDate { get; set; }

        public string DepartmentId { get; set; }
        public Department DepartmentLink { get; set; }

        public string? ProfessorId { get; set; }
        public Professor ProfessorLink { get; set; }
    }
}
