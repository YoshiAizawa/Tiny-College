﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Research_Contract
    {
        public string ResearchContractId { get; set; }
        public DateTime Contract_StartedDate { get; set; }
        public DateTime? Contract_EndedDate { get; set; }
        public string? Research_Description { get; set; }
        public string ProfessorId { get; set; }
        public Professor ProfessorLink { get; set; }
    }
}
