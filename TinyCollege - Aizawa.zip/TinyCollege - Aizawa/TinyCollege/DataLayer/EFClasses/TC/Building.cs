﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Building
    {
        public string BuildingId { get; set; }
        public string Building_Name { get; set; }
        public string BuildingNameAcronym { get; set; }
        public int Floors { get; set; }
        public int NumberOfRooms_PerFloor { get; set; }
        public ICollection<Room> Rooms { get; set; }
    }
}
