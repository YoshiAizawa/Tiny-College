﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.EFClasses.TC
{
    public class Student
    {
        public string StudentId { get; set; }
        public string Stu_FirstName { get; set; }
        public string Stu_LastName { get; set; }
        public string Stu_MiddleName { get; set; }
        public string Stu_Address { get; set; }
        public string Stu_ContactNumber { get; set; }
        public string DepartmentId { get; set; }
        public Department DepartmentLink { get; set; }
        public string? ProfessorId { get; set; }
        public Professor ProfessorLink { get; set; }
        public ICollection<Enroll> Enrolls { get; set; }
    }
}
