﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TC;
using DataLayer.EFCode.TFBS;
using Microsoft.EntityFrameworkCore;

namespace DataLayer.EFClasses.Context
{
    public class TinyCollegeContext : DbContext
    {
        public DbSet<Building> Buildings { get; set; }
        public DbSet<Chair> Chairs { get; set; }
        public DbSet<Class> Classes { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Dean> Deans { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Enroll> Enrolls { get; set; }
        public DbSet<Professor> Professors { get; set; }
        public DbSet<Research_Contract> ResearchContracts { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<Schedule> Schedules { get; set; }
        public DbSet<School> Schools { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Maintenance> Maintenances { get; set; }
        public DbSet<Mechanic> Mechanics { get; set; }
        public DbSet<Part> Parts { get; set; }
        public DbSet<Part_Used> PartUses { get; set; }
        public DbSet<Parts_Manager> PartsManagers { get; set; }
        public DbSet<Receipt_Fuel> ReceiptFuels { get; set; }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<Vehicle> Vehicles { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"server= (localdb)\MSSQLLocalDB; Initial Catalog = TinyCollege; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new BuildingConfig());
            modelBuilder.ApplyConfiguration(new ChairConfig());
            modelBuilder.ApplyConfiguration(new ClassConfig());
            modelBuilder.ApplyConfiguration(new CourseConfig());
            modelBuilder.ApplyConfiguration(new DeanConfig());
            modelBuilder.ApplyConfiguration(new DepartmentConfig());
            modelBuilder.ApplyConfiguration(new EnrollConfig());
            modelBuilder.ApplyConfiguration(new ProfessorConfig());
            modelBuilder.ApplyConfiguration(new Research_ContractConfig());
            modelBuilder.ApplyConfiguration(new RoomConfig());
            modelBuilder.ApplyConfiguration(new ScheduleConfig());
            modelBuilder.ApplyConfiguration(new SchoolConfig());
            modelBuilder.ApplyConfiguration(new StudentConfig());
            modelBuilder.ApplyConfiguration(new EmployeeConfig());
            modelBuilder.ApplyConfiguration(new MaintenanceConfig());
            modelBuilder.ApplyConfiguration(new MechanicConfig());
            modelBuilder.ApplyConfiguration(new Part_UsedConfig());
            modelBuilder.ApplyConfiguration(new PartConfig());
            modelBuilder.ApplyConfiguration(new Parts_ManagerConfig());
            modelBuilder.ApplyConfiguration(new Receipt_FuelConfig());
            modelBuilder.ApplyConfiguration(new ReservationConfig());
            modelBuilder.ApplyConfiguration(new VehicleConfig());

        }
    }
}
