﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class Part_UsedConfig : IEntityTypeConfiguration<Part_Used>
    {
        public void Configure(EntityTypeBuilder<Part_Used> builder)
        {
            builder.ToTable("Part_Used");

            builder.HasKey(c => c.PartUsedId);
            builder.Property(c => c.PartUsedId)
                .HasValueGenerator<Part_UsedIdGenerator>();

            builder.Property(c => c.PartUsed_Date)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.PartQuantity)
                .IsRequired();

            builder.HasOne(c => c.PartLink)
                .WithMany(c => c.PartUses)
                .HasForeignKey(c => c.PartId);

            builder.HasOne(c => c.PartsManagerLink)
                .WithMany(c => c.PartUses)
                .HasForeignKey(c => c.PartsManagerId);

            builder.HasOne(c => c.MaintenanceLink)
                .WithMany(c => c.PartUses)
                .HasForeignKey(c => c.MaintenanceId);
        }
    }
}
