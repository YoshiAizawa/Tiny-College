﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class Parts_ManagerConfig : IEntityTypeConfiguration<Parts_Manager>
    {
        public void Configure(EntityTypeBuilder<Parts_Manager> builder)
        {
            builder.ToTable("Parts_Manager");

            builder.HasKey(c => c.PartsManagerId);
            builder.Property(c => c.PartsManagerId)
                .HasValueGenerator<Parts_ManagerIdGenerator>();

            builder.Property(c => c.PartMgr_StartedDate)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.PartMgr_EndedDate)
                .IsRequired(false)
                .HasColumnType("datetime");

            builder.HasOne(c => c.EmployeeLink)
                .WithMany(c => c.PartsManagers)
                .HasForeignKey(c => c.EmployeeId);
        }
    }
}
