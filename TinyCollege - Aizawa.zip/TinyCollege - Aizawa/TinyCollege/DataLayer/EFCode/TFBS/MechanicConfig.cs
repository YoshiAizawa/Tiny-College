﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class MechanicConfig : IEntityTypeConfiguration<Mechanic>
    {
        public void Configure(EntityTypeBuilder<Mechanic> builder)
        {
            builder.ToTable("Mechanic");

            builder.HasKey(c => c.MechanicId);
            builder.Property(c => c.MechanicId)
                .HasValueGenerator<MechanicIdGenerator>();

            builder.Property(c => c.Mec_StartedDate)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.Mec_EndedDate)
                .IsRequired(false)
                .HasColumnType("datetime");

            builder.HasOne(c => c.EmployeeLink)
                .WithMany(c => c.Mechanics)
                .HasForeignKey(c => c.EmployeeId);

        }
    }
}
