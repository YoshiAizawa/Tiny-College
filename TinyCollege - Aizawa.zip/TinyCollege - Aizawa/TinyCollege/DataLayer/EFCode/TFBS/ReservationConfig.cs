﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class ReservationConfig : IEntityTypeConfiguration<Reservation>
    {
        public void Configure(EntityTypeBuilder<Reservation> builder)
        {
            builder.ToTable("Reservation");

            builder.HasKey(c => c.ReservationId);
            builder.Property(c => c.ReservationId)
                .HasValueGenerator<ReservationIdGenerator>();

            builder.Property(c => c.DepartureDate)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.Destination)
                .IsRequired();

            builder.Property(c => c.ArrivalDate)
                .IsRequired(false)
                .HasColumnType("datetime");

            builder.Property(c => c.TravelledDistance)
                .IsRequired(false);

            builder.Property(c => c.MaintenanceComplaints)
                .IsRequired(false);

            builder.HasOne(c => c.EmployeeLink)
                .WithMany(c => c.Reservations)
                .HasForeignKey(c => c.EmployeeId)
                .IsRequired(false);

            builder.HasOne(c => c.ProfessorLink)
                .WithMany(c => c.Reservations)
                .HasForeignKey(c => c.ProfessorId);

            builder.HasOne(c => c.VehicleLink)
                .WithMany(c => c.Reservations)
                .HasForeignKey(c => c.VehicleId);
        }
    }
}
