﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class EmployeeConfig : IEntityTypeConfiguration<Employee>
    {
        public void Configure(EntityTypeBuilder<Employee> builder)
        {
            builder.ToTable("Employee");

            builder.HasKey(c => c.EmployeeId);
            builder.Property(c => c.EmployeeId)
                .HasValueGenerator<EmployeeIdGenerator>();

            builder.Property(c => c.Emp_FirstName)
                .IsRequired();

            builder.Property(c => c.Emp_Lastname)
                .IsRequired();

            builder.Property(c => c.Emp_MiddleName)
                .IsRequired();

            builder.Property(c => c.Emp_Address)
                .IsRequired();

            builder.Property(c => c.Emp_ContactNumber)
                .IsRequired();

        }
    }
}
