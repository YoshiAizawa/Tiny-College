﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class MaintenanceConfig : IEntityTypeConfiguration<Maintenance>
    {
        public void Configure(EntityTypeBuilder<Maintenance> builder)
        {
            builder.ToTable("Maintenance");

            builder.HasKey(c => c.MaintenanceId);
            builder.Property(c => c.MaintenanceId)
                .HasValueGenerator<MaintenanceIdGenerator>();

            builder.HasOne(c => c.VehicleLink)
                .WithMany(c => c.Maintenances)
                .HasForeignKey(c => c.VehicleId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(c => c.MechanicLink)
                .WithMany(c => c.Maintenances)
                .HasForeignKey(c => c.MechanicId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Property(c => c.Maintenance_EntryDate)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.Maintenance_CompletedDate)
                .IsRequired(false)
                .HasColumnType("datetime");

            builder.Property(c => c.Details)
                .IsRequired();
        }
    }
}
