﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class VehicleConfig : IEntityTypeConfiguration<Vehicle>
    {
        public void Configure(EntityTypeBuilder<Vehicle> builder)
        {
            builder.ToTable("Vehicle");

            builder.HasKey(c => c.VehicleId);
            builder.Property(c => c.VehicleId)
                .HasValueGenerator<VehicleIdGenerator>();

            builder.Property(c => c.Vehicle_Type)
                .IsRequired();

            builder.Property(c => c.Available_Passenger)
                .IsRequired();

        }
    }
}
