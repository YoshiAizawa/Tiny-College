﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class Receipt_FuelConfig : IEntityTypeConfiguration<Receipt_Fuel>
    {
        public void Configure(EntityTypeBuilder<Receipt_Fuel> builder)
        {
            builder.ToTable("Receipt_Fuel");

            builder.HasKey(c => c.ReceiptFuelId);
            builder.Property(c => c.ReceiptFuelId)
                .HasValueGenerator<Receipt_FuelIdGenerator>();

            builder.Property(c => c.FuelType)
                .IsRequired();

            builder.Property(c => c.Gallons_of_Fuel)
                .IsRequired();

            builder.Property(c => c.Cost)
                .IsRequired();

            builder.Property(c => c.CardNumber)
                .IsRequired();

            builder.HasOne(c => c.ReservationLink)
                .WithMany(c => c.ReceiptFuels)
                .HasForeignKey(c => c.ReservationId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
