﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TFBS;
using DataLayer.EFCode.TFBS.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TFBS
{
    public class PartConfig : IEntityTypeConfiguration<Part>
    {
        public void Configure(EntityTypeBuilder<Part> builder)
        {
            builder.ToTable("Part");

            builder.HasKey(c => c.PartId);
            builder.Property(c => c.PartId)
                .HasValueGenerator<PartIdGenerator>();

            builder.Property(c => c.Part_Description)
                .IsRequired();

            builder.Property(c => c.Part_Quantity)
                .IsRequired();

            builder.Property(c => c.Part_Minimum_Quantity)
                .IsRequired();
        }
    }
}
