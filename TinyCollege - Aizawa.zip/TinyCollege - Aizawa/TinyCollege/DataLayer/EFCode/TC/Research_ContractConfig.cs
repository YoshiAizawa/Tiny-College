﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class Research_ContractConfig : IEntityTypeConfiguration<Research_Contract>
    {
        public void Configure(EntityTypeBuilder<Research_Contract> builder)
        {
            builder.ToTable("Research_Contract");

            builder.HasKey(c => c.ResearchContractId);
            builder.Property(c => c.ResearchContractId)
                .HasValueGenerator<Research_ContractIdGenerator>();

            builder.Property(c => c.Contract_StartedDate)
                .IsRequired();

            builder.Property(c => c.Contract_EndedDate)
                .IsRequired(false);

            builder.Property(c => c.Research_Description)
                .IsRequired();

            builder.HasOne(c => c.ProfessorLink)
                .WithMany(c => c.ResearchContracts)
                .HasForeignKey(c => c.ProfessorId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
