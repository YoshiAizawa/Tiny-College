﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class BuildingConfig :IEntityTypeConfiguration<Building>
    {
        public void Configure(EntityTypeBuilder<Building> builder)
        {
            builder.ToTable("Building");

            builder.HasKey(c => c.BuildingId);
            builder.Property(c => c.BuildingId)
                .HasValueGenerator<BuildingIdGenerator>();

            builder.Property(c => c.Building_Name)
                .IsRequired();

            builder.Property(c => c.BuildingNameAcronym)
                .IsRequired();

            builder.Property(c => c.Floors)
                .IsRequired();

            builder.Property(c => c.NumberOfRooms_PerFloor)
                .IsRequired();
        }
    }
}
