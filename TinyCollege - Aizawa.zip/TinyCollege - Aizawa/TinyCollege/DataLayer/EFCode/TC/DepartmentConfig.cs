﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class DepartmentConfig :IEntityTypeConfiguration<Department>
    {
        public void Configure(EntityTypeBuilder<Department> builder)
        {
            builder.ToTable("Department");

            builder.HasKey(c => c.DepartmentId);
            builder.Property(c => c.DepartmentId)
                .HasValueGenerator<DepartmentIdGenerator>();

            builder.Property(c => c.Dept_Name)
                .IsRequired();

            builder.Property(c => c.Dept_Acronym)
                .IsRequired();

            builder.HasOne(c => c.SchoolLink)
                .WithMany(c => c.Departments)
                .HasForeignKey(c => c.SchoolId);
        }
    }
}
