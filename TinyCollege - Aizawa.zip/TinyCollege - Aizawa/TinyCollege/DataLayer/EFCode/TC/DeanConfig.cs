﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class DeanConfig : IEntityTypeConfiguration<Dean>
    {
        public void Configure(EntityTypeBuilder<Dean> builder)
        {
            builder.ToTable("Dean");

            builder.HasKey(c => c.DeanId);
            builder.Property(c => c.DeanId)
                .HasValueGenerator<DeanIdGenerator>();

            builder.Property(c => c.Dean_StartedDate)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.Dean_EndedDate)
                .IsRequired(false)
                .HasColumnType("datetime");

            builder.HasOne(c => c.ProfessorLink)
                .WithMany(c => c.Deans)
                .HasForeignKey(c => c.ProfessorId)
                .IsRequired(false);

            builder.HasOne(c => c.SchoolLink)
                .WithMany(c => c.Deans)
                .HasForeignKey(c => c.SchoolId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}
