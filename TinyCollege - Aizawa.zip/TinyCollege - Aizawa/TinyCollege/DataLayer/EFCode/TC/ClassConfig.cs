﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class ClassConfig : IEntityTypeConfiguration<Class>
    {
        public void Configure(EntityTypeBuilder<Class> builder)
        {
            builder.ToTable("Class");
            
            builder.HasKey(c => c.ClassId);
            builder.Property(c => c.ClassId)
                .HasValueGenerator<ClassIdGenerator>();

            builder.HasOne(c => c.CourseLink)
                .WithMany(c => c.Classes)
                .HasForeignKey(c => c.CourseId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(c => c.RoomLink)
                .WithMany(c => c.Classes)
                .HasForeignKey(c => c.Room_Code)
                .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(c => c.ScheduleLink)
                .WithMany(c => c.Classes)
                .HasForeignKey(c => c.ScheduleId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(c => c.ProfessorLink)
                .WithMany(c => c.Classes)
                .HasForeignKey(c => c.ProfessorId);
        }
    }
}
