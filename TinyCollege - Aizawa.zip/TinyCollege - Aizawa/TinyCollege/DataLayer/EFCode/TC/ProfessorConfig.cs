﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class ProfessorConfig :IEntityTypeConfiguration<Professor>
    {
        public void Configure(EntityTypeBuilder<Professor> builder)
        {
            builder.ToTable("Professor");

            builder.HasKey(c => c.ProfessorId);
            builder.Property(c => c.ProfessorId)
                .HasValueGenerator<ProfessorIdGenerator>();

            builder.Property(c => c.Pro_FirstName)
                .IsRequired();

            builder.Property(c => c.Pro_LastName)
                .IsRequired();

            builder.Property(c => c.Pro_MiddleName)
                .IsRequired();

            builder.Property(c => c.Pro_Address)
                .IsRequired();

            builder.Property(c => c.Pro_ContactNumber)
                .IsRequired();

            builder.HasOne(c => c.DepartmentLink)
                .WithMany(c => c.Professors)
                .HasForeignKey(c => c.DepartmentId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}
