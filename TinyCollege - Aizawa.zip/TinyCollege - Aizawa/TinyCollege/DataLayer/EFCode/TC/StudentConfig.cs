﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class StudentConfig : IEntityTypeConfiguration<Student>
    {
        public void Configure(EntityTypeBuilder<Student> builder)
        {
            builder.ToTable("Student");

            builder.HasKey(c => c.StudentId);
            builder.Property(c => c.StudentId)
                .HasValueGenerator<StudentIdGenerator>();

            builder.Property(c => c.Stu_FirstName)
                .IsRequired();

            builder.Property(c => c.Stu_LastName)
                .IsRequired();

            builder.Property(c => c.Stu_MiddleName)
                .IsRequired();

            builder.Property(c => c.Stu_Address)
                .IsRequired();

            builder.Property(c => c.Stu_ContactNumber)
                .IsRequired();

            builder.HasOne(c => c.DepartmentLink)
                .WithMany(c => c.Students)
                .HasForeignKey(c => c.DepartmentId);

            builder.HasOne(c => c.ProfessorLink)
                .WithMany(c => c.Students)
                .HasForeignKey(c => c.ProfessorId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
