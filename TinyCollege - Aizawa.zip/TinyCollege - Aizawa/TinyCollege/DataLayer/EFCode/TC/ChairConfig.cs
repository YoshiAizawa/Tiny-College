﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class ChairConfig : IEntityTypeConfiguration<Chair>
    {
        public void Configure(EntityTypeBuilder<Chair> builder)
        {
            builder.ToTable("Chair");

            builder.HasKey(c=>c.ChairId);
            builder.Property((c => c.ChairId))
                .HasValueGenerator<ChairIdGenerator>();

            builder.Property(c => c.Chair_StartedDate)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.Chair_EndedDate)
                .IsRequired(false)
                .HasColumnType("datetime");

            builder.HasOne(c => c.ProfessorLink)
                .WithMany(c => c.Chairs)
                .HasForeignKey(c => c.ProfessorId)
                .IsRequired(false);

            builder.HasOne(c => c.DepartmentLink)
                .WithMany(c => c.Chairs)
                .HasForeignKey(c => c.DepartmentId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
