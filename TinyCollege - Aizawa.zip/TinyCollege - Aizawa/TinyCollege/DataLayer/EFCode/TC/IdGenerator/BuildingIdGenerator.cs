﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.ValueGeneration;

namespace DataLayer.EFCode.TC.IdGenerator
{
    public class BuildingIdGenerator : ValueGenerator
    {
        public override bool GeneratesTemporaryValues => false;

        protected override object NextValue(EntityEntry entry)
        {
            using var context = new TinyCollegeContext();

            var sb = new StringBuilder();

            var idNumSequence = (context.Buildings.Count() + 1).ToString();

            sb.Append($"BLDG{DateTime.Now.Year}-");
            sb.Append($"{idNumSequence.PadLeft(5, '0')}");

            return sb.ToString();
        }
    }
}
