﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class ScheduleConfig : IEntityTypeConfiguration<Schedule>
    {
        public void Configure(EntityTypeBuilder<Schedule> builder)
        {
            builder.ToTable("Schedule");

            builder.HasKey(c => c.ScheduleId);
            builder.Property(c => c.ScheduleId)
                .HasValueGenerator<ScheduleIdGenerator>();

            builder.Property(c => c.DayName)
                .IsRequired();

            builder.Property(c => c.StartTime)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.EndTime)
                .IsRequired()
                .HasColumnType("datetime");
        }
    }
}
