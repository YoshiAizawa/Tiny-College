﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class EnrollConfig : IEntityTypeConfiguration<Enroll>
    {
        public void Configure(EntityTypeBuilder<Enroll> builder)
        {
            builder.ToTable("Enroll");

            builder.HasKey(c => c.EnrollId);
            builder.Property(c => c.EnrollId)
                .HasValueGenerator<EnrollIdGenerator>();

            builder.Property(c => c.Enrolled_Date)
                .IsRequired()
                .HasColumnType("datetime");

            builder.Property(c => c.Semester)
                .IsRequired();

            builder.HasOne(c => c.StudentLink)
                .WithMany(c => c.Enrolls)
                .HasForeignKey(c => c.StudentId);

            builder.HasOne(c => c.ClassLink)
                .WithMany(c => c.Enrolls)
                .HasForeignKey(c => c.ClassId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
