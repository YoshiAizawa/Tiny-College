﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class RoomConfig : IEntityTypeConfiguration<Room>
    {
        public void Configure(EntityTypeBuilder<Room> builder)
        {
            builder.ToTable("Room");

            builder.HasKey(c => c.Room_Code);
            builder.Property(c => c.Room_Code);

            builder.HasOne(c => c.BuildingLink)
                .WithMany(c => c.Rooms)
                .HasForeignKey(c => c.BuildingId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
