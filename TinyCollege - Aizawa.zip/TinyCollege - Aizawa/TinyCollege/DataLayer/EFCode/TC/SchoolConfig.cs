﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.TC;
using DataLayer.EFCode.TC.IdGenerator;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DataLayer.EFCode.TC
{
    public class SchoolConfig : IEntityTypeConfiguration<School>
    {
        public void Configure(EntityTypeBuilder<School> builder)
        {
            builder.ToTable("School");

            builder.HasKey(c => c.SchoolId);
            builder.Property(c => c.SchoolId)
                .HasValueGenerator<SchoolIdGenerator>();

            builder.Property(c => c.School_Name)
                .IsRequired();
        }
    }
}
