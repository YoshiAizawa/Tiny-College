﻿using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServiceLayer.TC
{
    public class ChairService
    {
        private readonly TinyCollegeContext _context;

        public ChairService(TinyCollegeContext context)
        {
            _context = context;
        }

        public IQueryable<Chair> GetChairs()
        {
            return _context.Chairs;
        }

        public IQueryable<Chair> GetDepartmentChairs(string departmentId)
        {
            return _context.Chairs.Where(c => c.DepartmentId == departmentId && c.Chair_EndedDate==null)
                .Include(c => c.DepartmentLink)
                .Include(c => c.ProfessorLink);
        }

        public void AddChair(Chair chair)
        {
            _context.Chairs.Add(chair);
            _context.SaveChanges();
        }

        public void UpdateChair(Chair chair)
        {
            var editChair = _context.Chairs.Find(chair.ChairId);
            editChair.Chair_EndedDate = DateTime.Now;
            _context.SaveChanges();
        }
    }
}
