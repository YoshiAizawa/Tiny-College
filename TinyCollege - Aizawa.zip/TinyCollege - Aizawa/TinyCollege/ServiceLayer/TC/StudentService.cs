﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class StudentService
    {
        private readonly TinyCollegeContext _context;

        public StudentService(TinyCollegeContext context) => _context = context;

        public IQueryable<Student> GetStudents()
        {
            return _context.Students
                .Include(c => c.DepartmentLink)
                .Include(c => c.ProfessorLink);
        }

        public void AddStudent(Student student)
        {
            _context.Students.Add(student);
            _context.SaveChanges();
        }

        public void UpdateStudents(Student student)
        {
            var editProfessor = _context.Students.Find(student.StudentId);
            editProfessor.Stu_FirstName = student.Stu_FirstName;
            editProfessor.Stu_LastName = student.Stu_LastName;
            editProfessor.Stu_MiddleName = student.Stu_MiddleName;
            editProfessor.Stu_Address = student.Stu_Address;
            editProfessor.Stu_ContactNumber = student.Stu_ContactNumber;
            editProfessor.DepartmentId = student.DepartmentId;
            editProfessor.ProfessorId = student.ProfessorId;

            _context.SaveChanges();
        }
    }
}
