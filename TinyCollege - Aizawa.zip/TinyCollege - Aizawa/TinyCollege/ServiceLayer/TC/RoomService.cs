﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class RoomService
    {
        private readonly TinyCollegeContext _context;

        public RoomService(TinyCollegeContext context)
        {
            _context = context;
        }

        public IQueryable<Room> GetRooms()
        {
            return _context.Rooms;
        }

        public IQueryable<Room> GetScheduleRooms(string scheduleId)
        {
            return _context.Rooms
                .Include(c => c.Classes.Where(c => c.ScheduleId != scheduleId));
        }


        public IQueryable<Room> GetBuildingRooms(string buildingId)
        {
            return _context.Rooms.Where(c => c.BuildingId == buildingId)
                .Include(c => c.BuildingLink)
                .Include(c => c.Classes);
        }

        public void AddRoom(Room room)
        {
            _context.Rooms.Add(room);
            _context.SaveChanges();
        }

        public void UpdateBuilding(string roomCode, string buildingId)
        {
            var room = _context.Rooms.Find(roomCode);
            room.BuildingId = buildingId;
            _context.SaveChanges();
        }
    }
}
