﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class ScheduleService
    {
        private readonly TinyCollegeContext _context;

        public ScheduleService(TinyCollegeContext context) => _context = context;

        public IQueryable<Schedule> GetSchedules()
        {
            return _context.Schedules;
        }


        public void AddSchedule(Schedule schedule)
        {
            _context.Schedules.Add(schedule);
            _context.SaveChanges();
        }

        public void UpdateSchedules(Schedule schedule)
        {
            var editSchedule = _context.Schedules.Find(schedule.ScheduleId);
            editSchedule.StartTime = schedule.StartTime;
            editSchedule.EndTime = schedule.EndTime;
            editSchedule.DayName = schedule.DayName;
            _context.SaveChanges();
        }
    }
}
