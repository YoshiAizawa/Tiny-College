﻿using DataLayer.EFClasses.Context;
using System.Linq;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;
using System;

namespace ServiceLayer.TC
{
    public class EnrollService
    {
        private readonly TinyCollegeContext _context;

        public EnrollService(TinyCollegeContext context) => _context = context;

        public IQueryable<Enroll> GetEnrolls()
        {
            return _context.Enrolls;
        }

        public IQueryable<Enroll> GetStudentEnroll(string studentId)
        {
            return _context.Enrolls.Where(c => c.StudentId == studentId)
                .Include(c => c.ClassLink.ProfessorLink)
                .Include(c => c.StudentLink)
                .Include(c => c.ClassLink.ScheduleLink)
                .Include(c => c.ClassLink.CourseLink)
                .Include(c => c.ClassLink);
        }

        public void AddEnroll(Enroll enroll)
        {
            var EnrollsOfStudent = _context.Enrolls.Where(c => c.StudentId == enroll.StudentId);

            if (EnrollsOfStudent.Count() > 6)
            {
                throw new Exception("The Classes of student is already at maximum.");
            }
            else
            {
                _context.Enrolls.Add(enroll);
                _context.SaveChanges();
            }
        }

        public void UpdateStudents(Student student)
        {
            var editProfessor = _context.Students.Find(student.StudentId);
            editProfessor.Stu_FirstName = student.Stu_FirstName;
            editProfessor.Stu_LastName = student.Stu_LastName;
            editProfessor.Stu_MiddleName = student.Stu_MiddleName;
            editProfessor.Stu_Address = student.Stu_Address;
            editProfessor.Stu_ContactNumber = student.Stu_ContactNumber;
            editProfessor.DepartmentId = student.DepartmentId;
            editProfessor.ProfessorId = student.ProfessorId;

            _context.SaveChanges();
        }

    }
}
