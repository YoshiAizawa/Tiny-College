﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class ProfessorService
    {
        private readonly TinyCollegeContext _context;

        public ProfessorService(TinyCollegeContext context) => _context = context;

        public IQueryable<Professor> GetProfessors()
        {
            return _context.Professors
                .Include(c => c.DepartmentLink)
                .Include(c => c.Chairs)
                .Include(c => c.Deans)
                .Include(c => c.ResearchContracts);
        }

        public IQueryable<Professor> GetCourseProfessors(string departmentId)
        {
            return _context.Professors
                .Where(c => c.DepartmentId == departmentId)
                .Where(c => c.Classes.Count() < 4)
                .Include(c => c.DepartmentLink);
        }

        public IQueryable<Professor> GetDepartmentProfessors(string departmentId)
        {
            return _context.Professors
                .Where(c => c.DepartmentId == departmentId)
                .Include(c => c.DepartmentLink);
        }

        public void AddProfessor(Professor professor, bool isAdvisor, bool isReseacrher, string? researchDescription)
        {
            
            _context.Professors.Add(professor);
            _context.SaveChanges();

            if (isReseacrher)
            {
                var newResearcher = new Research_Contract
                {
                    ProfessorId = professor.ProfessorId,
                    Research_Description = researchDescription,
                    Contract_StartedDate = DateTime.Now
                };
                _context.ResearchContracts.Add(newResearcher);
                _context.SaveChanges();
            }
        }

        public void UpdateProfessor(Professor professor, bool isAdvisor, bool isReseacrher, string? researchDescription, bool deptChange)
        {
            var editProfessor = _context.Professors.Find(professor.ProfessorId);
            editProfessor.Pro_FirstName = professor.Pro_FirstName;
            editProfessor.Pro_LastName = professor.Pro_LastName;
            editProfessor.Pro_MiddleName = professor.Pro_MiddleName;
            editProfessor.Pro_Address = professor.Pro_Address;
            editProfessor.Pro_ContactNumber = professor.Pro_ContactNumber;
            editProfessor.DepartmentId = professor.DepartmentId;
            _context.SaveChanges();

            var chairs = _context.Chairs.Where(c => c.ProfessorId == professor.ProfessorId && c.Chair_EndedDate == null);
            if (chairs.Count() != 0)
            {
                if (deptChange)
                {
                    foreach (var chair in chairs)
                    {
                        chair.Chair_EndedDate = DateTime.Now;
                    }
                }
            }

            var deans = _context.Deans.Where(c => c.ProfessorId == professor.ProfessorId && c.Dean_EndedDate == null);
            if (deans.Count() != 0)
            {
                if (deptChange)
                {
                    foreach (var dean in deans)
                    {
                        dean.Dean_EndedDate = DateTime.Now;
                    }
                }
            }

            var researchers = _context.ResearchContracts.Where(c => c.ProfessorId == professor.ProfessorId && c.Contract_EndedDate == null);
            if (researchers.Count() == 0)//not existing
            {
                if (isReseacrher)
                {
                    var newResearcher = new Research_Contract
                    {
                        ProfessorId = professor.ProfessorId,
                        Contract_StartedDate = DateTime.Now,
                        Research_Description = researchDescription,
                    };
                    _context.ResearchContracts.Add(newResearcher);
                }
            }
            else // exist
            {
                foreach (var researcher in researchers)
                {
                    if (researcher.Contract_EndedDate == null)
                    {
                        if (!isReseacrher)
                        {
                            researcher.Contract_EndedDate = DateTime.Now;
                        }
                    }
                }
            }

            _context.SaveChanges();
        }
    }
}
