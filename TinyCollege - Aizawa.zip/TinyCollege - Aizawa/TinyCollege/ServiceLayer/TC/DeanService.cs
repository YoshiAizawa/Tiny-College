﻿using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServiceLayer.TC
{
    public class DeanService
    {
        private readonly TinyCollegeContext _context;

        public DeanService(TinyCollegeContext context)
        {
            _context = context;
        }

        public IQueryable<Dean> GetDeans()
        {
            return _context.Deans;
        }

        public IQueryable<Dean> GetSchoolDeans(string schoolId)
        {
            return _context.Deans.Where(c => c.SchoolId == schoolId)
                .Include(c => c.SchoolLink)
                .ThenInclude(c=>c.Departments)
                .Include(c => c.ProfessorLink);
        }

        public void AddDean(Dean dean)
        {
            var oldDeans = _context.Deans.Where(c => c.SchoolId == dean.SchoolId);
            foreach (var oldDean in oldDeans)
            {
                if (oldDean.Dean_EndedDate == null)
                    oldDean.Dean_EndedDate = DateTime.Now;
            }

            _context.Deans.Add(dean);
            _context.SaveChanges();
        }

        public void UpdateDean(Dean dean)
        {
            var editDean = _context.Deans.Find(dean.DeanId);
            editDean.Dean_EndedDate = DateTime.Now;
            _context.SaveChanges();
        }
    }
}
