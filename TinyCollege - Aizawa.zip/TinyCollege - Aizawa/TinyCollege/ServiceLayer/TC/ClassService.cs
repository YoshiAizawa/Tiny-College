﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class ClassService
    {
        private readonly TinyCollegeContext _context;

        public ClassService(TinyCollegeContext context) => _context = context;

        public IQueryable<Class> GetClasses()
        {
            return _context.Classes
                .Include(c => c.Enrolls)
                .Include(c => c.ProfessorLink)
                .Include(c => c.CourseLink)
                .Include(c => c.ScheduleLink);
        }

        public IQueryable<Class> GetScheduleClasses(string scheduleId)
        {
            return _context.Classes.Where(c => c.ScheduleId == scheduleId)
                .Include(c => c.Enrolls)
                .Include(c => c.RoomLink)
                .Include(c => c.ProfessorLink)
                .Include(c => c.CourseLink);
        }

        public IQueryable<Class> GetCourseClasses(string courseId)
        {
            return _context.Classes.Where(c => c.CourseId == courseId)
                .Include(c => c.RoomLink)
                .Include(c => c.ScheduleLink)
                .Include(c => c.ProfessorLink)
                .Include(c => c.CourseLink);
        }

        public IQueryable<Class> GetProfessorClasses(string professorId)
        {
            return _context.Classes.Where(c => c.ProfessorId == professorId)
                .Include(c => c.ScheduleLink)
                .Include(c => c.CourseLink);
        }

        public void AddClass(Class oneClass)
        {
            //var hasSameRoom;
            //var hasSameSched;

            //var checkClassRoom = _context.Classes.Where(c=>c.Room_Code == oneClass.Room_Code)

            var checkClass = _context.Classes.Where(c => c.ScheduleId == oneClass.ScheduleId && c.Room_Code == oneClass.Room_Code);

            if (checkClass.Count() == 0)
            {
                _context.Classes.Add(oneClass);
                _context.SaveChanges();
            }
            else throw new Exception(message: "Selected Schedule and Room is already Reserved.");
        }

        public void UpdateClasses(Class oneClass)
        {
            var checkClass = _context.Classes.Where(c => c.ScheduleId == oneClass.ScheduleId && c.Room_Code == oneClass.Room_Code);

            if (checkClass.Count() == 0)
            {
                var editClass = _context.Classes.Find(oneClass.ClassId);
                editClass.Room_Code = oneClass.Room_Code;
                editClass.CourseId = oneClass.CourseId;
                editClass.ProfessorId = oneClass.ProfessorId;
                editClass.ScheduleId = oneClass.ScheduleId;
                _context.SaveChanges();
            }
            else throw new Exception(message: "Selected Schedule and Room is already Reserved.");
        }
    }
}
