﻿using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class BuildingService
    {
        private readonly TinyCollegeContext _context;

        public BuildingService(TinyCollegeContext context)
        {
            _context = context;
        }

        public IQueryable<Building> GetBuildings()
        {
            return _context.Buildings
                .Include(c => c.Rooms);
        }

        public void AddBuilding(Building building)
        {
            _context.Buildings.Add(building);
            _context.SaveChanges();

            var generatedBuildingId = building.BuildingId;
            var newRoom = new Room();
            for (var Floor = 1; Floor <= building.Floors; Floor++)
            {
                for (var RoomNumber = 1; RoomNumber <= building.NumberOfRooms_PerFloor; RoomNumber++)
                {
                    var roomId = $"{RoomNumber.ToString().PadLeft(2, '0')}";
                    newRoom.Room_Code = $"{building.BuildingNameAcronym.ToUpper()}{Floor}{roomId}";
                    newRoom.BuildingId = generatedBuildingId;
                    _context.Rooms.Add(newRoom);
                    _context.SaveChanges();
                }
            }
            
        }

        public void UpdateBuilding(Building building)
        {
            var editBuilding = _context.Buildings.Find(building.BuildingId);
            editBuilding.Building_Name = building.Building_Name;
            editBuilding.BuildingNameAcronym = building.BuildingNameAcronym;
            editBuilding.Floors = building.Floors;
            editBuilding.NumberOfRooms_PerFloor = building.NumberOfRooms_PerFloor;

            var rooms = _context.Rooms.Where(c => c.BuildingId == building.BuildingId);
            foreach (var room in rooms)
            {
                _context.Rooms.Remove(room);
            }
            _context.SaveChanges();


            var generatedBuildingId = building.BuildingId;
            var newRoom = new Room();
            for (var Floor = 1; Floor <= building.Floors; Floor++)
            {
                for (var RoomNumber = 1; RoomNumber <= building.NumberOfRooms_PerFloor; RoomNumber++)
                {
                    var roomId = $"{RoomNumber.ToString().PadLeft(2, '0')}";
                    newRoom.Room_Code = $"{building.BuildingNameAcronym.ToUpper()}{Floor}{roomId}";
                    newRoom.BuildingId = generatedBuildingId;

                    _context.Rooms.Add(newRoom);
                    _context.SaveChanges();
                }
            }

            

            //var firstThreeLetter = editBuilding.Building_Name.Substring(0, 3);

            //var editRooms = _context.Rooms
            //    .Where(c => c.BuildingId == editBuilding.BuildingId);
            //foreach (var room in editRooms)
            //{
            //    var sb = new StringBuilder();
            //    sb.Append(firstThreeLetter);

            //    sb.Append(room.Room_Code.Remove(0, 3));

            //    room.Room_Code = sb.ToString();
            //}

            //_context.SaveChanges();
        }
    }
}
