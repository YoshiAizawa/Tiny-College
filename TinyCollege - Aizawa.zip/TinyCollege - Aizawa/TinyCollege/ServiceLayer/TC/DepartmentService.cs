﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class DepartmentService
    {
        private readonly TinyCollegeContext _context;

        public DepartmentService(TinyCollegeContext context) => _context = context;

        public IQueryable<Department> GetDepartments()
        {
            return _context.Departments
                .Include(c => c.SchoolLink)
                .Include(c => c.Courses)
                .Include(c => c.Chairs)
                .Include(c => c.Professors);
        }

        public IQueryable<Department> GetSchoolDepartments(string schoolId)
        {
            return _context.Departments.Where(c => c.SchoolId == schoolId)
                .Include(c => c.SchoolLink)
                .ThenInclude(c => c.Deans)
                .Include(c => c.Chairs);
        }

        public void AddDepartment(Department department)
        {
            _context.Departments.Add(department);
            _context.SaveChanges();
        }

        public void UpdateDepartments(Department department)
        {
            var editDepartment = _context.Departments.Find(department.DepartmentId);
            editDepartment.Dept_Name = department.Dept_Name;
            editDepartment.Dept_Acronym = department.Dept_Acronym;
            editDepartment.SchoolId = department.SchoolId;
            _context.SaveChanges();
        }
    }
}
