﻿using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using System;
using System.Collections.Generic;
using System.Text;

namespace ServiceLayer.TC
{
    public class ResearchService
    {
        private readonly TinyCollegeContext _context;

        public ResearchService(TinyCollegeContext context) => _context = context;

        public void AddResearch(Research_Contract research)
        {
            _context.ResearchContracts.Add(research);
            _context.SaveChanges();
        }

        public void UpdateResearch(Research_Contract research)
        {
            var editResearch = _context.ResearchContracts.Find(research.ResearchContractId);
            editResearch.Contract_StartedDate = research.Contract_StartedDate;
            editResearch.Contract_EndedDate = research.Contract_EndedDate;
            editResearch.Research_Description = research.Research_Description;
            editResearch.ProfessorId = research.ProfessorId;
        }
    }
}
