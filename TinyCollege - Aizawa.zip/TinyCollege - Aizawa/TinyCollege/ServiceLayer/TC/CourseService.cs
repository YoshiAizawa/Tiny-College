﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class CourseService
    {
        private readonly TinyCollegeContext _context;

        public CourseService(TinyCollegeContext context) => _context = context;

        public IQueryable<Course> GetCourses()
        {
            return _context.Courses
                .Include(c => c.DepartmentLink)
                .Include(c => c.Classes);
        }

        public IQueryable<Course> GetDepartmentCourses(string departmentId)
        {
            return _context.Courses.Where(c => c.DepartmentId == departmentId)
                .Include(c => c.Classes);
        }

        public void AddCourse(Course course)
        {
            var courses = _context.Courses.Where(c => c.DepartmentId == course.DepartmentId);
            var codeNumberSequence = courses.Count() + 1;

            var department = _context.Departments.Find(course.DepartmentId);

            course.CourseId = $"{department.Dept_Acronym}-{codeNumberSequence.ToString().PadLeft(2, '0')}";

            _context.Courses.Add(course);
            _context.SaveChanges();
        }

        public void UpdateCourses(Course course)
        {
                var editCourse = _context.Courses.Find(course.CourseId);
                editCourse.DepartmentId = course.DepartmentId;
                editCourse.Course_Name = course.Course_Name;
                _context.SaveChanges();
            
        }
    }
}
