﻿using DataLayer.EFClasses.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.TC;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TC
{
    public class SchoolService
    {
        private readonly TinyCollegeContext _context;

        public SchoolService(TinyCollegeContext context) => _context = context;

        public IQueryable<School> GetSchool()
        {
            return _context.Schools
                .Include(c => c.Departments)
                .Include(c => c.Deans);
        }

        public void AddSchool(School school)
        {
            _context.Schools.Add(school);
            _context.SaveChanges();
        }

        public void UpdateSchools(School school)
        {
            var editSchool = _context.Schools.Find(school.SchoolId);
            editSchool.School_Name = school.School_Name;

            _context.SaveChanges();
        }
    }
}
