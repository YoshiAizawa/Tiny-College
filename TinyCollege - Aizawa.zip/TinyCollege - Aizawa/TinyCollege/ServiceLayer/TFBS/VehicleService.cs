﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;

namespace ServiceLayer.TFBS
{
    public class VehicleService
    {
        private readonly TinyCollegeContext _context;

        public VehicleService(TinyCollegeContext context) => _context = context;

        public IQueryable<Vehicle> GetVehicles()
        {
            return _context.Vehicles;
        }

        public void AddVehicle(Vehicle vehicle)
        {
            _context.Vehicles.Add(vehicle);
            _context.SaveChanges();
        }

        public void UpdateVehicle(Vehicle vehicle)
        {
            var editVehicle = _context.Vehicles.Find(vehicle.VehicleId);
            editVehicle.Available_Passenger = vehicle.Available_Passenger;
            editVehicle.Vehicle_Type = vehicle.Vehicle_Type;

            _context.SaveChanges();
        }
    }
}
