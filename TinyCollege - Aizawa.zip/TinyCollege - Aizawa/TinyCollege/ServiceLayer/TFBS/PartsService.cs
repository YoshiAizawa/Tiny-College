﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TFBS
{
    public class PartsService
    {
        private readonly TinyCollegeContext _context;

        public PartsService(TinyCollegeContext context) => _context = context;

        public IQueryable<Part> GetParts()
        {
            return _context.Parts
                .Include(c => c.PartUses);
        }

        public IQueryable<Part> GetSummaryParts(string partUsedId)
        {
            return _context.Parts
                .Include(c => c.PartUses);
        }

        public void AddPart(Part part)
        {
            _context.Parts.Add(part);
            _context.SaveChanges();
        }

        public void UpdateParts(Part part)
        {
            var editPart = _context.Parts.Find(part.PartId);
            editPart.Part_Minimum_Quantity = part.Part_Minimum_Quantity;
            editPart.Part_Description = part.Part_Description;
            editPart.Part_Quantity = part.Part_Quantity;

            _context.SaveChanges();
        }
    }
}
