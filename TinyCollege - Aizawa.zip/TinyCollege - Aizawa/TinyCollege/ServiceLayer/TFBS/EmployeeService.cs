﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;

namespace ServiceLayer.TFBS
{
    public class EmployeeService
    {
        private readonly TinyCollegeContext _context;

        public EmployeeService(TinyCollegeContext context) => _context = context;

        public IQueryable<Employee> GetEmployees()
        {
            return _context.Employees
                .Include(c => c.Mechanics)
                .Include(c => c.PartsManagers);
        }

        public void AddEmployee(Employee employee, bool isMechanic, bool isPartsManager)
        {
            _context.Employees.Add(employee);
            _context.SaveChanges();

            if (isMechanic)
            {
                var newMechanic = new Mechanic
                {
                    EmployeeId = employee.EmployeeId,
                    Mec_StartedDate = DateTime.Now
                };
                _context.Mechanics.Add(newMechanic);
                _context.SaveChanges();
            }

            if (isPartsManager)
            {
                var newPartsManager = new Parts_Manager
                {
                    EmployeeId = employee.EmployeeId,
                    PartMgr_StartedDate = DateTime.Now
                };
                _context.PartsManagers.Add(newPartsManager);
                _context.SaveChanges();
            }
        }

        public void UpdateEmployees(Employee employee, bool isMechanic, bool isPartsManager)
        {
            var editEmployee = _context.Employees.Find(employee.EmployeeId);
            editEmployee.Emp_FirstName = employee.Emp_FirstName;
            editEmployee.Emp_Lastname = employee.Emp_Lastname;
            editEmployee.Emp_MiddleName = employee.Emp_MiddleName;
            editEmployee.Emp_Address = employee.Emp_Address;
            editEmployee.Emp_ContactNumber = employee.Emp_ContactNumber;
            _context.SaveChanges();

            var mechanics =
                _context.Mechanics.Where(c => c.EmployeeId == employee.EmployeeId && c.Mec_EndedDate == null).ToList();
            if (!mechanics.Any()) //Not mechanic
            {
                if (isMechanic)
                {
                    var newMechanic = new Mechanic
                    {
                        EmployeeId = employee.EmployeeId,
                        Mec_StartedDate = DateTime.Now
                    };
                    _context.Mechanics.Add(newMechanic);
                    _context.SaveChanges();
                }
            }
            else // it exist
            {
                foreach (var mechanic in mechanics)
                {
                    if (mechanic.Mec_EndedDate == null)
                    {
                        if (!isMechanic)
                        {
                            mechanic.Mec_EndedDate = DateTime.Now;
                        }

                    }
                }
            }

            var partManagers =
                _context.PartsManagers.Where(c => c.EmployeeId == employee.EmployeeId && c.PartMgr_EndedDate == null).ToList();
            if (!partManagers.Any()) //Not mechanic
            {
                if (isPartsManager)
                {
                    var newPartsManager = new Parts_Manager()
                    {
                        EmployeeId = employee.EmployeeId,
                        PartMgr_StartedDate = DateTime.Now
                    };
                    _context.PartsManagers.Add(newPartsManager);
                }
            }
            else // it exist
            {
                foreach (var partManager in partManagers)
                {
                    if (partManager.PartMgr_EndedDate == null)
                    {
                        if (!isPartsManager)
                        {
                            partManager.PartMgr_EndedDate = DateTime.Now;
                            
                        }
                    }
                }
            }
            _context.SaveChanges();
        }
    }
}
