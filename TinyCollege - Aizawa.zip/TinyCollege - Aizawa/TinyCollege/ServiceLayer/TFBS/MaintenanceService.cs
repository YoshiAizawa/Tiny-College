﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TFBS
{
    public class MaintenanceService
    {
        private readonly TinyCollegeContext _context;

        public MaintenanceService(TinyCollegeContext context) => _context = context;

        public IQueryable<Maintenance> GetMaintenances()
        {
            return _context.Maintenances
                .Include(c => c.PartUses)
                .Include(c => c.VehicleLink)
                .ThenInclude(c=>c.Reservations)
                .Include(c => c.MechanicLink)
                .ThenInclude(c=>c.EmployeeLink);
        }

        public void AddMaintenance(Maintenance maintenance)
        {
            _context.Maintenances.Add(maintenance);
            _context.SaveChanges();
        }

        public void UpdateMaintenance(Maintenance maintenance)
        {

            var editMaintenances = _context.Maintenances.Find(maintenance.MaintenanceId);
            editMaintenances.Maintenance_EntryDate = maintenance.Maintenance_EntryDate;
            editMaintenances.Details = maintenance.Details;
            editMaintenances.VehicleId = maintenance.VehicleId;
            editMaintenances.MechanicId = maintenance.MechanicId;

            _context.SaveChanges();
        }

        public void AddCompleteMaintenance(Maintenance maintenance)
        {
            var completeMaintenance = _context.Maintenances.Find(maintenance.MaintenanceId);

            completeMaintenance.Maintenance_CompletedDate = maintenance.Maintenance_CompletedDate;

            _context.SaveChanges();
        }
    }
}
