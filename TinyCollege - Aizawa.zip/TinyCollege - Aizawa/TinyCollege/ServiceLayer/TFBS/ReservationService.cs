﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TC;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TFBS
{
    public class ReservationService
    {
        private readonly TinyCollegeContext _context;

        public ReservationService(TinyCollegeContext context) => _context = context;

        public IQueryable<Reservation> GetReservations()
        {
            return _context.Reservations
                .Include(c => c.VehicleLink)
                .Include(c => c.ProfessorLink)
                .Include(c => c.EmployeeLink);
        }

        public IQueryable<Reservation> GetVehicleReservations(string vehicleId)
        {
            return _context.Reservations.Where(c => c.VehicleId == vehicleId)
                .Include(c => c.ProfessorLink)
                .Include(c => c.EmployeeLink)
                .Include(c=>c.ReceiptFuels);
        }

        public IQueryable<Professor> GetProfessorReservations(string professorId)
        {
            return _context.Professors.Where(c => c.ProfessorId == professorId)
                .Include(c => c.Reservations);
        }

        public void AddReservation(Reservation reservation)
        {
            _context.Reservations.Add(reservation);
            _context.SaveChanges();
        }

        public void AddReceipt(Receipt_Fuel receipt)
        {
            _context.ReceiptFuels.Add(receipt);
            _context.SaveChanges();
        }

        public void UpdateReservations(Reservation reservation)
        {
            var editReservation = _context.Reservations.Find(reservation.ReservationId);
            editReservation.Destination = reservation.Destination;
            editReservation.DepartureDate = reservation.DepartureDate;
            editReservation.ArrivalDate = reservation.ArrivalDate;
            editReservation.TravelledDistance = reservation.TravelledDistance;
            editReservation.MaintenanceComplaints = reservation.MaintenanceComplaints;

            editReservation.VehicleId = reservation.VehicleId;
            editReservation.ProfessorId = reservation.ProfessorId;
            _context.SaveChanges();
        }

        public void AddCompleteReservation(Reservation completeReservation)
        {
            var reservation = _context.Reservations.Find(completeReservation.ReservationId);

            reservation.ArrivalDate = completeReservation.ArrivalDate;
            reservation.TravelledDistance = completeReservation.TravelledDistance;
            reservation.MaintenanceComplaints = completeReservation.MaintenanceComplaints;
            reservation.EmployeeId = completeReservation.EmployeeId;

            _context.SaveChanges();
        }
    }
}
