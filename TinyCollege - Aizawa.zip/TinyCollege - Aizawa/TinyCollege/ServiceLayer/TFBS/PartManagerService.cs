﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TFBS
{
    public class PartManagerService
    {
        private readonly TinyCollegeContext _context;

        public PartManagerService(TinyCollegeContext context) => _context = context;

        public IQueryable<Parts_Manager> GetPartManagers()
        {
            return _context.PartsManagers
                .Include(c => c.EmployeeLink)
                .Include(c => c.PartUses);
        }
    }
}
