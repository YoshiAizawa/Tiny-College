﻿using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServiceLayer.TFBS
{
    public class ReceiptService
    {
        private readonly TinyCollegeContext _context;

        public ReceiptService(TinyCollegeContext context) => _context = context;

        public IQueryable<Receipt_Fuel> GetReceipts()
        {
            return _context.ReceiptFuels
                .Include(c => c.ReservationLink);
        }

        public IQueryable<Receipt_Fuel> GetReservationReceipts(string reservationId)
        {
            return _context.ReceiptFuels.Where(c => c.ReservationLink.ReservationId == reservationId);
        }

        public void AddReceipt(Receipt_Fuel receipt)
        {
            _context.ReceiptFuels.Add(receipt);
            _context.SaveChanges();
        }

        public void UpdateReceipts(Receipt_Fuel receipt)
        {
            var editReceipt = _context.ReceiptFuels.Find(receipt.ReceiptFuelId);
            editReceipt.FuelType = receipt.FuelType;
            editReceipt.Cost = receipt.Cost;
            editReceipt.Gallons_of_Fuel = receipt.Gallons_of_Fuel;
            editReceipt.CardNumber = receipt.CardNumber;

            _context.SaveChanges();
        }
    }
}
