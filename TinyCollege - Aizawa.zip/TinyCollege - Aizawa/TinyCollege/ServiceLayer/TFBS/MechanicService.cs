﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;

namespace ServiceLayer.TFBS
{
    public class MechanicService
    {
        private readonly TinyCollegeContext _context;

        public MechanicService(TinyCollegeContext context) => _context = context;

        public IQueryable<Mechanic> GetMechanics()
        {
            return _context.Mechanics
                .Include(c => c.Maintenances)
                .Include(c => c.EmployeeLink);
        }
    }
}
