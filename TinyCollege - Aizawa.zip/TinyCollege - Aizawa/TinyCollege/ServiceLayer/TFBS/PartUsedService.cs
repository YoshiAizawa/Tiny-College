﻿using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServiceLayer.TFBS
{
    public class PartUsedService
    {
        private readonly TinyCollegeContext _context;

        public PartUsedService(TinyCollegeContext context) => _context = context;

        public IQueryable<Part_Used> GetPartUsed()
        {
            return _context.PartUses;
        }

        public IQueryable<Part_Used> GetPartsUsed(string partId)
        {
            return _context.PartUses.Where(c=>c.PartId == partId)
                .Include(c => c.PartLink)
                .Include(c => c.MaintenanceLink)
                .Include(c => c.PartsManagerLink)
                .ThenInclude(c=>c.EmployeeLink);
        }

        public IQueryable<Part_Used> GetMaintenancePartUsed(string maintenanceId)
        {
            return _context.PartUses.Where(c => c.MaintenanceId == maintenanceId)
                .Include(c => c.PartLink)
                .Include(c => c.MaintenanceLink)
                .Include(c => c.PartsManagerLink)
                .ThenInclude(c => c.EmployeeLink);
        }

        public void AddPartUsed(Part_Used PartUsed)
        {
            _context.PartUses.Add(PartUsed);
            _context.SaveChanges();
        }

        public void UpdatePartUsed(Part_Used PartUsed)
        {
            var editPartUsed = _context.PartUses.Find(PartUsed.PartUsedId);

            editPartUsed.PartUsedId = PartUsed.PartUsedId;
            editPartUsed.PartsManagerId = PartUsed.PartUsedId;
            editPartUsed.PartQuantity = PartUsed.PartQuantity;
            editPartUsed.MaintenanceId = PartUsed.MaintenanceId;
            editPartUsed.PartId = PartUsed.PartId;

            _context.SaveChanges();
        }
    }
}
