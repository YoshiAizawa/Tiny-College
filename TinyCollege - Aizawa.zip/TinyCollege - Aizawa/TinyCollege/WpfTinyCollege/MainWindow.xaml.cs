﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
namespace WpfTinyCollege
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private const int GWL_STYLE = -16;
        private const int WS_SYSMENU = 0x80000;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        public MainWindow()
        {
            InitializeComponent();
            HomeViewInterface.Visibility = Visibility.Visible;

        }

        private void Tiny_College_Loaded(object sender, RoutedEventArgs e)
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) & ~WS_SYSMENU);
        }
        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void CollapseInterface()
        {
            HomeViewInterface.Visibility = Visibility.Collapsed;
            SchoolViewInterface.Visibility = Visibility.Collapsed;
            CourseViewInterface.Visibility = Visibility.Collapsed;
            ClassViewInterface.Visibility = Visibility.Collapsed;
            ProfessorViewInterface.Visibility = Visibility.Collapsed;
            ScheduleViewInterface.Visibility = Visibility.Collapsed;
            SchoolViewInterface.Visibility = Visibility.Collapsed;
            BuildingViewInterface.Visibility = Visibility.Collapsed;
            StudentViewInterface.Visibility = Visibility.Collapsed;
            EmployeeViewInterface.Visibility = Visibility.Collapsed;
            MaintenanceViewInterface.Visibility = Visibility.Collapsed;
            PartsViewInterface.Visibility = Visibility.Collapsed;
            ReservationViewInterface.Visibility = Visibility.Collapsed;
            SummaryViewInterface.Visibility = Visibility.Collapsed;
            VehicleViewInterface.Visibility = Visibility.Collapsed;
            DepartmentInterface.Visibility = Visibility.Collapsed;
        }

        private void TrvItemSchool_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (SchoolViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                SchoolViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemCourse_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (CourseViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                CourseViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemClass_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (ClassViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                ClassViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemStudent_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (StudentViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                StudentViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemProfessor_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (ProfessorViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                ProfessorViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemSchedule_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (ScheduleViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                ScheduleViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemBuilding_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (BuildingViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                BuildingViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemSummary_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (SummaryViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                SummaryViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemEmployee_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (EmployeeViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                EmployeeViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemReservation_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (ReservationViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                ReservationViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemMaintenance_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (MaintenanceViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                MaintenanceViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemParts_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (PartsViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                PartsViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemVehicle_OnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (VehicleViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                VehicleViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            if (HomeViewInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                HomeViewInterface.Visibility = Visibility.Visible;
            }
        }

        private void TrvItemDepartment_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (DepartmentInterface.Visibility != Visibility.Visible)
            {
                CollapseInterface();
                DepartmentInterface.Visibility = Visibility.Visible;
            }
        }

    }
}