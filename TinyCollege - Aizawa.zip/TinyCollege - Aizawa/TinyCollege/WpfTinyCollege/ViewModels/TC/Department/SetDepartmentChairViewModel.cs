﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Department
{
    public class SetDepartmentChairViewModel
    {
        private readonly ChairService _chairService;

        public SetDepartmentChairViewModel(DepartmentViewModel selectedDepartment)
        {
            _chairService = new ChairService(new TinyCollegeContext());
            DepartmentId = selectedDepartment.DepartmentId;
            DepartmentName = selectedDepartment.DepartmentName;
            ChairFullName = selectedDepartment.ChairFullName;
            DisplayDepartmentProfessors(selectedDepartment.DepartmentId);
        }
        //Show Professor of Selected Department
        private void DisplayDepartmentProfessors(string departmentId)
        {
            DepartmentProfessorsList.Clear();

            var professors = new ProfessorService(new TinyCollegeContext()).GetDepartmentProfessors(departmentId)
                .Select(c => new DepartmentProfessorsViewModel(c));

            foreach (var department in professors)
                DepartmentProfessorsList.Add(department);
        }
        public ObservableCollection<DepartmentProfessorsViewModel> DepartmentProfessorsList { get; set; } =
            new ObservableCollection<DepartmentProfessorsViewModel>();

        public DepartmentProfessorsViewModel SelectedProfessor { get; set; }
        public string ChairId { get; set; }
        public string DepartmentId { get; set; }
        public string DepartmentName { get; set; }
        public string ProfessorId { get; set; }
        public string ChairFullName { get; set; }
        public ObservableCollection<DepartmentViewModel> DepartmentList { get; set; }

        public void Set()
        {
            var newChair = new DataLayer.EFClasses.TC.Chair
            {
                DepartmentId = DepartmentId,
                ProfessorId = SelectedProfessor.ProfessorId,
                Chair_StartedDate = DateTime.Now,
            };

            _chairService.AddChair(newChair);
        }
    }
}
