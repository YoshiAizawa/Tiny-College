﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Department
{
    public class RemoveDepartmentChairViewModel
    {
        private ChairService _chairService;

        public RemoveDepartmentChairViewModel(DepartmentViewModel selectedDepartment)
        {
            _chairService = new ChairService(new TinyCollegeContext());

            var Chairs = new TinyCollegeContext().Chairs.Where(c => c.DepartmentId == selectedDepartment.DepartmentId);

            foreach (var Chair in Chairs)
            {
                if (Chair.Chair_EndedDate == null)
                {
                    ChairId = Chair.ChairId;
                }
            }
        }
        public string ChairId { get; set; }
        public string ProfessorId { get; set; }
        public DateTime ChairStartDate { get; set; }
        public string DepartmentId { get; set; }

        public void Remove()
        {
            var removeChair = new DataLayer.EFClasses.TC.Chair
            {
                ChairId = ChairId,
                DepartmentId = DepartmentId,
                ProfessorId = ProfessorId,
                Chair_StartedDate = ChairStartDate,
            };

            _chairService.UpdateChair(removeChair);
        }
    }
}
