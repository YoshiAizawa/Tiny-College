﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TC.Department
{
    public class DepartmentViewModel : INotifyPropertyChanged
    {
        private string _departmentId;
        private string _departmentName;
        private string _departmentAcronym;
        private string _schoolId;

        public string DepartmentId
        {
            get => _departmentId;
            internal set
            {
                _departmentId = value;
                OnPropertyChanged(nameof(DepartmentId));
            }
        }

        public string DepartmentAcronym
        {
            get => _departmentAcronym;
            internal set
            {
                _departmentAcronym = value;
                OnPropertyChanged(nameof(DepartmentAcronym));
            }
        }

        public string DepartmentName
        {
            get => _departmentName;
            internal set
            {
                _departmentName = value;
                OnPropertyChanged(nameof(DepartmentName));
            }
        }

        public string SchoolId
        {
            get => _schoolId;
            internal set
            {
                _schoolId = value;
                OnPropertyChanged(nameof(SchoolId));
            }
        }

        public int? NumberOfCourses { get; set; }
        public string SchoolName { get; set; }
        public string ChairFullName { get; set; }
        public double? TravelledDistance { get; set; }

        public DepartmentViewModel(DataLayer.EFClasses.TC.Department department)
        {
            DepartmentId = department.DepartmentId;
            DepartmentName = department.Dept_Name;
            DepartmentAcronym = department.Dept_Acronym;
            SchoolId = department.Dept_Acronym;
            if(department.SchoolLink != null)
                SchoolName = department.SchoolLink.School_Name;

            if (department.Courses == null)
            {
                NumberOfCourses = 0;
            }
            else NumberOfCourses = department.Courses.Count();

            using var _context = new TinyCollegeContext();

            
            if (department.Chairs == null) ChairFullName = null;
            else
            {
                var chairs = _context.Chairs.Where(c => c.DepartmentId == department.DepartmentId)
                    .Include(c => c.ProfessorLink);

                foreach (var chair in chairs)
                {
                    if (chair.Chair_EndedDate == null)
                    {
                        ChairFullName = $"{chair.ProfessorLink.Pro_LastName}, {chair.ProfessorLink.Pro_FirstName} " +
                            $"{chair.ProfessorLink.Pro_MiddleName[..1].ToUpper()}.";
                    }
                }
            }

            var completes = _context.Reservations
                .Include(c => c.ProfessorLink).Where(c => c.ProfessorLink.DepartmentId == department.DepartmentId);

                foreach (var complete in completes)
                {
                    TravelledDistance += complete.TravelledDistance;
                }

        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
