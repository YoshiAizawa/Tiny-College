﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Department;

namespace WpfTinyCollege.ViewModels.TC.School
{
    public class EditDepartmentViewModel
    {
        private readonly DepartmentService _departmentService;
        private readonly SchoolService _schoolService;

        public EditDepartmentViewModel(DepartmentViewModel departmentToEdit, DepartmentService departmentService, SchoolService schoolService)
        {
            DepartmentToEdit = departmentToEdit;
            _departmentService = departmentService;
            _schoolService = schoolService;
            SchoolList = new ObservableCollection<SchoolViewModel>(
                _schoolService.GetSchool().Select(c =>
                new SchoolViewModel(c))
            );

            DepartmentId = DepartmentToEdit.DepartmentId;
            CopyEditableFields(DepartmentToEdit);
        }
        public DepartmentViewModel DepartmentToEdit { get; set; }
        private void CopyEditableFields(DepartmentViewModel DepartmentToEdit)
        {
            DepartmentId = DepartmentToEdit.DepartmentId;
            DepartmentName = DepartmentToEdit.DepartmentName;
            DepartmentNameAcronym = DepartmentToEdit.DepartmentAcronym;
            SchoolId = DepartmentToEdit.SchoolId;
            //var Schools = new TinyCollegeContext().Schools.Where(c => c.SchoolId == DepartmentToEdit.SchoolId);
            //foreach (var School in Schools)
            //{
            //    SchoolName = School.Dept_Name;
            //}
        }
        public string DepartmentId { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentNameAcronym { get; set; }
        public string SchoolId { get; set; }
        public ObservableCollection<SchoolViewModel> SchoolList { get; set; }
        public SchoolViewModel SelectedSchool { get; set; }

        public void Edit(bool schoolChange)
        {
            DepartmentToEdit.DepartmentId = DepartmentId;
            DepartmentToEdit.DepartmentName = DepartmentName;
            DepartmentToEdit.DepartmentAcronym = DepartmentNameAcronym;
            if (schoolChange)
            {
                DepartmentToEdit.SchoolId = SelectedSchool.SchoolId;
            }
            else
            {
                DepartmentToEdit.SchoolId = SchoolId;
            }

            var newDepartment = new DataLayer.EFClasses.TC.Department
            {
                DepartmentId = DepartmentToEdit.DepartmentId,
                Dept_Name = DepartmentToEdit.DepartmentName,
                Dept_Acronym = DepartmentToEdit.DepartmentAcronym,
                SchoolId = DepartmentToEdit.SchoolId,
            };

            _departmentService.UpdateDepartments(newDepartment);
        }
    }
}
