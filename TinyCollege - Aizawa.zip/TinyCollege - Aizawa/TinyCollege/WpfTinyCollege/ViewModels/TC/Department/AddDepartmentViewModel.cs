﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.School;

namespace WpfTinyCollege.ViewModels.TC.Department
{
    public class AddDepartmentViewModel
    {
        private readonly DepartmentService _departmentService;
        private readonly SchoolService _schoolService;

        public AddDepartmentViewModel(DepartmentService departmentService, SchoolService schoolService)
        {
            _departmentService = departmentService;
            _schoolService = schoolService;
            SchoolList = new ObservableCollection<SchoolViewModel>(
                _schoolService.GetSchool().Select(c =>
                new SchoolViewModel(c))
            );
        }

        public string DepartmentName { get; set; }
        public string DepartmentNameAcronym { get; set; }
        public string SchoolId { get; set; }
        public ObservableCollection<SchoolViewModel> SchoolList { get; set; }
        public SchoolViewModel SelectedSchool { get; set; }
        public DepartmentViewModel AssociatedDepartment { get; set; }

        public void Add()
        {
            var department = new DataLayer.EFClasses.TC.Department()
            {
                Dept_Name = DepartmentName,
                Dept_Acronym = DepartmentNameAcronym.ToUpper(),
                SchoolId = SelectedSchool.SchoolId,
            };

            _departmentService.AddDepartment(department);

            AssociatedDepartment = new DepartmentViewModel(department);
        }
    }
}
