﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Department
{
    public class DepartmentCoursesViewModel
    {
        public string CourseId { get; set; }
        public string CourseName { get; set; }
        public int NumberOfClasses { get; set; }

        public DepartmentCoursesViewModel(DataLayer.EFClasses.TC.Course course)
        {
            CourseId = course.CourseId;
            CourseName = course.Course_Name;
            NumberOfClasses = course.Classes.Count();
        }
    }
}
