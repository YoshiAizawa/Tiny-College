﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Department
{
    public class DepartmentListViewModel
    {
        private readonly DepartmentService _departmentService;
        private DepartmentViewModel _selectedDepartment;

        public DepartmentListViewModel(DepartmentService departmentService)
        {
            _departmentService = departmentService;

            DepartmentList = new ObservableCollection<DepartmentViewModel>(
                _departmentService.GetDepartments().Select(c =>
                new DepartmentViewModel(c))
            );
        }

        public ObservableCollection<DepartmentViewModel> DepartmentList { get; set; }

        public ObservableCollection<DepartmentCoursesViewModel> DepartmentCoursesList { get; set; } =
            new ObservableCollection<DepartmentCoursesViewModel>();

        public DepartmentViewModel SelectedDepartment
        {
            get => _selectedDepartment;
            set
            {
                _selectedDepartment = value;
                if (_selectedDepartment != null)
                    DisplayDepartmentCourses(_selectedDepartment.DepartmentId);
            }
        }

        //Display
        private void DisplayDepartmentCourses(string departmentId)
        {
            DepartmentCoursesList.Clear();

            var courses = new CourseService(new TinyCollegeContext()).GetDepartmentCourses(departmentId)
                .Select(c => new DepartmentCoursesViewModel(c));

            foreach (var course in courses)
                DepartmentCoursesList.Add(course);
        }

        private string _searchText;

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchDepartment(_searchText);
            }
        }

        public void SearchDepartment(string searchString)
        {
            DepartmentList.Clear();

            var Courses = _departmentService.GetDepartments()
                .Where(c => c.Dept_Name.Contains(searchString) ||
                c.Dept_Acronym.Contains(searchString) ||
                c.DepartmentId.Contains(searchString));

            foreach (var course in Courses)
            {
                var CourseModel = new DepartmentViewModel(course);

                DepartmentList.Add(CourseModel);
            }
        }
    }
}
