﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Department
{
    public class DepartmentProfessorsViewModel
    {
        public string ProfessorFullName { get; set; }
        public string ProfessorId { get; set; }

        public DepartmentProfessorsViewModel(DataLayer.EFClasses.TC.Professor professor)
        {
            ProfessorId = professor.ProfessorId;
            ProfessorFullName = $"{professor.Pro_LastName}, {professor.Pro_FirstName} " +
                            $"{professor.Pro_MiddleName.Substring(0, 1).ToUpper()}.";
        }
    }
}
