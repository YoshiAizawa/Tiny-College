﻿using Hangfire.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Professor.Dean
{
    public class DeanViewModel
    {
        private string _deanId;
        private string _professorId;
        private string _schoolId;


        public string DeanId
        {
            get => _deanId;
            internal set
            {
                _deanId = value;
                OnPropertyChanged(nameof(DeanId));
            }
        }

        public string ProfessorId
        {
            get => _professorId;
            internal set
            {
                _professorId = value;
                OnPropertyChanged(nameof(ProfessorId));
            }
        }

        public string Schoolid
        {
            get => _schoolId;
            internal set
            {
                _schoolId = value;
                OnPropertyChanged(nameof(Schoolid));
            }
        }

        public string ProfessorFullName { get; set; }

        public DeanViewModel(DataLayer.EFClasses.TC.Dean dean)
        {
            DeanId = dean.DeanId;
            ProfessorId = dean.DeanId;
            Schoolid = dean.SchoolId;
            ProfessorFullName = $"{dean.ProfessorLink.Pro_LastName}, {dean.ProfessorLink.Pro_FirstName} " +
                $"{dean.ProfessorLink.Pro_MiddleName.Substring(0, 1)}.";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
