﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TC.Professor
{
    public class ProfessorViewModel : INotifyPropertyChanged
    {
        private string _professorId;
        private string _professorFirstName;
        private string _professorLastName;
        private string _professorMiddleName;
        private string _professorAddress;
        private string _professorContactNumber;

        private string _professorFullName;
        private string _professorDean;
        private string _professorChair;
        private string _professorAdvisor;
        private string _professorResearch;
        private string _nameOfDepartment;

        public string ProfessorId
        {
            get => _professorId;
            internal set
            {
                _professorId = value;
                OnPropertyChanged(nameof(ProfessorId));
            }
        }
        public string ProfessorFirstName
        {
            get => _professorFirstName;
            internal set
            {
                _professorFirstName = value;
                OnPropertyChanged(nameof(ProfessorFirstName));
            }
        }
        public string ProfessorLastName
        {
            get => _professorLastName;
            internal set
            {
                _professorLastName = value;
                OnPropertyChanged(nameof(ProfessorLastName));
            }
        }
        public string ProfessorMiddleName
        {
            get => _professorMiddleName;
            internal set
            {
                _professorMiddleName = value;
                OnPropertyChanged(nameof(ProfessorMiddleName));
            }
        }
        public string ProfessorAddress
        {
            get => _professorAddress;
            internal set
            {
                _professorAddress = value;
                OnPropertyChanged(nameof(ProfessorAddress));
            }
        }
        public string ProfessorContactNumber
        {
            get => _professorContactNumber;
            internal set
            {
                _professorContactNumber = value;
                OnPropertyChanged(nameof(ProfessorContactNumber));
            }
        }
        public string ProfessorFullName
        {
            get => _professorFullName;
            internal set
            {
                _professorFullName = value;
                OnPropertyChanged(nameof(ProfessorFullName));
            }
        }
        public string NameOfDepartment
        {
            get => _nameOfDepartment;
                internal set
            {
                _nameOfDepartment = value;
                OnPropertyChanged(nameof(NameOfDepartment));
            }
        }
        public string ProfessorDean
        {
            get => _professorDean;
            internal set
            {
                _professorDean = value;
                OnPropertyChanged(nameof(ProfessorDean));
            }
        }
        public string ProfessorChair
        {
            get => _professorChair;
            internal set
            {
                _professorChair = value;
                OnPropertyChanged(nameof(ProfessorChair));
            }
        }
        public string ProfessorResearch
        {
            get => _professorResearch;
            internal set
            {
                _professorResearch = value;
                OnPropertyChanged(nameof(ProfessorResearch));
            }
        }
        public string ProfessorAdvisor
        {
            get => _professorAdvisor;
            internal set
            {
                _professorAdvisor = value;
                OnPropertyChanged(nameof(ProfessorAdvisor));
            }
        }

        public string DepartmentId { get; set; }
        public string ResearchDescription { get; set; }
        public double? TravelledDistance { get; set; }

        public ProfessorViewModel(DataLayer.EFClasses.TC.Professor professor)
        {
            ProfessorId = professor.ProfessorId;
            ProfessorFirstName = professor.Pro_FirstName;
            ProfessorLastName = professor.Pro_LastName;
            ProfessorMiddleName = professor.Pro_MiddleName;
            ProfessorAddress = professor.Pro_Address;
            ProfessorContactNumber = professor.Pro_ContactNumber;
            DepartmentId = professor.DepartmentId;

            if(professor.DepartmentLink != null)
            NameOfDepartment = professor.DepartmentLink.Dept_Name;

            ProfessorFullName = $"{professor.Pro_LastName}, {professor.Pro_FirstName} " +
                $"{professor.Pro_MiddleName.Substring(0, 1)}.";

            using var _conext = new TinyCollegeContext();

            var researchers = _conext.ResearchContracts.Where(c => c.ProfessorId == professor.ProfessorId);
            if (researchers.Count() != 0)
            {
                foreach (var researcher in researchers)
                {
                    if (researcher.Contract_EndedDate == null)
                    {
                        ResearchDescription = researcher.Research_Description;
                        ProfessorResearch = "Active";
                    }
                }
            }

            var chairs = _conext.Chairs.Where(c => c.ProfessorId == professor.ProfessorId);
            if (chairs.Count() != 0)
            {
                foreach (var chair in chairs)
                {
                    if (chair.Chair_EndedDate == null)
                        ProfessorChair = "Active";
                }
            }

            var deans = _conext.Deans.Where(c => c.ProfessorId == professor.ProfessorId);
            if (deans.Count() != 0)
            {
                foreach (var dean in deans)
                {
                    if (dean.Dean_EndedDate == null)
                        ProfessorDean = "Active";
                }
            }

            var completes = _conext.Reservations
                .Where(c => c.ProfessorId == professor.ProfessorId);

            foreach (var complete in completes)
            {
                TravelledDistance += complete.TravelledDistance;
            }

        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}