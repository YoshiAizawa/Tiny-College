﻿using Hangfire.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Professor.Chair
{
    public class ChairViewModel : INotifyPropertyChanged
    {
        private string _chairId;
        private string _professorId;
        private string _departmentId;


        public string ChairId
        {
            get => _chairId;
            internal set
            {
                _chairId = value;
                OnPropertyChanged(nameof(ChairId));
            }
        }

        public string ProfessorId
        {
            get => _professorId;
            internal set
            {
                _professorId = value;
                OnPropertyChanged(nameof(ProfessorId));
            }
        }

        public string DepartmentId
        {
            get => _departmentId;
            internal set
            {
                _departmentId = value;
                OnPropertyChanged(nameof(DepartmentId));
            }
        }

        public string ProfessorFullName { get; set; }

        public ChairViewModel(DataLayer.EFClasses.TC.Chair chair)
        {
            ChairId = chair.ChairId;
            ProfessorId = chair.ChairId;
            DepartmentId = chair.DepartmentId;
            ProfessorFullName = $"{chair.ProfessorLink.Pro_LastName}, {chair.ProfessorLink.Pro_FirstName} " +
                $"{chair.ProfessorLink.Pro_MiddleName.Substring(0, 1)}.";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
