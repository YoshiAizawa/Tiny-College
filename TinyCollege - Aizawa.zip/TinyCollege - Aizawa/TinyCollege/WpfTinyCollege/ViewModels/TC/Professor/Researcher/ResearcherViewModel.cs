﻿using Hangfire.Annotations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Professor.Researcher
{
    public class ResearcherViewModel
    {
        private string _researcherId;
        private string _professorId;
        private string _description;


        public string ResearcherId
        {
            get => _researcherId;
            internal set
            {
                _researcherId = value;
                OnPropertyChanged(nameof(ResearcherId));
            }
        }

        public string ProfessorId
        {
            get => _professorId;
            internal set
            {
                _professorId = value;
                OnPropertyChanged(nameof(ProfessorId));
            }
        }

        public string Description
        {
            get => _description;
            internal set
            {
                _description = value;
                OnPropertyChanged(nameof(Description));
            }
        }

        public string ProfessorFullName { get; set; }

        public ResearcherViewModel(DataLayer.EFClasses.TC.Research_Contract researcher)
        {
            ResearcherId = researcher.ResearchContractId;
            ProfessorId = researcher.ProfessorId;
            Description = researcher.Research_Description;
            ProfessorFullName = $"{researcher.ProfessorLink.Pro_LastName}, {researcher.ProfessorLink.Pro_FirstName} " +
                $"{researcher.ProfessorLink.Pro_MiddleName.Substring(0, 1)}.";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
