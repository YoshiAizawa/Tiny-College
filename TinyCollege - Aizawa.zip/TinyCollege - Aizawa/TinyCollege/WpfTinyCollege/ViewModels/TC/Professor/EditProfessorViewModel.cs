﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Building;
using WpfTinyCollege.ViewModels.TC.Department;
using DataLayer.EFClasses.Context;

namespace WpfTinyCollege.ViewModels.TC.Professor
{
    public class EditProfessorViewModel
    {
        private readonly ProfessorService _professorService;

        public EditProfessorViewModel(ProfessorViewModel professorToEdit, ProfessorService professorService, DepartmentService departmentService)
        {
            ProfessorToEdit = professorToEdit;
            _professorService = professorService;
            DepartmentList = new ObservableCollection<DepartmentViewModel>(
                departmentService.GetDepartments().Select(c =>
                new DepartmentViewModel(c))
            );

            ProfessorId = professorToEdit.ProfessorId;
            CopyEditableFields(professorToEdit);
        }
        public ProfessorViewModel ProfessorToEdit { get; set; }
        public DepartmentViewModel SelectedDepartment { get; set; }
        private void CopyEditableFields(ProfessorViewModel professorToEdit)
        {
            ProfessorFirstName = professorToEdit.ProfessorFirstName;
            ProfessorMiddleName = professorToEdit.ProfessorMiddleName;
            ProfessorLastName = professorToEdit.ProfessorLastName;
            ProfessorAddress = professorToEdit.ProfessorAddress;
            ProfessorContactNumber = professorToEdit.ProfessorContactNumber;
            DepartmentId = professorToEdit.DepartmentId;
            ResearchDescription = professorToEdit.ResearchDescription;
            DepartmentName = professorToEdit.NameOfDepartment;

            //var departments = new TinyCollegeContext().Departments.Where(c => c.DepartmentId == professorToEdit.DepartmentId);
            //foreach (var department in departments)
            //{
            //    DepartmentName = department.Dept_Name;
            //}
        }
        public string ProfessorId { get; set; }
        public string ProfessorFirstName { get; set; }
        public string ProfessorMiddleName { get; set; }
        public string ProfessorLastName { get; set; }
        public string ProfessorAddress { get; set; }
        public string ProfessorContactNumber { get; set; }
        public string DepartmentId { get; set; }
        public string ResearchDescription { get; set; }
        public string DepartmentName { get; set; }
        public ObservableCollection<DepartmentViewModel> DepartmentList { get; set; }

        public void Edit(bool isAdvisor, bool isResearcher, string? researchDescription, bool deptChange)
        {
            ProfessorToEdit.ProfessorFirstName = ProfessorFirstName;
            ProfessorToEdit.ProfessorMiddleName = ProfessorMiddleName;
            ProfessorToEdit.ProfessorLastName = ProfessorLastName;
            ProfessorToEdit.ProfessorAddress = ProfessorAddress;
            ProfessorToEdit.ProfessorContactNumber = ProfessorContactNumber;
            if (deptChange)
            {
                ProfessorToEdit.DepartmentId = SelectedDepartment.DepartmentId;
            }
            else
            {
                ProfessorToEdit.DepartmentId = DepartmentId;
            }
            ProfessorToEdit.ResearchDescription = ResearchDescription;

            var newProfessor = new DataLayer.EFClasses.TC.Professor
            {
                ProfessorId = ProfessorToEdit.ProfessorId,
                Pro_FirstName = ProfessorToEdit.ProfessorFirstName,
                Pro_MiddleName = ProfessorToEdit.ProfessorMiddleName,
                Pro_LastName = ProfessorToEdit.ProfessorLastName,
                Pro_Address = ProfessorToEdit.ProfessorAddress,
                Pro_ContactNumber = ProfessorToEdit.ProfessorContactNumber,
                DepartmentId = ProfessorToEdit.DepartmentId,
            };

            _professorService.UpdateProfessor(newProfessor,isAdvisor,isResearcher,researchDescription,deptChange);
        }
    }
}
