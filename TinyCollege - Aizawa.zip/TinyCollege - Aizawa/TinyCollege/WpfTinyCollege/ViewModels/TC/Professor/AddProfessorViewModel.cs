﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.Context;
using System.Collections.ObjectModel;
using WpfTinyCollege.ViewModels.TC.Department;
using System.Linq;

namespace WpfTinyCollege.ViewModels.TC.Professor
{
    public class AddProfessorViewModel
    {
        private readonly ProfessorService _professorService;
        private readonly DepartmentService _departmentService;

        public AddProfessorViewModel(ProfessorService professorService, DepartmentService departmentService)
        {
            _professorService = professorService;
            _departmentService = departmentService;
            DepartmentList = new ObservableCollection<DepartmentViewModel>(
                _departmentService.GetDepartments().Select(c =>
                new DepartmentViewModel(c))
            );
        }

        public string ProfessorFirstName { get; set; }
        public string ProfessorMiddleName { get; set; }
        public string ProfessorLastName { get; set; }
        public string ProfessorAddress { get; set; }
        public string ProfessorContactNumber { get; set; }
        public string DepartmentId { get; set; }
        public ObservableCollection<DepartmentViewModel> DepartmentList { get; set; }
        public DepartmentViewModel SelectedDepartment { get; set; }
        public ProfessorViewModel AssociatedProfessor { get; set; }

        public void Add(bool isAdvisor, bool isResearcher, string? researchDescription)
        {
            var professor = new DataLayer.EFClasses.TC.Professor()
            {
                Pro_FirstName = char.ToUpper(ProfessorFirstName[0]) + ProfessorFirstName[1..],
                Pro_LastName = char.ToUpper(ProfessorLastName[0]) + ProfessorLastName[1..],
                Pro_MiddleName = char.ToUpper(ProfessorMiddleName[0]) + ProfessorMiddleName[1..],
                Pro_ContactNumber = ProfessorContactNumber,
                Pro_Address = char.ToUpper(ProfessorAddress[0]) + ProfessorAddress[1..],
                DepartmentId = SelectedDepartment.DepartmentId,
            };

            _professorService.AddProfessor(professor,isAdvisor,isResearcher,researchDescription);

            AssociatedProfessor = new ProfessorViewModel(professor);
        }
    }
}
