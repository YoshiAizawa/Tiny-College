﻿using System;
using System.Collections.Generic;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Class;

namespace WpfTinyCollege.ViewModels.TC.Professor
{
    public class ProfessorClassesViewModel
    {
        private ClassViewModel _selectedClass;

        public string ClassCode { get; set; }
        public string ClassStartTime { get; set; }
        public string ClassEndTime { get; set; }
        public string ClassDayAcronym { get; set; }
        public string CourseName { get; set; }
        public string CourseId { get; set; }
        public string RoomLocation { get; set; }

        public ClassViewModel SelectedClass
        {
            get => _selectedClass;
            set
            {
                _selectedClass = value;
            }
        }

        public ProfessorClassesViewModel(DataLayer.EFClasses.TC.Class oneClass)
        {
            ClassCode = oneClass.ClassId;
            ClassStartTime = oneClass.ScheduleLink.StartTime.ToString("t");
            ClassEndTime = oneClass.ScheduleLink.EndTime.ToString("t");
            ClassDayAcronym = oneClass.ScheduleLink.DayName;
            CourseName = oneClass.CourseLink.Course_Name;
            CourseId = oneClass.CourseLink.CourseId;
            RoomLocation = oneClass.Room_Code;
        }
    }
}
