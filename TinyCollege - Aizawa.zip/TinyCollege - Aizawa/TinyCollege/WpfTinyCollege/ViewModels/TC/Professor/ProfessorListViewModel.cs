﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Professor
{
    public class ProfessorListViewModel
    {
        private readonly ProfessorService _professorService;
        private ProfessorViewModel _selectedProfessor;
        //private string _searchText;

        public ProfessorListViewModel(ProfessorService professorService)
        {
            _professorService = professorService;

            ProfessorList = new ObservableCollection<ProfessorViewModel>(
                _professorService.GetProfessors().Select(c =>
                new ProfessorViewModel(c))
            );
        }

        public ObservableCollection<ProfessorViewModel> ProfessorList { get; set; }
        public ObservableCollection<ProfessorClassesViewModel> ProfessorClassesList { get; set; } =
            new ObservableCollection<ProfessorClassesViewModel>();

        private string _searchText;

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchProfessor(_searchText);
            }
        }

        public void SearchProfessor(string searchString)
        {
            ProfessorList.Clear();

            var Professors = _professorService.GetProfessors()
                .Where(c => c.Pro_FirstName.Contains(searchString) ||
                c.Pro_LastName.Contains(searchString) ||
                c.Pro_MiddleName.Contains(searchString) ||
                c.DepartmentLink.Dept_Acronym.Contains(searchString) ||
                c.DepartmentLink.Dept_Name.Contains(searchString));

            foreach (var professor in Professors)
            {
                var CourseModel = new ProfessorViewModel(professor);

                ProfessorList.Add(CourseModel);
            }
        }

        public ProfessorViewModel SelectedProfessor
        {
            get => _selectedProfessor;
            set
            {
                _selectedProfessor = value;
                if (_selectedProfessor != null)
                    DisplayProfessorClasses(_selectedProfessor.ProfessorId);
            }
        }

        private void DisplayProfessorClasses(string professorId)
        {
            ProfessorClassesList.Clear();

            var Classes = new ClassService(new TinyCollegeContext()).GetProfessorClasses(professorId)
                .Select(c => new ProfessorClassesViewModel(c));

            foreach (var oneClass in Classes)
                ProfessorClassesList.Add(oneClass);
        }

    }
}
