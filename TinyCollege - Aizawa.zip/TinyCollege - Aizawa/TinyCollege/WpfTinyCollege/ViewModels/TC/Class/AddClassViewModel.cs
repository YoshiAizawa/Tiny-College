﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.Context;
using System.Collections.ObjectModel;
using WpfTinyCollege.ViewModels.TC.Department;
using System.Linq;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TC.Building;
using WpfTinyCollege.ViewModels.TC.Schedule;
using WpfTinyCollege.ViewModels.TC.Course;

namespace WpfTinyCollege.ViewModels.TC.Class
{
    public class AddClassViewModel
    {
        private readonly ClassService _classService;
        private CourseViewModel _selectedCourse;

        // Choose Course then Professor
        public ObservableCollection<CourseViewModel> CourseList { get; set; }
        public ObservableCollection<ProfessorViewModel> CoursesProfessorList { get; set; } =
            new ObservableCollection<ProfessorViewModel>();
        // Choose Time then Room
        public ObservableCollection<ScheduleViewModel> ScheduleList { get; set; }
        public ObservableCollection<RoomViewModel> RoomList { get; set; }

        public CourseViewModel SelectedCourse
        {
            get => _selectedCourse;
            set
            {
                _selectedCourse = value;
                if (_selectedCourse != null)
                    DisplayCourseProfessor(_selectedCourse.DepartmentId);
            }
        }

        public void DisplayCourseProfessor(string departmentId)
        {
            CoursesProfessorList.Clear();

            var Professors = new ProfessorService(new TinyCollegeContext()).GetCourseProfessors(departmentId)
                .Select(c => new ProfessorViewModel(c));

            foreach (var professor in Professors)
                CoursesProfessorList.Add(professor);
        }

        public ProfessorViewModel SelectedProfessor { get; set; }

        public ScheduleViewModel SelectedSchedule { get; set; }

        public RoomViewModel SelectedRoom { get; set; }

        public ClassViewModel AssociatedClass { get; set; }


        public AddClassViewModel(ClassService classService, CourseService courseService, ScheduleService scheduleService, RoomService roomService)
        {
            _classService = classService;

            CourseList = new ObservableCollection<CourseViewModel>(
                courseService.GetCourses().Select(c =>
                new CourseViewModel(c))
            );

            ScheduleList = new ObservableCollection<ScheduleViewModel>(
                scheduleService.GetSchedules().Select(c =>
                new ScheduleViewModel(c))
            ) ;

            RoomList = new ObservableCollection<RoomViewModel>(
                roomService.GetRooms().Select(c =>
                new RoomViewModel(c))
            );
        }

        public void Add()
        {
            var oneClass = new DataLayer.EFClasses.TC.Class()
            {
                CourseId = SelectedCourse.CourseId,
                ProfessorId = SelectedProfessor.ProfessorId,
                ScheduleId = SelectedSchedule.ScheduleId,
                Room_Code = SelectedRoom.RoomCode
            };

            _classService.AddClass(oneClass);

            AssociatedClass = new ClassViewModel(oneClass);
        }

    }
}
