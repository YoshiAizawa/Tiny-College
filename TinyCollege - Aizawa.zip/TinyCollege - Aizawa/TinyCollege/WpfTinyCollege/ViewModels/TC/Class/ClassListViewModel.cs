﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Class
{
    public class ClassListViewModel
    {
        private readonly ClassService _classService;
        //private ClassViewModel _selectedClass;

        public ClassListViewModel(ClassService classService)
        {
            _classService = classService;

            ClassList = new ObservableCollection<ClassViewModel>(
                _classService.GetClasses().Select(c =>
                new ClassViewModel(c))
            );
        }

        public ObservableCollection<ClassViewModel> ClassList { get; set; }
        public ClassViewModel SelectedClass { get; set; }

        private string _searchText;
        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchClass(_searchText);
            }
        }

        public void SearchClass(string searchString)
        {
            ClassList.Clear();

            var Courses = _classService.GetClasses()
                .Where(c => c.ClassId.Contains(searchString) ||
                c.CourseId.Contains(searchString) ||
                c.ScheduleLink.StartTime.ToString().Contains(searchString) ||
                c.ScheduleLink.EndTime.ToString().Contains(searchString) ||
                c.Room_Code.Contains(searchString) ||
                c.ProfessorLink.Pro_FirstName.Contains(searchString) ||
                c.ProfessorLink.Pro_LastName.Contains(searchString) ||
                c.CourseLink.Course_Name.Contains(searchString) ||
                c.ScheduleLink.DayName.Contains(searchString));

            foreach (var course in Courses)
            {
                var CourseModel = new ClassViewModel(course);

                ClassList.Add(CourseModel);
            }
        }
    }
}
