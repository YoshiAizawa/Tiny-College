﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using System;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TC.Class
{
    public class ClassViewModel : INotifyPropertyChanged
    {
        private string _classId;
        private string _roomCode;
        private string _courseId;
        private string _scheduleId;
        public string _professorId;

        public string ClassId
        {
            get => _classId;
            internal set
            {
                _classId = value;
                OnPropertyChanged(nameof(ClassId));
            }
        }

        public string RoomCode
        {
            get => _roomCode;
            internal set
            {
                _roomCode = value;
                OnPropertyChanged(nameof(RoomCode));
            }
        }

        public string CourseId
        {
            get => _courseId;
            internal set
            {
                _courseId = value;
                OnPropertyChanged(nameof(CourseId));
            }
        }

        public string ScheduleId
        {
            get => _scheduleId;
            internal set
            {
                _scheduleId = value;
                OnPropertyChanged(nameof(ScheduleId));
            }
        }

        public string ProfessorId
        {
            get => _professorId;
            internal set
            {
                _professorId = value;
                OnPropertyChanged(nameof(ProfessorId));
            }
        }

        public string ClassStartTime { get; set; }
        public string ClassEndTime { get; set; }
        public string ClassTime { get; set; }
        public string ClassDay { get; set; }
        public string ProfessorFullName { get; set; }
        public string CourseName { get; set; }
        public int NumberOfEnrollees { get; set; }
        public int AvailableEnrollees { get; set; }
        public string DepartmentId { get; set; }

        public ClassViewModel(DataLayer.EFClasses.TC.Class oneClass)
        {
            ClassId = oneClass.ClassId;
            RoomCode = oneClass.Room_Code;
            CourseId = oneClass.CourseId;
            if (oneClass.ScheduleLink != null)
            {
                ScheduleId = oneClass.ScheduleId;
                ClassStartTime = oneClass.ScheduleLink.StartTime.ToString("t");
                ClassEndTime = oneClass.ScheduleLink.EndTime.ToString("t");
                ClassTime = $"{ClassStartTime} - {ClassEndTime}";
                ClassDay = oneClass.ScheduleLink.DayName;
            }
            if (oneClass.CourseLink != null)
            {
                CourseName = oneClass.CourseLink.Course_Name;
                DepartmentId = oneClass.CourseLink.DepartmentId;
            }
            if (oneClass.ProfessorLink != null)
            {
                var prof = oneClass.ProfessorLink;
                ProfessorId = prof.ProfessorId;

                ProfessorFullName = $"{prof.Pro_LastName}, {prof.Pro_FirstName} " +
                    $"{prof.Pro_MiddleName.Substring(0, 1).ToUpper()}.";
            }
            var enrollees = new TinyCollegeContext().Enrolls.Where(c => c.ClassId == oneClass.ClassId);
            NumberOfEnrollees = enrollees.Count();

            AvailableEnrollees = 35 - NumberOfEnrollees;
        }


        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}