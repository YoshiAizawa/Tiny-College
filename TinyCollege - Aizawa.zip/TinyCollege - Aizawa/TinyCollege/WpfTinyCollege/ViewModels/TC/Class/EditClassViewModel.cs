﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Building;
using WpfTinyCollege.ViewModels.TC.Course;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TC.Schedule;

namespace WpfTinyCollege.ViewModels.TC.Class
{
    public class EditClassViewModel
    {
        private readonly ClassService _classService;
        private readonly CourseService _courseService;
        private readonly ScheduleService _scheduleService;
        private readonly RoomService _roomService;

        public EditClassViewModel(ClassViewModel classToEdit, ClassService classService, CourseService courseService, ScheduleService scheduleService, RoomService roomService)
        {
            ClassToEdit = classToEdit;
            _classService = classService;
            _courseService = courseService;
            _roomService = roomService;
            _scheduleService = scheduleService;

            CourseList = new ObservableCollection<CourseViewModel>(
                _courseService.GetCourses().Select(c =>
                new CourseViewModel(c))
            );

            ScheduleList = new ObservableCollection<ScheduleViewModel>(
                _scheduleService.GetSchedules().Select(c =>
                new ScheduleViewModel(c))
            );

            RoomList = new ObservableCollection<RoomViewModel>(
                _roomService.GetRooms().Select(c =>
                new RoomViewModel(c))
            );

            ClassId = ClassToEdit.ClassId;
            CopyEditableFields(ClassToEdit);
            DisplayCourseProfessor(ClassToEdit.DepartmentId);
        }

        private void CopyEditableFields(ClassViewModel classToEdit)
        {
            ClassId = classToEdit.ClassId;
            CourseName = classToEdit.CourseName;
            ScheduleId = ClassToEdit.ScheduleId;
            RoomCode = ClassToEdit.RoomCode;
            ProfessorId = ClassToEdit.ProfessorId;
            
        }

        public void DisplayCourseProfessor(string departmentId)
        {
            CoursesProfessorList.Clear();

            var Professors = new ProfessorService(new TinyCollegeContext()).GetCourseProfessors(departmentId)
                .Select(c => new ProfessorViewModel(c));

            foreach (var professor in Professors)
                CoursesProfessorList.Add(professor);
        }
        public ObservableCollection<CourseViewModel> CourseList { get; set; }
        public ObservableCollection<ProfessorViewModel> CoursesProfessorList { get; set; } =
            new ObservableCollection<ProfessorViewModel>();
        public ObservableCollection<ScheduleViewModel> ScheduleList { get; set; }
        public ObservableCollection<RoomViewModel> RoomList { get; set; }
        public ProfessorViewModel SelectedProfessor { get; set; }
        public ScheduleViewModel SelectedSchedule { get; set; }
        public RoomViewModel SelectedRoom { get; set; }
        public ClassViewModel AssociatedClass { get; set; }
        public ClassViewModel ClassToEdit { get; set; }
        public string ClassId { get; set; }
        public string ProfessorId { get; set; }
        public string ScheduleId { get; set; }
        public string RoomCode { get; set; }
        public string CourseName { get; set; }
        

        public void Edit(bool changeProf, bool changeSched, bool changeRoom)
        {
            ClassToEdit.CourseName = CourseName;
            ClassToEdit.ProfessorId = SelectedProfessor.ProfessorId;
            ClassToEdit.ScheduleId = SelectedSchedule.ScheduleId;
            if (changeProf)
            {
                ClassToEdit.ProfessorId = SelectedProfessor.ProfessorId;
            }
            else
            {
                ClassToEdit.ProfessorId = ProfessorId;
            }
            if (changeSched)
            {
                ClassToEdit.ScheduleId = SelectedSchedule.ScheduleId;
            }
            else
            {
                ClassToEdit.ScheduleId = ScheduleId;
            }
            if (changeRoom)
            {
                ClassToEdit.RoomCode = SelectedRoom.RoomCode;
            }
            else
            {
                ClassToEdit.RoomCode = RoomCode;
            }

            var newClass = new DataLayer.EFClasses.TC.Class
            {
                ClassId = ClassToEdit.ClassId,
                ProfessorId = ClassToEdit.ProfessorId,
                CourseId = ClassToEdit.CourseId,
                ScheduleId = ClassToEdit.ScheduleId,
                Room_Code = ClassToEdit.RoomCode,
            };

            _classService.UpdateClasses(newClass);
        }
    }
}
