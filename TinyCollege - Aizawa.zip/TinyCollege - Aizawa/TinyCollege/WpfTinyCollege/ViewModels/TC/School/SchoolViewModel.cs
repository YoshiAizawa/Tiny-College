﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TC.School
{
    public class SchoolViewModel : INotifyPropertyChanged
    {
        private string _schoolId;
        private string _schoolName;


        public string SchoolId
        {
            get => _schoolId;
            internal set
            {
                _schoolId = value;
                OnPropertyChanged(nameof(SchoolId));
            }
        }

        public string SchoolName
        {
            get => _schoolName;
            internal set
            {
                _schoolName = value;
                OnPropertyChanged(nameof(SchoolName));
            }
        }
        public string DeanFullName { get; set; }
        public string NumberOfDepartments { get; set; }

        public SchoolViewModel(DataLayer.EFClasses.TC.School school)
        {
            if (school.Deans == null || school.Departments == null)
            {
                SchoolId = school.SchoolId;
                SchoolName = school.School_Name;
                NumberOfDepartments = 0.ToString();
            }
            else
            {
                using (var _context = new TinyCollegeContext())
                {
                    var deans = _context.Deans.Where(c => c.SchoolId == school.SchoolId)
                        .Include(c => c.ProfessorLink);

                    foreach (var dean in deans)
                    {
                        if (dean.Dean_EndedDate == null)
                        {
                            DeanFullName = $"{dean.ProfessorLink.Pro_LastName}, {dean.ProfessorLink.Pro_FirstName} " +
                                $"{dean.ProfessorLink.Pro_MiddleName.Substring(0, 1)}.";
                        }
                    }
                }
                SchoolId = school.SchoolId;
                SchoolName = school.School_Name;
                NumberOfDepartments = school.Departments.Count().ToString();
            }
        }

        public SchoolViewModel()
        {
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}