﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.School
{
    public class RemoveSchoolDeanViewModel
    {
        private DeanService _deanService;

        public RemoveSchoolDeanViewModel(SchoolViewModel selectedSchool)
        {
            _deanService = new DeanService(new TinyCollegeContext());

            var deans = new TinyCollegeContext().Deans.Where(c => c.SchoolId == selectedSchool.SchoolId);

            foreach (var dean in deans)
            {
                if (dean.Dean_EndedDate == null)
                {
                    DeanId = dean.DeanId;
                }
            }
        }

        public string DeanId { get; set; }
        public string ProfessorId { get; set; }
        public DateTime DeanStartDate { get; set; }
        public string SchoolId { get; set; }

        public void Remove()
        {
            
            var removeDean = new DataLayer.EFClasses.TC.Dean
            {
                DeanId = DeanId,
                SchoolId = SchoolId,
                ProfessorId = ProfessorId,
                Dean_StartedDate = DeanStartDate,
            };

            _deanService.UpdateDean(removeDean);
        }
    }
}
