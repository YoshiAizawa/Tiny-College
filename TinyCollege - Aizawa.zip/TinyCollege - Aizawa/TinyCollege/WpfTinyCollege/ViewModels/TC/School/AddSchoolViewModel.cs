﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.School
{
    public class AddSchoolViewModel
    {
        private readonly SchoolService _schoolService;

        public AddSchoolViewModel(SchoolService SchoolService)
        {
            _schoolService = SchoolService;
        }

        public string SchoolName { get; set; }
        public SchoolViewModel AssociatedSchool { get; set; }

        public void Add()
        {
            var school = new DataLayer.EFClasses.TC.School()
            {
                School_Name = SchoolName,
            };

            _schoolService.AddSchool(school);

            AssociatedSchool = new SchoolViewModel(school);
        }
    }
}
