﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.School
{
    public class SchoolListViewModel
    {
        private readonly SchoolService _schoolService;
        private SchoolViewModel _selectedSchool;

        public SchoolListViewModel(SchoolService schoolService)
        {
            _schoolService = schoolService;

            SchoolList = new ObservableCollection<SchoolViewModel>(
                _schoolService.GetSchool().Select(c =>
                new SchoolViewModel(c))
            );
        }

        public ObservableCollection<SchoolViewModel> SchoolList { get; set; }
        public SchoolViewModel SelectedSchool
        {
            get => _selectedSchool;
            set
            {
                _selectedSchool = value;
                if (_selectedSchool != null)
                    DisplaySchoolDepartments(_selectedSchool.SchoolId);
            }
        }

        public ObservableCollection<SchoolDepartmentsViewModel> SchoolDepartmentList { get; set; } =
            new ObservableCollection<SchoolDepartmentsViewModel>();


        //Display

        private void DisplaySchoolDepartments(string schoolId)
        {
            SchoolDepartmentList.Clear();

            var departments = new DepartmentService(new TinyCollegeContext()).GetSchoolDepartments(schoolId)
                .Select(c => new SchoolDepartmentsViewModel(c));

            foreach (var department in departments)
                SchoolDepartmentList.Add(department);
        }

        private string _searchText;

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchSchool(_searchText);
            }
        }

        public void SearchSchool(string searchString)
        {
            SchoolList.Clear();

            var Schools = _schoolService.GetSchool()
                .Where(c => c.School_Name.Contains(searchString) ||
                c.SchoolId.Contains(searchString));

            foreach (var school in Schools)
            {
                var SchoolModel = new SchoolViewModel(school);

                SchoolList.Add(SchoolModel);
            }
        }
    }
}
