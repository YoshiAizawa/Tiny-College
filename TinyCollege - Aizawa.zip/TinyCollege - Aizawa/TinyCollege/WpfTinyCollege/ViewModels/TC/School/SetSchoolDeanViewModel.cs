﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Department;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TC.Professor.Dean;

namespace WpfTinyCollege.ViewModels.TC.School
{
    public class SetSchoolDeanViewModel
    {
        private readonly DeanService _deanService;
        private readonly SchoolService _schoolService;
        private SchoolDepartmentsViewModel _selectedDepartment;

        public SetSchoolDeanViewModel(SchoolViewModel selectedSchool)
        {
            _deanService = new DeanService(new TinyCollegeContext());
            SchoolId = selectedSchool.SchoolId;
            SchoolName = selectedSchool.SchoolName;
            DeanFullName = selectedSchool.DeanFullName;
            DisplaySchoolDepartments(selectedSchool.SchoolId);
        }

        // Show Departments of School
        private void DisplaySchoolDepartments(string schoolId)
        {
            SchoolDepartmentList.Clear();

            var departments = new DepartmentService(new TinyCollegeContext()).GetSchoolDepartments(schoolId)
                .Select(c => new SchoolDepartmentsViewModel(c));

            foreach (var department in departments)
                SchoolDepartmentList.Add(department);
        }
        public ObservableCollection<SchoolDepartmentsViewModel> SchoolDepartmentList { get; set; } =
            new ObservableCollection<SchoolDepartmentsViewModel>();
        public SchoolDepartmentsViewModel SelectedDepartment
        {
            get => _selectedDepartment;
            set
            {
                _selectedDepartment = value;
                if (_selectedDepartment != null)
                    DisplayDepartmentProfessors(_selectedDepartment.DepartmentId);
            }
        }
        //Show Professor of Selected Department
        private void DisplayDepartmentProfessors(string departmentId)
        {
            DepartmentProfessorsList.Clear();

            var professors = new ProfessorService(new TinyCollegeContext()).GetDepartmentProfessors(departmentId)
                .Select(c => new DepartmentProfessorsViewModel(c));

            foreach (var department in professors)
                DepartmentProfessorsList.Add(department);
        }
        public ObservableCollection<DepartmentProfessorsViewModel> DepartmentProfessorsList { get; set; } =
            new ObservableCollection<DepartmentProfessorsViewModel>();

        public DepartmentProfessorsViewModel SelectedProfessor { get; set; }
        public string DeanId { get; set; }
        public string SchoolId { get; set; }
        public string SchoolName { get; set; }
        public string ProfessorId { get; set; }
        public string DeanFullName { get; set; }
        public ObservableCollection<SchoolViewModel> SchoolList { get; set; }

        public void Set()
        {
            var newDean = new DataLayer.EFClasses.TC.Dean
            {
                SchoolId = SchoolId,
                ProfessorId = SelectedProfessor.ProfessorId,
                Dean_StartedDate = DateTime.Now,
            };

            _deanService.AddDean(newDean);
        }
    }
}
