﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.School
{
    public class EditSchoolViewModel
    {
        private readonly SchoolService _schoolService;

        public EditSchoolViewModel(SchoolViewModel schoolToEdit, SchoolService SchoolService)
        {
            SchoolToEdit = schoolToEdit;
            _schoolService = SchoolService;

            SchoolId = schoolToEdit.SchoolId;
            CopyEditableFields(SchoolToEdit);
        }
        public SchoolViewModel SchoolToEdit { get; set; }
        private void CopyEditableFields(SchoolViewModel SchoolToEdit)
        {
            SchoolName = SchoolToEdit.SchoolName;
        }
        public string SchoolId { get; set; }
        public string SchoolName { get; set; }

        public void Edit()
        {
            SchoolToEdit.SchoolName = SchoolName;

            var newSchool = new DataLayer.EFClasses.TC.School
            {
                SchoolId = SchoolToEdit.SchoolId,
                School_Name = SchoolToEdit.SchoolName
            };



            _schoolService.UpdateSchools(newSchool);
        }
    }
}
