﻿using DataLayer.EFClasses.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.School
{
    public class SchoolDepartmentsViewModel
    {
        public string DepartmentId { get; set; }
        public string DepartmentName { get; set; }
        public string ChairFullName { get; set; }
        public SchoolDepartmentsViewModel(DataLayer.EFClasses.TC.Department department)
        {
            using (var _context = new TinyCollegeContext())
            {
                var chairs = _context.Chairs.Where(c=>c.DepartmentId == department.DepartmentId)
                    .Include(c=>c.ProfessorLink);
                foreach (var chair in chairs)
                {
                    if (chair.Chair_EndedDate == null)
                    {
                        ChairFullName = $"{chair.ProfessorLink.Pro_LastName}, {chair.ProfessorLink.Pro_FirstName} " +
                            $"{chair.ProfessorLink.Pro_MiddleName.Substring(0, 1)}.";
                    }
                }
            }
            DepartmentId = department.DepartmentId;
            DepartmentName = department.Dept_Name;
        }
    }
}
