﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Schedule
{
    public class ScheduleListViewModel
    {
        private readonly ScheduleService _scheduleService;
        private ScheduleViewModel _selectedSchedule;

        public ScheduleListViewModel(ScheduleService scheduleService)
        {
            _scheduleService = scheduleService;

            ScheduleList = new ObservableCollection<ScheduleViewModel>(
                _scheduleService.GetSchedules().Select(c =>
                new ScheduleViewModel(c))
            );
        }

        public ObservableCollection<ScheduleViewModel> ScheduleList { get; set; }
        public ObservableCollection<ScheduleClassesViewModel> ScheduleClassesList { get; set; } =
            new ObservableCollection<ScheduleClassesViewModel>();

        public ScheduleViewModel SelectedSchedule
        {
            get => _selectedSchedule;
            set
            {
                _selectedSchedule = value;
                if (_selectedSchedule != null)
                    DisplayScheduleClasses(_selectedSchedule.ScheduleId);
            }
        }

        private void DisplayScheduleClasses(string scheduleId)
        {
            ScheduleClassesList.Clear();

            var Classes = new ClassService(new TinyCollegeContext()).GetScheduleClasses(scheduleId)
                .Select(c => new ScheduleClassesViewModel(c));

            foreach (var oneClass in Classes)
                ScheduleClassesList.Add(oneClass);
        }

        private string _searchText;

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchSchedule(_searchText);
            }
        }

        public void SearchSchedule(string searchString)
        {
            ScheduleList.Clear();

            var Schedules = _scheduleService.GetSchedules()
                .Where(c => c.ScheduleId.Contains(searchString) ||
                c.StartTime.ToString().Contains(searchString) ||
                c.EndTime.ToString().Contains(searchString) ||
                c.DayName.Contains(searchString));

            foreach (var schedule in Schedules)
            {
                var ScheduleModel = new ScheduleViewModel(schedule);

                ScheduleList.Add(ScheduleModel);
            }
        }
    }
}
