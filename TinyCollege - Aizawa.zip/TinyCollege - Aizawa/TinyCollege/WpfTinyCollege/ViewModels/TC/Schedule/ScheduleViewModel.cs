﻿using Hangfire.Annotations;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TC.Schedule
{
    public class ScheduleViewModel : INotifyPropertyChanged
    {
        private string _scheduleId;
        private string _startingTime;
        private string _endingTime;
        private string _dayAcronym;

        public string ScheduleId
        {
            get => _scheduleId;
            internal set
            {
                _scheduleId = value;
                OnPropertyChanged(nameof(ScheduleId));
            }
        }

        public string StartingTime
        {
            get => _startingTime;
            internal set
            {
                _startingTime = value;
                OnPropertyChanged(nameof(StartingTime));
            }
        }

        public string EndingTime
        {
            get => _endingTime;
            internal set
            {
                _endingTime = value;
                OnPropertyChanged(nameof(EndingTime));
            }
        }

        public string DayAcronym
        {
            get => _dayAcronym;
            internal set
            {
                _dayAcronym = value;
                OnPropertyChanged(nameof(DayAcronym));
            }
        }

        public string ScheduleTime { get; set; }

        public ScheduleViewModel(DataLayer.EFClasses.TC.Schedule schedule)
        {
            ScheduleId = schedule.ScheduleId;
            StartingTime = schedule.StartTime.ToString("t");
            EndingTime = schedule.EndTime.ToString("t");
            DayAcronym = schedule.DayName;
            ScheduleTime = $"{StartingTime} - {EndingTime} {DayAcronym}";
        }


        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}