﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Schedule
{
    public class ScheduleClassesViewModel
    {
        public string CourseName { get; set; }
        public string RoomLocation { get; set; }
        public string CourseId { get; set; }
        public string ProfessorFullName { get; set; }
        public int NumberOfStudents { get; set; }

        public ScheduleClassesViewModel(DataLayer.EFClasses.TC.Class oneClass)
        {
            CourseName = oneClass.CourseLink.Course_Name;
            RoomLocation = oneClass.Room_Code;
            CourseId = oneClass.CourseId;
            ProfessorFullName = $"{oneClass.ProfessorLink.Pro_LastName}, {oneClass.ProfessorLink.Pro_FirstName} " +
                $"{oneClass.ProfessorLink.Pro_MiddleName.Substring(0,1).ToUpper()}.";
            NumberOfStudents = oneClass.Enrolls.Count();
        }
    }
}
