﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Schedule
{
    public class AddScheduleViewModel
    {
        private readonly ScheduleService _scheduleService;

        public AddScheduleViewModel(ScheduleService scheduleService)
        {
            _scheduleService = scheduleService;
        }

        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string DayAcronym { get; set; }
        public ScheduleViewModel AssociatedSchedule { get; set; }

        public void Add()
        {
            var schedule = new DataLayer.EFClasses.TC.Schedule()
            {
                StartTime = Convert.ToDateTime(StartTime),
                EndTime = Convert.ToDateTime(EndTime),
                DayName = DayAcronym
            };

            _scheduleService.AddSchedule(schedule);

            AssociatedSchedule = new ScheduleViewModel(schedule);
        }
    }
}
