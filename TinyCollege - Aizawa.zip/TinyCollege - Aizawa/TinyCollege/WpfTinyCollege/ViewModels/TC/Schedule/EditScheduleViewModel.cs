﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Schedule
{
    public class EditScheduleViewModel
    {
        private readonly ScheduleService _scheduleService;

        public EditScheduleViewModel(ScheduleViewModel scheduleToEdit, ScheduleService scheduleService)
        {
            ScheduleToEdit = scheduleToEdit;
            _scheduleService = scheduleService;

            ScheduleId = scheduleToEdit.ScheduleId;
            CopyEditableFields(ScheduleToEdit);
        }
        public ScheduleViewModel ScheduleToEdit { get; set; }
        private void CopyEditableFields(ScheduleViewModel scheduleToEdit)
        {
            StartTime = scheduleToEdit.StartingTime;
            EndTime = scheduleToEdit.EndingTime;
            DayAcronym = scheduleToEdit.DayAcronym;
        }
        public string ScheduleId { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string DayAcronym { get; set; }

        public void Edit()
        {
            ScheduleToEdit.StartingTime = StartTime;
            ScheduleToEdit.EndingTime = EndTime;
            ScheduleToEdit.DayAcronym = DayAcronym;

            var newSchedule = new DataLayer.EFClasses.TC.Schedule
            {
                ScheduleId = ScheduleToEdit.ScheduleId,
                StartTime = Convert.ToDateTime(ScheduleToEdit.StartingTime),
                EndTime = Convert.ToDateTime(ScheduleToEdit.EndingTime),
                DayName = ScheduleToEdit.DayAcronym
            };



            _scheduleService.UpdateSchedules(newSchedule);
        }
    }
}
