﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Department;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TC.Student;

namespace WpfTinyCollege.ViewModels.TC.Student
{
    public class EditStudentViewModel
    {
        private readonly StudentService _studentService;
        private readonly DepartmentService _departmentService;
        private DepartmentViewModel _selectedDepartment;

        public EditStudentViewModel(StudentViewModel studentToEdit, StudentService studentService, DepartmentService departmentService)
        {
            StudentToEdit = studentToEdit;
            _studentService = studentService;
            _departmentService = departmentService;
            DepartmentList = new ObservableCollection<DepartmentViewModel>(
                _departmentService.GetDepartments().Select(c =>
                new DepartmentViewModel(c))
            );

            StudentId = StudentToEdit.StudentId;
            CopyEditableFields(StudentToEdit);
            DisplayDefaultProfessor(StudentToEdit.DepartmentId);
        }
        public ObservableCollection<DepartmentViewModel> DepartmentList { get; set; }
        public ObservableCollection<ProfessorViewModel> DepartmentProfessorList { get; set; } =
            new ObservableCollection<ProfessorViewModel>();

        public StudentViewModel StudentToEdit { get; set; }
        public ProfessorViewModel SelectedProfessor { get; set; }
        public DepartmentViewModel SelectedDepartment
        {
            get => _selectedDepartment;
            set
            {
                _selectedDepartment = value;
                if (_selectedDepartment != null)
                    DisplayDepartmentProfessor(_selectedDepartment.DepartmentId);
            }
        }

        public void DisplayDepartmentProfessor(string departmentId)
        {
            DepartmentProfessorList.Clear();

            var Professors = new ProfessorService(new TinyCollegeContext()).GetDepartmentProfessors(departmentId)
                .Select(c => new ProfessorViewModel(c));

            foreach (var professor in Professors)
                DepartmentProfessorList.Add(professor);
        }

        public void DisplayDefaultProfessor(string departmentId)
        {
            DepartmentProfessorList.Clear();

            var Professors = new ProfessorService(new TinyCollegeContext()).GetDepartmentProfessors(departmentId)
                .Select(c => new ProfessorViewModel(c));

            foreach (var professor in Professors)
                DepartmentProfessorList.Add(professor);
        }

        private void CopyEditableFields(StudentViewModel StudentToEdit)
        {
            StudentFirstName = StudentToEdit.StudentFirstName;
            StudentMiddleName = StudentToEdit.StudentMiddleName;
            StudentLastName = StudentToEdit.StudentLastName;
            StudentAddress = StudentToEdit.StudentAddress;
            StudentContactNumber = StudentToEdit.StudentContactNumber;
            DepartmentId = StudentToEdit.DepartmentId;
            ProfessorId = StudentToEdit.ProfessorId;
        }
        public string StudentId { get; set; }
        public string StudentFirstName { get; set; }
        public string StudentMiddleName { get; set; }
        public string StudentLastName { get; set; }
        public string StudentAddress { get; set; }
        public string StudentContactNumber { get; set; }
        public string DepartmentId { get; set; }
        public string ProfessorId { get; set; }

        public void Edit(bool changeDept, bool changeAdv)
        {
            StudentToEdit.StudentFirstName = StudentFirstName;
            StudentToEdit.StudentMiddleName = StudentMiddleName;
            StudentToEdit.StudentLastName = StudentLastName;
            StudentToEdit.StudentAddress = StudentAddress;
            StudentToEdit.StudentContactNumber = StudentContactNumber;
            if (changeDept)
            {
                StudentToEdit.DepartmentId = SelectedDepartment.DepartmentId;
            }
            else
            {
                StudentToEdit.DepartmentId = DepartmentId;
            }
            if (changeAdv)
            {
                StudentToEdit.ProfessorId = SelectedProfessor.ProfessorId;
            }
            else
            {
                StudentToEdit.ProfessorId = ProfessorId;
            }

            var newStudent = new DataLayer.EFClasses.TC.Student
            {
                StudentId = StudentToEdit.StudentId,
                Stu_FirstName = StudentToEdit.StudentFirstName,
                Stu_MiddleName = StudentToEdit.StudentMiddleName,
                Stu_LastName = StudentToEdit.StudentLastName,
                Stu_Address = StudentToEdit.StudentAddress,
                Stu_ContactNumber = StudentToEdit.StudentContactNumber,
                DepartmentId = StudentToEdit.DepartmentId,
                ProfessorId = StudentToEdit.ProfessorId
            };

            _studentService.UpdateStudents(newStudent);
        }
    }
}
