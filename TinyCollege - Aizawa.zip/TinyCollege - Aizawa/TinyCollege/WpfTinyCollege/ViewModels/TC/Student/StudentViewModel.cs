﻿using Hangfire.Annotations;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TC.Student
{
    public class StudentViewModel : INotifyPropertyChanged
    {
        private string _studentId;
        private string _studentFirstName;
        private string _studentLastName;
        private string _studentMiddleName;
        private string _studentAddress;
        private string _studentContactNumber;
        private string _departmentId;
        private string _professorId;


        public string StudentId
        {
            get => _studentId;
            internal set
            {
                _studentId = value;
                OnPropertyChanged(nameof(StudentId));
            }
        }
        public string DepartmentId
        {
            get => _departmentId;
            internal set
            {
                _departmentId = value;
                OnPropertyChanged(nameof(DepartmentId));
            }
        }
        public string ProfessorId
        {
            get => _professorId;
            internal set
            {
                _professorId = value;
                OnPropertyChanged(nameof(ProfessorId));
            }
        }
        public string StudentFirstName
        {
            get => _studentFirstName;
            internal set
            {
                _studentFirstName = value;
                OnPropertyChanged(nameof(StudentFirstName));
            }
        }
        public string StudentLastName
        {
            get => _studentLastName;
            internal set
            {
                _studentLastName = value;
                OnPropertyChanged(nameof(StudentLastName));
            }
        }
        public string StudentMiddleName
        {
            get => _studentMiddleName;
            internal set
            {
                _studentMiddleName = value;
                OnPropertyChanged(nameof(StudentMiddleName));
            }
        }
        public string StudentAddress
        {
            get => _studentAddress;
            internal set
            {
                _studentAddress = value;
                OnPropertyChanged(nameof(StudentAddress));
            }
        }
        public string StudentContactNumber
        {
            get => _studentContactNumber;
            internal set
            {
                _studentContactNumber = value;
                OnPropertyChanged(nameof(StudentContactNumber));
            }
        }

        public string NameOfDepartment { get; set; }
        public string NameOfProfessor { get; set; }
        public string StudentFullName { get; set; }

        public StudentViewModel(DataLayer.EFClasses.TC.Student student)
        {
            StudentId = student.StudentId;
            StudentFirstName = student.Stu_FirstName;
            StudentMiddleName = student.Stu_MiddleName;
            StudentLastName = student.Stu_LastName;
            StudentAddress = student.Stu_Address;
            StudentContactNumber = student.Stu_ContactNumber;
            DepartmentId = student.DepartmentId;
            ProfessorId = student.ProfessorId;
            if(student.DepartmentLink != null)
                NameOfDepartment = student.DepartmentLink.Dept_Name;

            if(student.ProfessorLink != null)
                NameOfProfessor = $"{student.ProfessorLink.Pro_LastName}, " +
                $"{student.ProfessorLink.Pro_FirstName} " +
                $"{student.ProfessorLink.Pro_MiddleName.Substring(0,1).ToUpper()}.";

            StudentFullName = $"{student.Stu_LastName}, {student.Stu_FirstName} " +
                $"{student.Stu_MiddleName.Substring(0, 1).ToUpper()}.";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}