﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Student
{
    public class StudentListViewModel
    {
        private readonly StudentService _studentService;
        private StudentViewModel _selectedStudent;

        public StudentListViewModel(StudentService studentService)
        {
            _studentService = studentService;

            StudentList = new ObservableCollection<StudentViewModel>(
                _studentService.GetStudents().OrderBy(c=>c.StudentId)
                    .Select(c => new StudentViewModel(c))
            );
        }

        public ObservableCollection<StudentViewModel> StudentList { get; set; }
        public ObservableCollection<StudentEnrollsViewModel> StudentClassesList { get; set; } =
            new ObservableCollection<StudentEnrollsViewModel>();

        public StudentViewModel SelectedStudent
        {
            get => _selectedStudent;
            set
            {
                _selectedStudent = value;
                if (_selectedStudent != null)
                    DisplayStudentEnrolls(_selectedStudent.StudentId);

            }
        }

        private void DisplayStudentEnrolls(string studentId)
        {
            StudentClassesList.Clear();

            var Classes = new EnrollService(new TinyCollegeContext()).GetStudentEnroll(studentId)
                .Select(c => new StudentEnrollsViewModel(c));

            foreach (var oneClass in Classes)
                StudentClassesList.Add(oneClass);
        }


        private string _searchText;

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchStudent(_searchText);
            }
        }

        public void SearchStudent(string searchString)
        {
            StudentList.Clear();

            var Students = _studentService.GetStudents()
                .Where(c => c.Stu_FirstName.Contains(searchString) ||
                c.Stu_LastName.Contains(searchString) ||
                c.DepartmentLink.Dept_Name.Contains(searchString));
            
            foreach (var student in Students)
            {
                var StudentModel = new StudentViewModel(student);

                StudentList.Add(StudentModel);
            }
        }
    }
}
