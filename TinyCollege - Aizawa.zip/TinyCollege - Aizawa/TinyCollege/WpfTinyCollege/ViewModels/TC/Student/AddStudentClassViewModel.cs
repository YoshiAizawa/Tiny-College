﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Class;
using WpfTinyCollege.ViewModels.TC.Course;
using WpfTinyCollege.ViewModels.TC.School;

namespace WpfTinyCollege.ViewModels.TC.Student
{
    public class AddStudentClassViewModel
    {
        private readonly EnrollService _enrollService;
        private readonly SchoolService _schoolService;
        private readonly CourseService _courseService;
        private CourseViewModel _selectedCourse;

        public AddStudentClassViewModel(StudentViewModel selectedStudent)
        {
            _enrollService = new EnrollService(new TinyCollegeContext());
            _courseService = new CourseService(new TinyCollegeContext());
            StudentId = selectedStudent.StudentId;
            StudentFullName = selectedStudent.StudentFullName;

            CourseList = new ObservableCollection<CourseViewModel>(
                _courseService.GetCourses().Select(c =>
                new CourseViewModel(c)));
        }

        public ObservableCollection<CourseViewModel> CourseList { get; set; }
        public CourseViewModel SelectedCourse
        {
            get => _selectedCourse;
            set
            {
                _selectedCourse = value;
                if (_selectedCourse != null)
                    DisplayCourseClasses(_selectedCourse.CourseId);
            }
        }

        public ObservableCollection<CourseClassesViewModel> CourseClassesList { get; set; } =
            new ObservableCollection<CourseClassesViewModel>();

        // Show Departments of School
        private void DisplayCourseClasses(string courseId)
        {
            CourseClassesList.Clear();

            var classes = new ClassService(new TinyCollegeContext()).GetCourseClasses(courseId)
                .Select(c => new CourseClassesViewModel(c));

            foreach (var oneClass in classes)
                CourseClassesList.Add(oneClass);
        }
        public CourseClassesViewModel SelectedClass { get; set; }
        public string StudentId { get; set; }
        public string StudentFullName { get; set; }
        public string Semester { get; set; }

        public void Add()
        {
            var newEnroll = new DataLayer.EFClasses.TC.Enroll
            {
                StudentId = StudentId,
                ClassId = SelectedClass.ClassCode,
                Semester = Semester,
                Enrolled_Date = DateTime.Now
            };

            _enrollService.AddEnroll(newEnroll);
        }
    }
}
