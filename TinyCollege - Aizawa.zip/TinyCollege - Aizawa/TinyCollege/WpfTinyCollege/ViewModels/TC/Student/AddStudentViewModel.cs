﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Department;
using WpfTinyCollege.ViewModels.TC.Professor;

namespace WpfTinyCollege.ViewModels.TC.Student
{
    public class AddStudentViewModel
    {
        private readonly StudentService _studentService;
        private readonly DepartmentService _departmentService;
        private DepartmentViewModel _selectedDepartment;

        public AddStudentViewModel(StudentService studentService, DepartmentService departmentService)
        {
            _studentService = studentService;
            _departmentService = departmentService;
            DepartmentList = new ObservableCollection<DepartmentViewModel>(
                _departmentService.GetDepartments().Select(c =>
                new DepartmentViewModel(c))
            );
        }

        public string StudentFirstName { get; set; }
        public string StudentMiddleName { get; set; }
        public string StudentLastName { get; set; }
        public string StudentAddress { get; set; }
        public string StudentContactNumber { get; set; }
        public string DepartmentId { get; set; }
        public string AdvisorId { get; set; }
        public ObservableCollection<DepartmentViewModel> DepartmentList { get; set; }
        public ObservableCollection<ProfessorViewModel> DepartmentProfessorList { get; set; } =
            new ObservableCollection<ProfessorViewModel>();
        public DepartmentViewModel SelectedDepartment
        {
            get => _selectedDepartment;
            set
            {
                _selectedDepartment = value;
                if (_selectedDepartment != null)
                    DisplayDepartmentProfessor(_selectedDepartment.DepartmentId);
            }
        }

        public void DisplayDepartmentProfessor(string departmentId)
        {
            DepartmentProfessorList.Clear();

            var Professors = new ProfessorService(new TinyCollegeContext()).GetDepartmentProfessors(departmentId)
                .Select(c => new ProfessorViewModel(c));

            foreach (var professor in Professors)
                DepartmentProfessorList.Add(professor);
        }
        public ProfessorViewModel SelectedProfessor { get; set; }
        public StudentViewModel AssociatedStudent { get; set; }

        public void Add()
        {
            var student = new DataLayer.EFClasses.TC.Student()
            {
                Stu_FirstName = char.ToUpper(StudentFirstName[0]) + StudentFirstName.Substring(1),
                Stu_LastName = char.ToUpper(StudentLastName[0]) + StudentLastName.Substring(1),
                Stu_MiddleName = char.ToUpper(StudentMiddleName[0]) + StudentMiddleName.Substring(1),
                Stu_ContactNumber = StudentContactNumber,
                Stu_Address = char.ToUpper(StudentAddress[0]) + StudentAddress.Substring(1),
                DepartmentId = SelectedDepartment.DepartmentId,
                ProfessorId = SelectedProfessor.ProfessorId,
            };

            _studentService.AddStudent(student);

            AssociatedStudent = new StudentViewModel(student);
        }
    }
}
