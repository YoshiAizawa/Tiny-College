﻿using DataLayer.EFClasses.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Student
{
    public class StudentEnrollsViewModel
    {
        public string ClassStartTime { get; set; }
        public string ClassEndTime { get; set; }
        public string ClassDayAcronym { get; set; }
        public string CourseName { get; set; }
        public string ProfessorName { get; set; }
        public string RoomLocation { get; set; }
        public string CourseNameCode { get; set; }

        public StudentEnrollsViewModel(DataLayer.EFClasses.TC.Enroll enroll)
        {

            RoomLocation = enroll.ClassLink.Room_Code;
            CourseName = enroll.ClassLink.CourseLink.Course_Name;
            ClassStartTime = enroll.ClassLink.ScheduleLink.StartTime.TimeOfDay.ToString();
            ClassEndTime = enroll.ClassLink.ScheduleLink.EndTime.TimeOfDay.ToString();
            ClassDayAcronym = enroll.ClassLink.ScheduleLink.DayName;
            ProfessorName = $"{enroll.ClassLink.ProfessorLink.Pro_LastName}, {enroll.ClassLink.ProfessorLink.Pro_FirstName} " +
                $"{enroll.ClassLink.ProfessorLink.Pro_MiddleName.Substring(0, 1).ToUpper()}.";

            CourseNameCode = $"{enroll.ClassLink.CourseLink.CourseId} - {enroll.ClassLink.CourseLink.Course_Name}";

            //  ClassStartTime = oneClass.ScheduleLink.StartTime.TimeOfDay.ToString();
            //  ClassEndTime = oneClass.ScheduleLink.EndTime.TimeOfDay.ToString();
            //  ClassDayAcronym = oneClass.ScheduleLink.DayName;
            //  CourseName = oneClass.CourseLink.Course_Name;
            //  RoomLocation = oneClass.Room_Code;
            //  ProfessorName = $"{oneClass.ProfessorLink.Pro_LastName}, " +
            //    $"{oneClass.ProfessorLink.Pro_FirstName} " +
            //    $"{oneClass.ProfessorLink.Pro_MiddleName.Substring(0,1).ToUpper()}.";

        }
    }
}
