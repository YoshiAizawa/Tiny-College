﻿using System.Collections.Generic;
using Hangfire.Annotations;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TC.Building
{
    public class BuildingViewModel : INotifyPropertyChanged
    {
        private string _buildingId;
        private string _buildingName;
        private string _buildingNameAcronym;
        private int _floors;
        private int _numberOfRooms_PerFloor;


        public string BuildingId
        {
            get => _buildingId;
            internal set
            {
                _buildingId = value;
                OnPropertyChanged(nameof(BuildingId));
            }
        }

        public string BuildingName
        {
            get => _buildingName;
            internal set
            {
                _buildingName = value;
                OnPropertyChanged(nameof(BuildingName));
            }
        }

        public string BuildingNameAcronym
        {
            get => _buildingNameAcronym;
            internal set
            {
                _buildingNameAcronym = value;
                OnPropertyChanged(nameof(BuildingNameAcronym));
            }
        }

        public int Floors
        {
            get => _floors;
            internal set
            {
                _floors = value;
                OnPropertyChanged(nameof(Floors));
            }
        }

        public int NumberOfRooms_PerFloor
        {
            get => _numberOfRooms_PerFloor;
            internal set
            {
                _numberOfRooms_PerFloor = value;
                OnPropertyChanged(nameof(NumberOfRooms_PerFloor));
            }
        }

        public BuildingViewModel(DataLayer.EFClasses.TC.Building building)
        {
            BuildingId = building.BuildingId;
            BuildingName = building.Building_Name;
            BuildingNameAcronym = building.BuildingNameAcronym;
            Floors = building.Floors;
            NumberOfRooms_PerFloor = building.NumberOfRooms_PerFloor;
        }

        public BuildingViewModel()
        {
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}