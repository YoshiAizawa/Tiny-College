﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Building
{
    public class RoomViewModel
    {
        public string RoomCode { get; set; }
        public string BuildingId { get; set; }

        public RoomViewModel(DataLayer.EFClasses.TC.Room room)
        {
            RoomCode = room.Room_Code;
            BuildingId = room.BuildingId; 
        }
    }
}
