﻿using System;
using System.Collections.Generic;
using System.Text;
using ServiceLayer;
using ServiceLayer.TC;

namespace WpfTinyCollege.ViewModels.TC.Building
{
    public class AddBuildingViewModel
    {
        private readonly BuildingService _buildingService;

        public AddBuildingViewModel(BuildingService buildingService)
        {
            _buildingService = buildingService;
        }

        public string BuildingName { get; set; }
        public string BuildingNameAcronym { get; set; }
        public int Floors { get; set; }
        public int NumberOfRooms_PerFloor { get; set; }

        public BuildingViewModel AssociatedBuilding { get; set; }

        public void Add()
        {
            var building = new DataLayer.EFClasses.TC.Building()
            {
                Building_Name = BuildingName,
                BuildingNameAcronym = BuildingNameAcronym,
                Floors = Floors,
                NumberOfRooms_PerFloor = NumberOfRooms_PerFloor
            };

            _buildingService.AddBuilding(building);

            AssociatedBuilding = new BuildingViewModel(building);
        }
    }
}
