﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLayer.EFClasses.TC;

namespace WpfTinyCollege.ViewModels.TC.Building
{
    public class BuildingRoomsViewModel
    {
        public string Room_Code { get; set; }
        public string RoomBuildingName { get; set; }
        public int NumberOfClasses { get; set; }

        public BuildingRoomsViewModel(DataLayer.EFClasses.TC.Room room)
        {
            Room_Code = room.Room_Code;
            if (room.BuildingLink == null)
            {
                RoomBuildingName = "Error";
            }
            else RoomBuildingName = room.BuildingLink.Building_Name;
            NumberOfClasses = room.Classes.Count();
        }
    }
}
