﻿using ServiceLayer;
using System.Collections.ObjectModel;
using System.Linq;
using DataLayer.EFClasses.Context;
using ServiceLayer.TC;

namespace WpfTinyCollege.ViewModels.TC.Building
{
    public class BuildingListViewModel
    {
        private readonly BuildingService _buildingService;
        private BuildingViewModel _selectedBuilding;

        public BuildingListViewModel(BuildingService buildingService)
        {
            _buildingService = buildingService;

            BuildingList = new ObservableCollection<BuildingViewModel>(
                _buildingService.GetBuildings().Select(c =>
                new BuildingViewModel(c))
            );
        }
        public BuildingViewModel SelectedBuilding
        {
            get => _selectedBuilding;
            set
            {
                _selectedBuilding = value;
                if (_selectedBuilding != null)
                    DisplayBuildingRooms(_selectedBuilding.BuildingId);
            }
        }

        public ObservableCollection<BuildingViewModel> BuildingList { get; set; }
        public ObservableCollection<BuildingRoomsViewModel> BuildingRoomsList { get; set; } = 
            new ObservableCollection<BuildingRoomsViewModel>();

        //Display


        public void DisplayBuildingRooms(string buildingId)
        {
            BuildingRoomsList.Clear();

            var rooms = new RoomService(new TinyCollegeContext()).GetBuildingRooms(buildingId)
                .Select(c=> new BuildingRoomsViewModel(c));

            foreach (var room in rooms)
                BuildingRoomsList.Add(room);
        }

        private string _searchText;

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchBuilding(_searchText);
            }
        }

        public void SearchBuilding(string searchString)
        {
            BuildingList.Clear();

            var Buildings = _buildingService.GetBuildings()
                .Where(c => c.Building_Name.Contains(searchString) ||
                c.BuildingNameAcronym.Contains(searchString) ||
                c.Floors.ToString().Contains(searchString) ||
                c.NumberOfRooms_PerFloor.ToString().Contains(searchString));

            foreach (var building in Buildings)
            {
                var BuildingModel = new BuildingViewModel(building);

                BuildingList.Add(BuildingModel);
            }
        }
    }
}