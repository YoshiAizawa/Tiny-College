﻿using System;
using System.Collections.Generic;
using System.Text;
using ServiceLayer.TC;
using WpfTinyCollege.ViewModels.TC.Building;
using WpfTinyCollege.Views.TC.Building;

namespace WpfTinyCollege.ViewModels.TC.Building
{
    public class EditBuildingViewModel
    {
        private readonly BuildingService _buildingService;

        public EditBuildingViewModel(BuildingViewModel buildingToEdit, BuildingService buildingService)
        {
            BuildingToEdit = buildingToEdit;
            _buildingService = buildingService;

            BuildingId = buildingToEdit.BuildingId;
            CopyEditableFields(buildingToEdit);
        }
         public BuildingViewModel BuildingToEdit { get; set; }
        private void CopyEditableFields(BuildingViewModel buildingToEdit)
        {
            BuildingName = buildingToEdit.BuildingName;
            BuildingNameAcronym = buildingToEdit.BuildingNameAcronym;
            Floors = buildingToEdit.Floors;
            NumberOfRooms_PerFloor = buildingToEdit.NumberOfRooms_PerFloor;
        }
        public string BuildingId { get; set; }
        public string BuildingName { get; set; }
        public string BuildingNameAcronym { get; set; }
        public int Floors { get; set; }
        public int NumberOfRooms_PerFloor { get; set; }

        public void Edit()
        {
            BuildingToEdit.BuildingName = BuildingName;
            BuildingToEdit.BuildingNameAcronym = BuildingNameAcronym;
            BuildingToEdit.Floors = Floors;
            BuildingToEdit.NumberOfRooms_PerFloor = NumberOfRooms_PerFloor;

            var newBuilding = new DataLayer.EFClasses.TC.Building
            {
                BuildingId = BuildingToEdit.BuildingId,
                Building_Name = BuildingToEdit.BuildingName,
                BuildingNameAcronym = BuildingToEdit.BuildingNameAcronym,
                Floors = BuildingToEdit.Floors,
                NumberOfRooms_PerFloor = BuildingToEdit.NumberOfRooms_PerFloor
            };

            

            _buildingService.UpdateBuilding(newBuilding);
        }
    }
}
