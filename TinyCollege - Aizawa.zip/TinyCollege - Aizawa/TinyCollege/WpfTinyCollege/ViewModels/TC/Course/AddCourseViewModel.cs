﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Department;

namespace WpfTinyCollege.ViewModels.TC.Course
{
    public class AddCourseViewModel
    {
        private readonly CourseService _courseService;
        private readonly DepartmentService _departmentService;

        public AddCourseViewModel(CourseService courseService, DepartmentService departmentService)
        {
            _courseService = courseService;
            _departmentService = departmentService;
            DepartmentList = new ObservableCollection<DepartmentViewModel>(
                _departmentService.GetDepartments().Select(c =>
                new DepartmentViewModel(c))
            );
        }

        public string CourseName { get; set; }
        public string DepartmentId { get; set; }
        public ObservableCollection<DepartmentViewModel> DepartmentList { get; set; }
        public DepartmentViewModel SelectedDepartment { get; set; }
        public CourseViewModel AssociatedCourse { get; set; }
        
        public void Add()
        {
            var course = new DataLayer.EFClasses.TC.Course()
            {
                Course_Name = CourseName,
                DepartmentId = SelectedDepartment.DepartmentId,
            };

            _courseService.AddCourse(course);

            AssociatedCourse = new CourseViewModel(course);
        }
    }
}
