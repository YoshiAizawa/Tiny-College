﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Course
{
    public class CourseListViewModel
    {
        private readonly CourseService _courseService;
        private CourseViewModel _selectedCourse;
        private string _searchText;

        public CourseListViewModel(CourseService courseService)
        {
            _courseService = courseService;

            CourseList = new ObservableCollection<CourseViewModel>(
                _courseService.GetCourses().Select(c =>
                new CourseViewModel(c))
            );
        }

        public ObservableCollection<CourseViewModel> CourseList { get; set; }
        public ObservableCollection<CourseClassesViewModel> CourseClassesList { get; set; } =
    new ObservableCollection<CourseClassesViewModel>();

        public CourseViewModel SelectedCourse
        {
            get => _selectedCourse;
            set
            {
                _selectedCourse = value;
                if (_selectedCourse != null)
                    DisplayCourseClasses(_selectedCourse.CourseId);

            }
        }

        private void DisplayCourseClasses(string courseId)
        {
            CourseClassesList.Clear();

            var classes = new ClassService(new TinyCollegeContext()).GetCourseClasses(courseId)
                .Select(c => new CourseClassesViewModel(c));

            foreach (var oneClass in classes)
                CourseClassesList.Add(oneClass);
        }

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchCourse(_searchText);
            }
        }

        public void SearchCourse(string searchString)
        {
            CourseList.Clear();

            var Courses = _courseService.GetCourses()
                .Where(c => c.Course_Name.Contains(searchString) ||
                c.CourseId.Contains(searchString) ||
                c.DepartmentLink.Dept_Name.Contains(searchString));

            foreach (var course in Courses)
            {
                var CourseModel = new CourseViewModel(course);

                CourseList.Add(CourseModel);
            }
        }
    }
}
