﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TC.Department;

namespace WpfTinyCollege.ViewModels.TC.Course
{
    public class EditCourseViewModel
    {
        private readonly CourseService _courseService;
        private readonly DepartmentService _departmentService;

        public EditCourseViewModel(CourseViewModel courseToEdit, CourseService courseService, DepartmentService departmentService)
        {
            CourseToEdit = courseToEdit;
            _courseService = courseService;
            _departmentService = departmentService;
            DepartmentList = new ObservableCollection<DepartmentViewModel>(
                _departmentService.GetDepartments().Select(c =>
                new DepartmentViewModel(c))
            );

            CourseId = CourseToEdit.CourseId;
            CopyEditableFields(CourseToEdit);
        }
        public CourseViewModel CourseToEdit { get; set; }
        private void CopyEditableFields(CourseViewModel courseToEdit)
        {
            CourseId = courseToEdit.CourseId;
            CourseName = courseToEdit.CourseName;
            DepartmentId = CourseToEdit.DepartmentId;
            //var Departments = new TinyCollegeContext().Departments.Where(c => c.DepartmentId == CourseToEdit.DepartmentId);
            //foreach (var Department in Departments)
            //{
            //    DepartmentName = Department.Dept_Name;
            //}
        }
        public string CourseId { get; set; }
        public string CourseName { get; set; }
        public string DepartmentId { get; set; }
        
        public ObservableCollection<DepartmentViewModel> DepartmentList { get; set; }
        public DepartmentViewModel SelectedDepartment { get; set; }

        public void Edit()
        {
            CourseToEdit.CourseId = CourseId;
            CourseToEdit.CourseName = CourseName;
            CourseToEdit.DepartmentId = DepartmentId;

            var newCourse = new DataLayer.EFClasses.TC.Course
            {
                CourseId = CourseToEdit.CourseId,
                Course_Name = CourseToEdit.CourseName,
                DepartmentId = CourseToEdit.DepartmentId,
            };

            _courseService.UpdateCourses(newCourse);
        }
    }
}
