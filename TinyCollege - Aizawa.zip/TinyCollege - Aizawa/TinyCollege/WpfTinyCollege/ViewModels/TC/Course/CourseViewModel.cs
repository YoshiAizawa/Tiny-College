﻿using Hangfire.Annotations;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TC.Course
{
    public class CourseViewModel : INotifyPropertyChanged
    {
        private string _courseId;
        private string _courseTitle;
        private string _departmentId;
        private string _nameOfDepartment;

        public string CourseId
        {
            get => _courseId;
            internal set
            {
                _courseId = value;
                OnPropertyChanged(nameof(CourseId));
            }
        }

        public string CourseName
        {
            get => _courseTitle;
            internal set
            {
                _courseTitle = value;
                OnPropertyChanged(nameof(CourseName));
            }
        }

        public string DepartmentId
        {
            get => _departmentId;
            internal set
            {
                _departmentId = value;
                OnPropertyChanged(nameof(DepartmentId));
            }
        }

        public string NameOfDepartment
        {
            get => _nameOfDepartment;
            internal set
            {
                _nameOfDepartment = value;
                OnPropertyChanged(nameof(NameOfDepartment));
            }
        }

        public string CourseIdName { get; set; }

        public CourseViewModel(DataLayer.EFClasses.TC.Course course)
        {
            CourseId = course.CourseId;
            CourseName = course.Course_Name;
            DepartmentId = course.DepartmentId;

            NameOfDepartment = course.DepartmentLink.Dept_Name;

            CourseIdName = $"{course.CourseId} - {course.Course_Name}";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}