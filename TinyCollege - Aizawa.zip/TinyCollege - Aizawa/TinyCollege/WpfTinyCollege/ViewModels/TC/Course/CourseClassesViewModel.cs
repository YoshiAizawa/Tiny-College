﻿using DataLayer.EFClasses.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TC.Course
{
    public class CourseClassesViewModel
    {
        public string ClassCode { get; set; }
        public string RoomLocation { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string DayAcronym { get; set; }
        public string ProfessorFullName { get; set; }
        public string CourseCode { get; set; }
        public string ClassDetail { get; set; }

        public CourseClassesViewModel(DataLayer.EFClasses.TC.Class oneClass)
        {
            CourseCode = oneClass.CourseId;
            var classes = new TinyCollegeContext().Classes
                .Where(c => c.CourseId == oneClass.CourseId);

            foreach (var soloClass in classes)
            {
                RoomLocation = soloClass.Room_Code;
            }
            ClassCode = oneClass.ClassId;
            StartTime = oneClass.ScheduleLink.StartTime.ToString("t");
            EndTime = oneClass.ScheduleLink.EndTime.ToString("t");
            DayAcronym = oneClass.ScheduleLink.DayName;
            ProfessorFullName = $"{oneClass.ProfessorLink.Pro_LastName}, {oneClass.ProfessorLink.Pro_FirstName} " +
                $"{oneClass.ProfessorLink.Pro_MiddleName.Substring(0, 1).ToUpper()}.";
            ClassDetail = $"{ProfessorFullName}, {StartTime} - {EndTime} {DayAcronym} {RoomLocation}";
        }
    }
}

