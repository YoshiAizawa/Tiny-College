﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TFBS.Vehicle
{
    public class VehicleListViewModel
    {
        private readonly VehicleService _vehicleService;
        private VehicleViewModel _selectedVehicle;

        public VehicleListViewModel(VehicleService VehicleService)
        {
            _vehicleService = VehicleService;

            VehicleList = new ObservableCollection<VehicleViewModel>(
                _vehicleService.GetVehicles().Select(c =>
                new VehicleViewModel(c))
            );
        }

        public ObservableCollection<VehicleViewModel> VehicleList { get; set; }
        public ObservableCollection<VehicleReservationViewModel> VehicleReservationsList { get; set; } =
            new ObservableCollection<VehicleReservationViewModel>();

        private string _searchText;

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchVehicle(_searchText);
            }
        }

        public VehicleViewModel SelectedVehicle
        {
            get => _selectedVehicle;
            set
            {
                _selectedVehicle = value;
                if (_selectedVehicle != null)
                    DisplayVehicleReservations(_selectedVehicle.VehicleId);
            }
        }

        public void SearchVehicle(string searchString)
        {
            VehicleList.Clear();


            var Vehicles = _vehicleService.GetVehicles()
                .Where(c => c.Vehicle_Type.Contains(searchString) ||
                            c.Available_Passenger.ToString().Contains(searchString));

            foreach (var vehicle in Vehicles)
            {
                var VehicleModel = new VehicleViewModel(vehicle);
                VehicleList.Add(VehicleModel);
            }
        }

        private void DisplayVehicleReservations(string VehicleId)
        {
            VehicleReservationsList.Clear();

            var Reservations = new ReservationService(new TinyCollegeContext()).GetVehicleReservations(VehicleId)
                .Select(c => new VehicleReservationViewModel(c));

            foreach (var reservation in Reservations)
                VehicleReservationsList.Add(reservation);
        }
    }
}
