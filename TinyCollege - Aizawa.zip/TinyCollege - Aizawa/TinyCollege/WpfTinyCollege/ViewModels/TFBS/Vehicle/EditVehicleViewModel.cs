﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Employee;

namespace WpfTinyCollege.ViewModels.TFBS.Vehicle
{
    public  class EditVehicleViewModel
    {
        private readonly VehicleService _vehicleService;

        public EditVehicleViewModel(VehicleViewModel vehicleToEdit, VehicleService vehicleService)
        {
            VehicleToEdit = vehicleToEdit;
            _vehicleService = vehicleService;
            VehicleId = vehicleToEdit.VehicleId;
            CopyEditableFields(vehicleToEdit);
        }
        public VehicleViewModel VehicleToEdit { get; set; }
        private void CopyEditableFields(VehicleViewModel vehicleToEdit)
        {
            VehicleType = vehicleToEdit.VehicleType;
            AvailablePassenger = vehicleToEdit.AvailablePassengers;
        }
        public string VehicleId { get; set; }
        public string VehicleType { get; set; }
        public int AvailablePassenger { get; set; }

        public void Edit()
        {
            VehicleToEdit.VehicleType = VehicleType;
            VehicleToEdit.AvailablePassengers = AvailablePassenger;

            var newVehicle = new DataLayer.EFClasses.TFBS.Vehicle()
            {
                VehicleId = VehicleToEdit.VehicleId,
                Vehicle_Type = VehicleToEdit.VehicleType,
                Available_Passenger = VehicleToEdit.AvailablePassengers,
            };

            _vehicleService.UpdateVehicle(newVehicle);
        }
    }
}
