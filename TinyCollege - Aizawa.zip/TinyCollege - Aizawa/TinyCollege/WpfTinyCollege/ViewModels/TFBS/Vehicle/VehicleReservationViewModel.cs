﻿using DataLayer.EFClasses.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TFBS.Vehicle
{
    public class VehicleReservationViewModel
    {
        public string ReservationId { get; set; }
        public string Destination { get; set; }
        public string DepartureDate { get; set; }
        public string CompletedReservation { get; set; }
        public string ProfessorFullname { get; set; }

        public VehicleReservationViewModel(DataLayer.EFClasses.TFBS.Reservation reservation)
        {
            ReservationId = reservation.ReservationId;
            Destination = reservation.Destination;
            DepartureDate = reservation.DepartureDate.ToString("MMMM dd, yyyy");
            ProfessorFullname = $"{reservation.ProfessorLink.Pro_LastName}, " +
                $"{reservation.ProfessorLink.Pro_FirstName} " +
                $"{reservation.ProfessorLink.Pro_MiddleName.Substring(0,1).ToUpper()}.";

            var completed = new TinyCollegeContext().Reservations
                .Where(c => c.ReservationId == reservation.ReservationId && c.ArrivalDate != null);

            if (completed.Count() != 0)
            {
                CompletedReservation = "Completed";
            }
            else CompletedReservation = "Ongoing";
        }
    }
}
