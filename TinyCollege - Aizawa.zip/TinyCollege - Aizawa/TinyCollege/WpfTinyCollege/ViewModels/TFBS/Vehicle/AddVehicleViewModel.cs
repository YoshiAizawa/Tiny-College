﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Employee;

namespace WpfTinyCollege.ViewModels.TFBS.Vehicle
{
    public class AddVehicleViewModel
    {
        private readonly VehicleService _vehicleService;

        public AddVehicleViewModel(VehicleService vehicleService)
        {
            _vehicleService = vehicleService;
        }

        public string VehicleType { get; set; }
        public string AvailablePassenger { get; set; }
        public VehicleViewModel AssociatedVehicle { get; set; }

        public void Add()
        {
            var vehicle = new DataLayer.EFClasses.TFBS.Vehicle()
            {
                Vehicle_Type = char.ToUpper(VehicleType[0]) + VehicleType.Substring(1),
                Available_Passenger = Convert.ToInt32(AvailablePassenger),
            };

            _vehicleService.AddVehicle(vehicle);

            AssociatedVehicle = new VehicleViewModel(vehicle);
        }
    }
}
