﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TFBS.Vehicle
{
    public class VehicleViewModel : INotifyPropertyChanged
    {
        private string _vehicleId;
        private string _vehicleType;
        private int _availablePassengers;
        private string _status;

        public string VehicleId
        {
            get => _vehicleId;
            internal set
            {
                _vehicleId = value;
                OnPropertyChanged(nameof(VehicleId));
            }
        }
        public string VehicleType
        {
            get => _vehicleType;
            internal set
            {
                _vehicleType = value;
                OnPropertyChanged(nameof(VehicleType));
            }
        }
        public int AvailablePassengers
        {
            get => _availablePassengers;
            internal set
            {
                _availablePassengers = value;
                OnPropertyChanged(nameof(AvailablePassengers));
            }
        }
        public string Status
        {
            get => _status;
            internal set
            {
                _status = value;
                OnPropertyChanged(nameof(Status));
            }
        }
        public string ReservationId { get; set; }
        public double? TravelledDistance { get; set; }

        public string VehicleIdType { get; set; }

        public VehicleViewModel(DataLayer.EFClasses.TFBS.Vehicle vehicle)
        {
            VehicleId = vehicle.VehicleId;
            VehicleType = vehicle.Vehicle_Type;
            AvailablePassengers = vehicle.Available_Passenger;

            VehicleIdType = $"({VehicleId})-{VehicleType}";

            var _context = new TinyCollegeContext();

            var reservations = _context.Reservations.Where(c => c.VehicleId == vehicle.VehicleId && c.ArrivalDate == null);

            if (reservations.Count() != 0)
            {
                Status = "In-use";
            }
            else Status = "Free";

            var completes = _context.Reservations.Where(c => c.VehicleId == vehicle.VehicleId);
            foreach (var complete in completes)
            {
                TravelledDistance += complete.TravelledDistance;
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}