﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TFBS.Employee
{
    public class EmployeeViewModel : INotifyPropertyChanged
    {
        private string _employeeId;
        private string _employeeFirstName;
        private string _employeeLastName;
        private string _employeeMiddleName;
        private string _employeeAddress;
        private string _employeeContactNumber;
        private string _employeeFullName;

        public string EmployeeId
        {
            get => _employeeId;
            internal set
            {
                _employeeId = value;
                OnPropertyChanged(nameof(EmployeeId));
            }
        }
        public string EmployeeFirstName
        {
            get => _employeeFirstName;
            internal set
            {
                _employeeFirstName = value;
                OnPropertyChanged(nameof(EmployeeFirstName));
            }
        }
        public string EmployeeLastName
        {
            get => _employeeLastName;
            internal set
            {
                _employeeLastName = value;
                OnPropertyChanged(nameof(EmployeeLastName));
            }
        }
        public string EmployeeMiddleName
        {
            get => _employeeMiddleName;
            internal set
            {
                _employeeMiddleName = value;
                OnPropertyChanged(nameof(EmployeeMiddleName));
            }
        }
        public string EmployeeAddress
        {
            get => _employeeAddress;
            internal set
            {
                _employeeAddress = value;
                OnPropertyChanged(nameof(EmployeeAddress));
            }
        }
        public string EmployeeContactNumber
        {
            get => _employeeContactNumber;
            internal set
            {
                _employeeContactNumber = value;
                OnPropertyChanged(nameof(EmployeeContactNumber));
            }
        }
        public string EmployeeFullName
        {
            get => _employeeFullName;
            internal set
            {
                _employeeFullName = value;
                OnPropertyChanged(nameof(EmployeeFullName));
            }
        }
        public string EmployeePartManager { get; set; }
        public string EmployeeMechanic { get; set; }
        public string EmployeeMechanicAuthorized { get; set; }
        public string PartManagerId { get; set; }
        public string MechanicId { get; set; }
        public string MechanicAuthorizedId { get; set; }


        public EmployeeViewModel(DataLayer.EFClasses.TFBS.Employee employee)
        {
            EmployeeId = employee.EmployeeId;
            EmployeeFirstName = employee.Emp_FirstName;
            EmployeeMiddleName = employee.Emp_MiddleName;
            EmployeeLastName = employee.Emp_Lastname;
            EmployeeAddress = employee.Emp_Address;
            EmployeeContactNumber = employee.Emp_ContactNumber;

            EmployeeFullName = $"{employee.Emp_Lastname}, {employee.Emp_FirstName} " +
                $"{employee.Emp_MiddleName.Substring(0, 1).ToUpper()}.";

            using var _context = new TinyCollegeContext();

            var mechanics = _context.Mechanics.Where(c => c.EmployeeId == employee.EmployeeId);
            if (mechanics.Count() != 0)
            {
                foreach (var mechanic in mechanics)
                {
                    if (mechanic.Mec_EndedDate == null)
                    {
                        MechanicId = mechanic.MechanicId;
                        EmployeeMechanic = "Active";
                    }
                }
            }

            var partManagers = _context.PartsManagers.Where(c => c.EmployeeId == employee.EmployeeId);
            if(partManagers.Count() != 0)
            {
                foreach(var partManager in partManagers)
                {
                    if(partManager.PartMgr_EndedDate == null)
                    {
                        PartManagerId = partManager.PartsManagerId;
                        EmployeePartManager = "Active";
                    }
                }
            }

        }


        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}