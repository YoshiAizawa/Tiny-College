﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using DataLayer.EFClasses.Context;
using Hangfire.Annotations;

namespace WpfTinyCollege.ViewModels.TFBS.Employee
{
    public class MechanicViewModel : INotifyPropertyChanged
    {
        private string _mechanicId;
        private string _mechanicFirstName;
        private string _mechanicLastName;
        private string _mechanicMiddleName;

        private string _mechanicFullName;

        private string _employeeId;

        public string MechanicId
        {
            get => _mechanicId;
            internal set
            {
                _mechanicId = value;
                OnPropertyChanged(nameof(MechanicId));
            }
        }
        public string MechanicFirstName
        {
            get => _mechanicFirstName;
            internal set
            {
                _mechanicFirstName = value;
                OnPropertyChanged(nameof(MechanicFirstName));
            }
        }
        public string MechanicLastName
        {
            get => _mechanicLastName;
            internal set
            {
                _mechanicLastName = value;
                OnPropertyChanged(nameof(MechanicLastName));
            }
        }
        public string MechanicMiddleName
        {
            get => _mechanicMiddleName;
            internal set
            {
                _mechanicMiddleName = value;
                OnPropertyChanged(nameof(MechanicMiddleName));
            }
        }
        public string MechanicFullName
        {
            get => _mechanicFullName;
            internal set
            {
                _mechanicFullName = value;
                OnPropertyChanged(nameof(MechanicFullName));
            }
        }

        public string EmployeeId
        {
            get => _employeeId;
            internal set
            {
                _employeeId = value;
                OnPropertyChanged(nameof(EmployeeId));
            }
        }

        public MechanicViewModel(DataLayer.EFClasses.TFBS.Mechanic mechanic)
        {
            MechanicId = mechanic.MechanicId;
            MechanicFirstName = mechanic.EmployeeLink.Emp_FirstName;
            MechanicMiddleName = mechanic.EmployeeLink.Emp_MiddleName;
            MechanicLastName = mechanic.EmployeeLink.Emp_Lastname;

            MechanicFullName = $"{mechanic.EmployeeLink.Emp_Lastname}, {mechanic.EmployeeLink.Emp_FirstName} " +
                               $"{mechanic.EmployeeLink.Emp_MiddleName[..1].ToUpper()}.";
        }


        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
