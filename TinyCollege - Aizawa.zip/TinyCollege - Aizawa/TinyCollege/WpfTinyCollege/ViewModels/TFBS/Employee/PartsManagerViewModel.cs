﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Hangfire.Annotations;

namespace WpfTinyCollege.ViewModels.TFBS.Employee
{
    public class PartsManagerViewModel : INotifyPropertyChanged
    {
        private string _partsManagerId;
        private string _partsManagerFirstName;
        private string _partsManagerLastName;
        private string _partsManagerMiddleName;

        private string _partsManagerFullName;

        private string _employeeId;

        public string PartsManagerId
        {
            get => _partsManagerId;
            internal set
            {
                _partsManagerId = value;
                OnPropertyChanged(nameof(PartsManagerId));
            }
        }
        public string PartsManagerFirstName
        {
            get => _partsManagerFirstName;
            internal set
            {
                _partsManagerFirstName = value;
                OnPropertyChanged(nameof(PartsManagerFirstName));
            }
        }
        public string PartsManagerLastName
        {
            get => _partsManagerLastName;
            internal set
            {
                _partsManagerLastName = value;
                OnPropertyChanged(nameof(PartsManagerLastName));
            }
        }
        public string PartsManagerMiddleName
        {
            get => _partsManagerMiddleName;
            internal set
            {
                _partsManagerMiddleName = value;
                OnPropertyChanged(nameof(PartsManagerMiddleName));
            }
        }
        public string PartsManagerFullName
        {
            get => _partsManagerFullName;
            internal set
            {
                _partsManagerFullName = value;
                OnPropertyChanged(nameof(PartsManagerFullName));
            }
        }

        public string EmployeeId
        {
            get => _employeeId;
            internal set
            {
                _employeeId = value;
                OnPropertyChanged(nameof(EmployeeId));
            }
        }

        public PartsManagerViewModel(DataLayer.EFClasses.TFBS.Parts_Manager partsManager)
        {
            PartsManagerId = partsManager.PartsManagerId;
            PartsManagerFirstName = partsManager.EmployeeLink.Emp_FirstName;
            PartsManagerMiddleName = partsManager.EmployeeLink.Emp_MiddleName;
            PartsManagerLastName = partsManager.EmployeeLink.Emp_Lastname;

            PartsManagerFullName = $"{partsManager.EmployeeLink.Emp_Lastname}, {partsManager.EmployeeLink.Emp_FirstName} " +
                               $"{partsManager.EmployeeLink.Emp_MiddleName[..1].ToUpper()}.";
        }


        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
