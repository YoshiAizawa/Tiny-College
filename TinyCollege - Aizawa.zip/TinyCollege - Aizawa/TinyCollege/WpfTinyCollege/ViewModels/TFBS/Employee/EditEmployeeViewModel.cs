﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.TFBS;

namespace WpfTinyCollege.ViewModels.TFBS.Employee
{
    public class EditEmployeeViewModel
    {
        private readonly EmployeeService _employeeService;

        public EditEmployeeViewModel(EmployeeViewModel employeeToEdit, EmployeeService employeeService)
        {
            EmployeeToEdit = employeeToEdit;
            _employeeService = employeeService;
            EmployeeId = employeeToEdit.EmployeeId;
            CopyEditableFields(employeeToEdit);
        }
        public EmployeeViewModel EmployeeToEdit { get; set; }
        private void CopyEditableFields(EmployeeViewModel employeeToEdit)
        {
            EmployeeFirstName = employeeToEdit.EmployeeFirstName;
            EmployeeMiddleName = employeeToEdit.EmployeeMiddleName;
            EmployeeLastName = employeeToEdit.EmployeeLastName;
            EmployeeAddress = employeeToEdit.EmployeeAddress;
            EmployeeContactNumber = employeeToEdit.EmployeeContactNumber;
        }
        public string EmployeeId { get; set; }
        public string EmployeeFirstName { get; set; }
        public string EmployeeMiddleName { get; set; }
        public string EmployeeLastName { get; set; }
        public string EmployeeAddress { get; set; }
        public string EmployeeContactNumber { get; set; }

        public void Edit(bool isMechanic, bool isPartsManager)
        {
            EmployeeToEdit.EmployeeFirstName = EmployeeFirstName;
            EmployeeToEdit.EmployeeMiddleName = EmployeeMiddleName;
            EmployeeToEdit.EmployeeLastName = EmployeeLastName;
            EmployeeToEdit.EmployeeAddress = EmployeeAddress;
            EmployeeToEdit.EmployeeContactNumber = EmployeeContactNumber;

            var newEmployee = new DataLayer.EFClasses.TFBS.Employee()
            {
                EmployeeId = EmployeeToEdit.EmployeeId,
                Emp_FirstName = EmployeeToEdit.EmployeeFirstName,
                Emp_MiddleName = EmployeeToEdit.EmployeeMiddleName,
                Emp_Lastname = EmployeeToEdit.EmployeeLastName,
                Emp_Address = EmployeeToEdit.EmployeeAddress,
                Emp_ContactNumber = EmployeeToEdit.EmployeeContactNumber,
            };

            _employeeService.UpdateEmployees(newEmployee, isMechanic, isPartsManager);
        }
    }
}
