﻿using ServiceLayer.TFBS;
using System;
using System.Collections.Generic;
using System.Text;
using DataLayer.EFClasses.Context;
using System.Collections.ObjectModel;
using System.Linq;

namespace WpfTinyCollege.ViewModels.TFBS.Employee
{
    public class AddEmployeeViewModel
    {
        private readonly EmployeeService _employeeService;

        public AddEmployeeViewModel(EmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        public string EmployeeFirstName { get; set; }
        public string EmployeeMiddleName { get; set; }
        public string EmployeeLastName { get; set; }
        public string EmployeeAddress { get; set; }
        public string EmployeeContactNumber { get; set; }
        public EmployeeViewModel AssociatedEmployee { get; set; }

        public void Add(bool isMechanic, bool isPartsManager)
        {
            var employee = new DataLayer.EFClasses.TFBS.Employee()
            {
                Emp_FirstName = char.ToUpper(EmployeeFirstName[0]) + EmployeeFirstName.Substring(1),
                Emp_Lastname = char.ToUpper(EmployeeLastName[0]) + EmployeeLastName.Substring(1),
                Emp_MiddleName = char.ToUpper(EmployeeMiddleName[0]) + EmployeeMiddleName.Substring(1),
                Emp_ContactNumber = EmployeeContactNumber,
                Emp_Address = char.ToUpper(EmployeeAddress[0]) + EmployeeAddress.Substring(1),
            };

            _employeeService.AddEmployee(employee, isMechanic, isPartsManager);

            AssociatedEmployee = new EmployeeViewModel(employee);
        }
    }
}
