﻿using ServiceLayer.TFBS;
using System.Collections.ObjectModel;
using System.Linq;
using DataLayer.EFClasses.Context;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media.Animation;
using DataLayer.EFClasses.TFBS;
using Microsoft.EntityFrameworkCore;

namespace WpfTinyCollege.ViewModels.TFBS.Employee
{
    public class EmployeeListViewModel
    {
        private readonly EmployeeService _employeeService;
#pragma warning disable CS0169 // The field 'EmployeeListViewModel._selectedEmployee' is never used
        private EmployeeViewModel _selectedEmployee;
#pragma warning restore CS0169 // The field 'EmployeeListViewModel._selectedEmployee' is never used
        //private string _searchText;

        public EmployeeListViewModel(EmployeeService EmployeeService)
        {
            _employeeService = EmployeeService;

            EmployeeList = new ObservableCollection<EmployeeViewModel>(
                _employeeService.GetEmployees().Select(c =>
                new EmployeeViewModel(c))
            );
        }

        public ObservableCollection<EmployeeViewModel> EmployeeList { get; set; }

        private string _searchText;

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchEmployee(_searchText);
            }
        }

        public void SearchEmployee(string searchString)
        {
            EmployeeList.Clear();

            if (searchString is "Mechanic" or "mechanic")
            {
                var Mechanics = new TinyCollegeContext().Mechanics.ToList();


                foreach (var EmployeeModel in Mechanics.Where(c => c.Mec_EndedDate == null)
                             .Select(mechanic => _employeeService.GetEmployees().Where(c => c.EmployeeId == mechanic.EmployeeId).ToList())
                             .SelectMany(Employees => Employees.Select(employee => new EmployeeViewModel(employee))))
                {
                    EmployeeList.Add(EmployeeModel);
                }
            }
            else if (searchString is "Parts Manager" or "Parts" or "Part" or "Manager" or "part" or "parts" or "manager")
            {
                var partsManagers = new TinyCollegeContext().PartsManagers.ToList();


                foreach (var EmployeeModel in partsManagers.Where(c => c.PartMgr_EndedDate == null)
                             .Select(partsManager => _employeeService.GetEmployees().Where(c => c.EmployeeId == partsManager.EmployeeId).ToList())
                             .SelectMany(Employees => Employees.Select(employee => new EmployeeViewModel(employee))))
                {
                    EmployeeList.Add(EmployeeModel);
                }
            }
            else
            {
                var Employees = _employeeService.GetEmployees()
                    .Where(c => c.Emp_FirstName.Contains(searchString) ||
                    c.Emp_Lastname.Contains(searchString) ||
                    c.Emp_MiddleName.Contains(searchString) ||
                    c.Emp_Address.Contains(searchString) ||
                    c.Emp_ContactNumber.Contains(searchString) ||
                    c.Emp_FirstName.Contains(searchString));

                foreach (var employee in Employees)
                {
                    var employeeModel = new EmployeeViewModel(employee);
                    EmployeeList.Add(employeeModel);
                }
            }
        }

        public EmployeeViewModel SelectedEmployee { get; set; }
    }
}
