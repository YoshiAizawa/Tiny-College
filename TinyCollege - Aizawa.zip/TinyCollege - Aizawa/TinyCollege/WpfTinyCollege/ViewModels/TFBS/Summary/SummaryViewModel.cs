﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using DataLayer.EFClasses.TC;
using DataLayer.EFClasses.TFBS;

namespace WpfTinyCollege.ViewModels.TFBS.Summary
{
    public class SummaryViewModel : INotifyPropertyChanged
    {

        private string _month;
        private string _year;
        private string _monthYear;

        public string Month
        {
            get => _month;
            set
            {
                _month = value;
                OnPropertyChanged(nameof(Month));
            }
        }
        
        public string Year
        {
            get => _year;
            set
            {
                _year = value;
                OnPropertyChanged(nameof(Year));
            }
        }

        public string MonthYear
        {
            get => _monthYear;
            set
            {
                _monthYear = value;
                OnPropertyChanged(nameof(MonthYear));
            }
        }


        public SummaryViewModel()
        {

        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}