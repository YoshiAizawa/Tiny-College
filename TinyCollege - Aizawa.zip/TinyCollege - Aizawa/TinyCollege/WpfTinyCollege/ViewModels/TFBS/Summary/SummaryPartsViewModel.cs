﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfTinyCollege.ViewModels.TFBS.Summary
{
    public class SummaryPartsViewModel
    {
        public string Description { get; set; }
        public string DateUsed { get; set; }

        public SummaryPartsViewModel(DataLayer.EFClasses.TFBS.Part part)
        {
            Description = part.Part_Description;

        }
    }
}
