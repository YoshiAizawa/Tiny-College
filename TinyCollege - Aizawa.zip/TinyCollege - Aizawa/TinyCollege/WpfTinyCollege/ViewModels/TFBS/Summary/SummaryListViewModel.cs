﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TFBS.Summary
{
    public class SummaryListViewModel
    {
        private readonly PartUsedService _summaryService;
        private SummaryViewModel _selectedSummary;
        //private string _searchText;

        public SummaryListViewModel(PartUsedService SummaryService)
        {
            _summaryService = SummaryService;

            SummaryList = new ObservableCollection<SummaryViewModel>(
                _summaryService.GetPartUsed().Select(c =>
                new SummaryViewModel())
            );
        }

        public ObservableCollection<SummaryViewModel> SummaryList { get; set; }
        public ObservableCollection<SummaryPartsViewModel> SummaryPartsList { get; set; } =
            new ObservableCollection<SummaryPartsViewModel>();

        //public string SearchText
        //{
        //    get => _searchText;
        //    set
        //    {
        //        _searchText = value;
        //        SearchSummary(_searchText);
        //    }
        //}

        public SummaryViewModel SelectedSummary
        {
            get => _selectedSummary;
            set
            {
                _selectedSummary = value;
            }
        }

        private void DisplaySummaryParts(string SummaryId)
        {
            SummaryPartsList.Clear();

            var Parts = new PartsService(new TinyCollegeContext()).GetSummaryParts(SummaryId)
                .Select(c => new SummaryPartsViewModel(c));

            foreach (var part in Parts)
                SummaryPartsList.Add(part);
        }
    }
}
