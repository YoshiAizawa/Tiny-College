﻿using System;
using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TFBS.Reservation
{
    public class ReservationViewModel : INotifyPropertyChanged
    {
        private string _reservationId;
        private string _professorFullName;
        private string _vehicleType;
        private string _departureDate;
        private string _destination;
        private string _completedReservation;
        private string _travelledDistance;
        private string _dateCompleted;
        private string _employeeFullName;

        //for completed reservation
        private string _completedReservationId;
        private string _maintenanceComplaints;

        public string CompletedReservationId
        {
            get => _completedReservationId;
            internal set
            {
                _completedReservationId = value;
                OnPropertyChanged(nameof(CompletedReservationId));
            }
        }//

        public string MaintenanceComplaints
        {
            get => _maintenanceComplaints;
            internal set
            {
                _maintenanceComplaints = value;
                OnPropertyChanged(nameof(MaintenanceComplaints));
            }
        }//
        public string TravelledDistance
        {
            get => _travelledDistance;
            internal set
            {
                _travelledDistance = value;
                OnPropertyChanged(nameof(TravelledDistance));
            }
        }

        public string ReservationId
        {
            get => _reservationId;
            internal set
            {
                _reservationId = value;
                OnPropertyChanged(nameof(ReservationId));
            }
        }//
        public string ProfessorFullName
        {
            get => _professorFullName;
            internal set
            {
                _professorFullName = value;
                OnPropertyChanged(nameof(ProfessorFullName));
            }
        }//
        public string VehicleType
        {
            get => _vehicleType;
            internal set
            {
                _vehicleType = value;
                OnPropertyChanged(nameof(VehicleType));
            }
        }//
        public string DepartureDate
        {
            get => _departureDate;
            internal set
            {
                _departureDate = value;
                OnPropertyChanged(nameof(DepartureDate));
            }
        }//
        public string Destination
        {
            get => _destination;
            internal set
            {
                _destination = value;
                OnPropertyChanged(nameof(Destination));
            }
        }//
        public string CompletedReservation
        {
            get => _completedReservation;
            internal set
            {
                _completedReservation = value;
                OnPropertyChanged(nameof(CompletedReservation));
            }
        }

        public string DateCompleted
        {
            get => _dateCompleted;
            internal set
            {
                _dateCompleted = value;
                OnPropertyChanged(nameof(DateCompleted));
            }
        }
        public string EmployeeFullName
        {
            get => _employeeFullName;
            internal set
            {
                _employeeFullName = value;
                OnPropertyChanged(nameof(EmployeeFullName));
            }
        }
        public int Passengers { get; set; }
        public string VehicleId { get; set; }
        public string ProfessorId { get; set; }

        public ReservationViewModel(DataLayer.EFClasses.TFBS.Reservation reservation)
        {
            ReservationId = reservation.ReservationId;
            DepartureDate = Convert.ToDateTime(reservation.DepartureDate).ToString("MM/dd/yyyy");
            Destination = reservation.Destination;
            if (reservation.VehicleLink != null)
            {
                VehicleId = reservation.VehicleId;
                Passengers = reservation.VehicleLink.Available_Passenger;
                VehicleType = reservation.VehicleLink.Vehicle_Type;
            }

            if (reservation.ProfessorLink != null)
            {
                ProfessorFullName =
                    $"{reservation.ProfessorLink.Pro_LastName}, {reservation.ProfessorLink.Pro_FirstName} " +
                    $"{reservation.ProfessorLink.Pro_MiddleName.Substring(0, 1).ToUpper()}.";
            }

            if (reservation.ArrivalDate != null)
            {
                CompletedReservation = "Completed";
                MaintenanceComplaints = reservation.MaintenanceComplaints;
                TravelledDistance = $"{reservation.TravelledDistance.ToString()}Km";
                DateCompleted = reservation.ArrivalDate != null ? reservation.ArrivalDate.Value.ToString("MMMM dd, yyyy") : "n/a"; 
                if (reservation.EmployeeLink != null)
                {
                    EmployeeFullName = $"{reservation.EmployeeLink.Emp_Lastname}, " +
                                       $"{reservation.EmployeeLink.Emp_FirstName} " +
                                       $"{reservation.EmployeeLink.Emp_MiddleName.Substring(0, 1).ToUpper()}.";
                }
            }
            else CompletedReservation = "Ongoing";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}