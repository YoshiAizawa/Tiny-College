﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TFBS.Reservation
{
    public class ReservationListViewModel
    {
        private readonly ReservationService _reservationService;
        private ReservationViewModel _selectedReservation;
        private string _searchText;

        public ReservationListViewModel(ReservationService ReservationService)
        {
            _reservationService = ReservationService;

            ReservationList = new ObservableCollection<ReservationViewModel>(
                _reservationService.GetReservations().Select(c =>
                new ReservationViewModel(c))
            );
        }

        public ObservableCollection<ReservationViewModel> ReservationList { get; set; }
        public ObservableCollection<ReservationReceiptsViewModel> ReservationReceiptsList { get; set; } =
            new ObservableCollection<ReservationReceiptsViewModel>();

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchReservation(_searchText);
            }
        }

        public void SearchReservation(string searchString)
        {
            ReservationList.Clear();


            var Reservations = _reservationService.GetReservations()
                .Where(c => c.ReservationId.Contains(searchString) ||
                            c.ArrivalDate.ToString().Contains(searchString) ||
                            c.DepartureDate.ToString().Contains(searchString) ||
                            c.Destination.Contains(searchString) ||
                            c.TravelledDistance.ToString().Contains(searchString) ||
                            c.VehicleLink.Vehicle_Type.Contains(searchString));

            foreach (var reservation in Reservations)
            {
                var reservationModel = new ReservationViewModel(reservation);
                ReservationList.Add(reservationModel);
            }
        }

        public ReservationViewModel SelectedReservation
        {
            get => _selectedReservation;
            set
            {
                _selectedReservation = value;
                if (_selectedReservation != null)
                    DisplayReservationReceipts(_selectedReservation.ReservationId);
            }
        }

        private void DisplayReservationReceipts(string reservationId)
        {
            ReservationReceiptsList.Clear();

            var Receipts = new ReceiptService(new TinyCollegeContext()).GetReservationReceipts(reservationId)
                .Select(c => new ReservationReceiptsViewModel(c));

            foreach (var receipt in Receipts)
                ReservationReceiptsList.Add(receipt);
        }
    }
}
