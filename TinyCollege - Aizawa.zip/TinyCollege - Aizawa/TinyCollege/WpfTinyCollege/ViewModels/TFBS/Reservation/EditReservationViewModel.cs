﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.TC;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TC.Department;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.ViewModels.TFBS.Reservation
{
    public class EditReservationViewModel
    {
        private readonly ReservationService _reservationService;
        private readonly VehicleService _vehicleService;
        private readonly ProfessorService _professorService;

        public EditReservationViewModel(ReservationViewModel reservationToEdit, ReservationService reservationService, VehicleService vehicleService, ProfessorService professorService)
        {
            ReservationToEdit = reservationToEdit;
            _reservationService = reservationService;
            _vehicleService = vehicleService;
            _professorService = professorService;

            ProfessorList = new ObservableCollection<ProfessorViewModel>(
                _professorService.GetProfessors().Select(c =>
                    new ProfessorViewModel(c)));

            VehicleList = new ObservableCollection<VehicleViewModel>(
                _vehicleService.GetVehicles().Select(c =>
                    new VehicleViewModel(c)));

            ReservationId = reservationToEdit.ReservationId;
            CopyEditableFields(reservationToEdit);
        }
        public ReservationViewModel ReservationToEdit { get; set; }
        public ProfessorViewModel SelectedProfessor { get; set; }
        public VehicleViewModel SelectedVehicle { get; set; }
        private void CopyEditableFields(ReservationViewModel reservationToEdit)
        {
            Destination = reservationToEdit.Destination;
            DepartureDate = Convert.ToDateTime(reservationToEdit.DepartureDate);
            VehicleType = reservationToEdit.VehicleType;
            ProfessorFullName = reservationToEdit.ProfessorFullName;
        }
        public string ReservationId { get; set; }
        public string Destination { get; set; }
        public DateTime DepartureDate { get; set; }
        public string VehicleType { get; set; }
        public string ProfessorFullName { get; set; }
        public string VehicleId { get; set; }
        public string ProfessorId { get; set; }
        public ObservableCollection<ProfessorViewModel> ProfessorList { get; set; }
        public ObservableCollection<VehicleViewModel> VehicleList { get; set; }

        public void Edit(bool vehicleChange, bool profChange)
        {
            ReservationToEdit.Destination = Destination;
            ReservationToEdit.DepartureDate = DepartureDate.ToString("MM/dd/yyyy");
            if (vehicleChange)
            {
                ReservationToEdit.VehicleId = SelectedVehicle.VehicleId;
            }
            else
            {
                ReservationToEdit.VehicleId = VehicleId;
            }
            if (profChange)
            {
                ReservationToEdit.ProfessorId = SelectedProfessor.ProfessorId;
            }
            else
            {
                ReservationToEdit.ProfessorId = ProfessorId;
            }

            var newReservation = new DataLayer.EFClasses.TFBS.Reservation()
            {
                ReservationId = ReservationToEdit.ReservationId,
                Destination = ReservationToEdit.Destination,
                DepartureDate = Convert.ToDateTime(ReservationToEdit.DepartureDate),
                VehicleId = ReservationToEdit.VehicleId,
                ProfessorId = ReservationToEdit.ProfessorId,
            };

            _reservationService.UpdateReservations(newReservation);
        }
    }
}
