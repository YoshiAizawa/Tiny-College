﻿using DataLayer.EFClasses.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TFBS.Reservation
{
    public class ReservationReceiptsViewModel
    {
        public string ReceiptFuelId { get; set; }
        public string FuelType { get; set; }
        public double Cost { get; set; }
        public double Gallons_of_Fuel { get; set; }
        public string Card_Number { get; set; }
        public ReservationReceiptsViewModel(DataLayer.EFClasses.TFBS.Receipt_Fuel receipt)
        {
            ReceiptFuelId = receipt.ReceiptFuelId;
            FuelType = receipt.FuelType;
            Cost = receipt.Cost;
            Gallons_of_Fuel = receipt.Gallons_of_Fuel;
            Card_Number = receipt.CardNumber;
        }
    }
}
