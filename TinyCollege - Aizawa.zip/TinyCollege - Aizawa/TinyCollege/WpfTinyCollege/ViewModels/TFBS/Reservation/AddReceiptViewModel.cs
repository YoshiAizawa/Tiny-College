﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.EFClasses.Context;
using DataLayer.EFClasses.TFBS;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Employee;

namespace WpfTinyCollege.ViewModels.TFBS.Reservation
{
    public class AddReceiptViewModel
    {
        private ReservationService _reservationService;

        public AddReceiptViewModel(ReservationViewModel reservationReceipt, ReservationService reservationService)
        {
            ReservationReceipt = reservationReceipt;
            _reservationService = reservationService;
        }

        public ReservationViewModel ReservationReceipt { get; set; }
        public string FuelType { get; set; }
        public double Cost { get; set; }
        public double Gallons { get; set; }
        public string CardNumber { get; set; }
        public ReservationViewModel AssociatedReservation { get; set; }
        public string Destination { get; set; }

        public void Add()
        {
            var receipt = new DataLayer.EFClasses.TFBS.Receipt_Fuel()
            {
                FuelType = char.ToUpper(FuelType[0]) + FuelType.Substring(1),
                Cost = Cost,
                Gallons_of_Fuel = Gallons,
                CardNumber = CardNumber,
                ReservationId = ReservationReceipt.ReservationId,
            };

            _reservationService.AddReceipt(receipt);

            var reservations =
                new TinyCollegeContext().Reservations.Where(c => c.ReservationId == receipt.ReservationLink.ReservationId);
            foreach (var reservation in reservations)
            {
                AssociatedReservation = new ReservationViewModel(reservation);
            }
        }


    }
}
