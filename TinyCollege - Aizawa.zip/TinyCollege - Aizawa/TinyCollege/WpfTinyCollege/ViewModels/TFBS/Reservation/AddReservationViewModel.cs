﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.TC;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.ViewModels.TFBS.Reservation
{
    public class AddReservationViewModel
    {
        private readonly ReservationService _reservationService;
        private readonly VehicleService _vehicleService;
        private readonly ProfessorService _professorService;

        public AddReservationViewModel(ReservationService reservationService, VehicleService vehicleService, ProfessorService professorService)
        {
            _reservationService = reservationService;

            _professorService = professorService;


            ProfessorList = new ObservableCollection<ProfessorViewModel>(
                _professorService.GetProfessors().OrderBy(c=>c.Pro_LastName)
                    .Select(c => new ProfessorViewModel(c)));

            _vehicleService = vehicleService;
            VehicleList = new ObservableCollection<VehicleViewModel>(
                _vehicleService.GetVehicles().OrderBy(c=>c.Vehicle_Type)
                    .Select(c => new VehicleViewModel(c)));
        }

        public string Destination { get; set; }
        public DateTime DepartureDate { get; set; }
        public string VehicleId { get; set; }
        public string ProfessorId { get; set; }
        public ObservableCollection<ProfessorViewModel> ProfessorList { get; set; }
        public ObservableCollection<VehicleViewModel> VehicleList { get; set; }
        public ProfessorViewModel SelectedProfessor { get; set; }
        public VehicleViewModel SelectedVehicle { get; set; }
        public ReservationViewModel AssociatedReservation { get; set; }


        public void Add()
        {
            var reservation = new DataLayer.EFClasses.TFBS.Reservation()
            {
                Destination = char.ToUpper(Destination[0]) + Destination.Substring(1),
                DepartureDate = DepartureDate,
                ProfessorId = SelectedProfessor.ProfessorId,
                VehicleId = SelectedVehicle.VehicleId,
            };

            _reservationService.AddReservation(reservation);

            AssociatedReservation = new ReservationViewModel(reservation);
        }
    }
}
