﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TFBS.Employee;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.ViewModels.TFBS.Reservation
{
    public class AddCompleteReservationViewModel
    {
        private readonly ReservationService _reservationService;
        private readonly ProfessorService _professorService;
        private readonly VehicleService _vehicleService;
        private readonly EmployeeService _employeeService;

        public AddCompleteReservationViewModel(ReservationViewModel reservationToComplete, ReservationService reservationService, ProfessorService professorService, VehicleService vehicleService, EmployeeService employeeService)
        {
            ReservationToComplete = reservationToComplete;
            _reservationService = reservationService;
            _professorService = professorService;
            _vehicleService = vehicleService;
            _employeeService = employeeService;


            EmployeeList = new ObservableCollection<EmployeeViewModel>(
                _employeeService.GetEmployees().OrderBy(c => c.Emp_Lastname)
                    .Select(c => new EmployeeViewModel(c)));

            ReservationId = reservationToComplete.ReservationId;
        }
        public ReservationViewModel ReservationToComplete { get; set; }
        public string MaintenanceComplaint{ get; set; }
        public DateTime CompletedDate { get; set; }
        public string TravelledDistance { get; set; }
        public string EmployeeId { get; set; }
        public string ReservationId { get; set; }
        public EmployeeViewModel SelectedEmployee { get; set; }
        public ObservableCollection<EmployeeViewModel> EmployeeList { get; set; }
        public ObservableCollection<ProfessorViewModel> ProfessorList { get; set; }
        public ObservableCollection<VehicleViewModel> VehicleList { get; set; }
        public ObservableCollection<ReservationViewModel> ReservationList { get; set; }
        public ReservationViewModel AssociatedReservation { get; set; }


        public void Add()
        {
            var completeReservation = new DataLayer.EFClasses.TFBS.Reservation()
            {
                MaintenanceComplaints = MaintenanceComplaint,
                ArrivalDate = CompletedDate,
                TravelledDistance = Convert.ToDouble(TravelledDistance),
                EmployeeId = SelectedEmployee.EmployeeId,
                ReservationId = ReservationToComplete.ReservationId,
            };

            _reservationService.AddCompleteReservation(completeReservation);

            var reservations =
                new TinyCollegeContext().Reservations.Where(c => c.ReservationId == completeReservation.ReservationId);
            foreach (var reservation in reservations)
            {
                AssociatedReservation = new ReservationViewModel(reservation);
            }

            
        }
    }
}
