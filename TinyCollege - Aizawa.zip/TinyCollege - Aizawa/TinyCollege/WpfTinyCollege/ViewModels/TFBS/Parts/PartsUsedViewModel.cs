﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfTinyCollege.ViewModels.TFBS.Parts
{
    public class PartsUsedViewModel
    {
        public string Description { get; set; }
        public string PartManagerFullName { get; set; }
        public int QuantityUsed { get; set; }
        public string PartUsedDate { get; set; }

        public PartsUsedViewModel(DataLayer.EFClasses.TFBS.Part_Used partUsed)
        {
            QuantityUsed = partUsed.PartQuantity;
            PartUsedDate = partUsed.PartUsed_Date.ToString("MMMM dd, yyyy");
            PartManagerFullName = $"{partUsed.PartsManagerLink.EmployeeLink.Emp_Lastname}, " +
                        $"{partUsed.PartsManagerLink.EmployeeLink.Emp_FirstName} " +
                        $"{partUsed.PartsManagerLink.EmployeeLink.Emp_MiddleName.Substring(0, 1).ToUpper()}.";
            Description = partUsed.PartLink.Part_Description;
        }
    }
}
