﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TFBS.Parts
{
    public class PartsViewModel : INotifyPropertyChanged
    {
        private string _partId;
        private string _partDescription;
        private int _partQuantity;
        private int _partMinimum;


        public string PartId
        {
            get => _partId;
            internal set
            {
                _partId = value;
                OnPropertyChanged(nameof(PartId));
            }
        }
        public string PartDescription
        {
            get => _partDescription;
            internal set
            {
                _partDescription = value;
                OnPropertyChanged(nameof(PartDescription));
            }
        }
        public int PartQuantity
        {
            get => _partQuantity;
            internal set
            {
                _partQuantity = value;
                OnPropertyChanged(nameof(PartQuantity));
            }
        }
        public int PartMinimum
        {
            get => _partMinimum;
            internal set
            {
                _partMinimum = value;
                OnPropertyChanged(nameof(PartMinimum));
            }
        }

        public string PartIdDescription { get; set; }

        public PartsViewModel(DataLayer.EFClasses.TFBS.Part part)
        {
            PartId = part.PartId;
            PartDescription = part.Part_Description;
            PartQuantity = part.Part_Quantity;
            PartMinimum = part.Part_Minimum_Quantity;

            PartIdDescription = $"{part.PartId} - {part.Part_Description}";
        }


        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}