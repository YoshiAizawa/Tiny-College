﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.ViewModels.TFBS.Parts
{
    public class AddPartsViewModel
    {
        private readonly PartsService _partsService;

        public AddPartsViewModel(PartsService partsService)
        {
            _partsService = partsService;
        }

        public string PartDescription { get; set; }
        public int PartQuantity { get; set; }
        public int PartMinimum { get; set; }
        public PartsViewModel AssociatedParts { get; set; }

        public void Add()
        {
            var part = new DataLayer.EFClasses.TFBS.Part()
            {
                Part_Description = char.ToUpper(PartDescription[0]) + PartDescription.Substring(1),
                Part_Quantity = Convert.ToInt32(PartQuantity),
                Part_Minimum_Quantity = Convert.ToInt32(PartMinimum),
            };

            _partsService.AddPart(part);

            AssociatedParts = new PartsViewModel(part);
        }
    }
}
