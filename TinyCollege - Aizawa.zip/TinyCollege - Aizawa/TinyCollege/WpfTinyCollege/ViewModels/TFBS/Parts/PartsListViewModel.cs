﻿using ServiceLayer.TFBS;
using DataLayer.EFClasses.Context;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace WpfTinyCollege.ViewModels.TFBS.Parts
{
    public class PartsListViewModel
    {
        private readonly PartsService _partService;
        private PartsViewModel _selectedParts;
        //private string _searchText;

        public PartsListViewModel(PartsService PartsService)
        {
            _partService = PartsService;

            PartsList = new ObservableCollection<PartsViewModel>(
                _partService.GetParts().Select(c =>
                new PartsViewModel(c))
            );
        }

        private string _searchText;

        public ObservableCollection<PartsViewModel> PartsList { get; set; }
        public ObservableCollection<PartsUsedViewModel> PartsUsedList { get; set; } =
            new ObservableCollection<PartsUsedViewModel>();

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                SearchPart(_searchText);
            }
        }

        public void SearchPart(string searchString)
        {
            PartsList.Clear();


            var Parts = _partService.GetParts()
                .Where(c => c.Part_Description.Contains(searchString) ||
                            c.Part_Quantity.ToString().Contains(searchString) ||
                            c.Part_Minimum_Quantity.ToString().Contains((searchString)));

            foreach (var part in Parts)
            {
                var partModel = new PartsViewModel(part);
                PartsList.Add(partModel);
            }
        }

        public PartsViewModel SelectedPart
        {
            get => _selectedParts;
            set
            {
                _selectedParts = value;
                if (_selectedParts != null)
                    DisplayPartsUsed(_selectedParts.PartId);
            }
        }

        private void DisplayPartsUsed(string PartsId)
        {
            PartsUsedList.Clear();

            var Used = new PartUsedService(new TinyCollegeContext()).GetPartsUsed(PartsId)
                .Select(c => new PartsUsedViewModel(c));

            foreach (var use in Used)
                PartsUsedList.Add(use);
        }
    }
}
