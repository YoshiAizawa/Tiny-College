﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.ViewModels.TFBS.Parts
{
    public class EditPartsViewModel
    {
        private readonly PartsService _partsService;

        public EditPartsViewModel(PartsViewModel partsToEdit, PartsService partsService)
        {
            this.PartsToEdit = partsToEdit;
            _partsService = partsService;
            PartId = partsToEdit.PartId;
            CopyEditableFields(partsToEdit);
        }
        public PartsViewModel PartsToEdit { get; set; }
        private void CopyEditableFields(PartsViewModel vehicleToEdit)
        {

            PartDescription = vehicleToEdit.PartDescription;
            PartQuantity = vehicleToEdit.PartQuantity;
            PartMinimum = vehicleToEdit.PartMinimum;
        }
        public string PartId { get; set; }
        public string PartDescription { get; set; }
        public int PartQuantity { get; set; }
        public int PartMinimum { get; set; }

        public void Edit()
        {
            PartsToEdit.PartDescription = PartDescription;
            PartsToEdit.PartQuantity = PartQuantity;
            PartsToEdit.PartMinimum = PartMinimum;

            var newParts = new DataLayer.EFClasses.TFBS.Part()
            {
                PartId = PartsToEdit.PartId,
                Part_Description = PartsToEdit.PartDescription,
                Part_Quantity= PartsToEdit.PartQuantity,
                Part_Minimum_Quantity = PartsToEdit.PartMinimum,
            };

            _partsService.UpdateParts(newParts);
        }
    }
}
