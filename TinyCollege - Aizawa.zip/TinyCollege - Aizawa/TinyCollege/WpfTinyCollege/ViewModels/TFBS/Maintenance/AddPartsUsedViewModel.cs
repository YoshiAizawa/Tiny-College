﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Employee;
using WpfTinyCollege.ViewModels.TFBS.Parts;
using WpfTinyCollege.ViewModels.TFBS.Reservation;

namespace WpfTinyCollege.ViewModels.TFBS.Maintenance
{
    public class AddPartsUsedViewModel
    {
        private MaintenanceService _maintenanceService;
        private PartUsedService _partUsedService;
        private PartsService _partsService;
        private PartManagerService _partManagerService;

        public AddPartsUsedViewModel(MaintenanceViewModel maintenancePartsUsed, MaintenanceService maintenanceService, PartUsedService partUsedService, PartsService partsService, PartManagerService partManagerService)
        {
            MaintenancePartsUsed = maintenancePartsUsed;

            _maintenanceService = maintenanceService;
            _partUsedService = partUsedService;
            _partsService = partsService;
            _partManagerService = partManagerService;

            PartsList = new ObservableCollection<PartsViewModel>(_partsService.GetParts()
                .OrderBy(c => c.PartId)
                .Select(c => new PartsViewModel(c)));

            PartsManagerList = new ObservableCollection<PartsManagerViewModel>(_partManagerService.GetPartManagers()
                .OrderBy(c => c.PartsManagerId)
                .Select(c => new PartsManagerViewModel(c)));
        }

        public MaintenanceViewModel MaintenancePartsUsed { get; set; }
        public ObservableCollection<PartsViewModel> PartsList { get; set; }
        public ObservableCollection<PartsManagerViewModel> PartsManagerList { get; set; }
        public int QuantityUsed { get; set; }
        public DateTime UsedDate { get; set; }
        public MaintenanceViewModel AssociatedMaintenance { get; set; }
        public PartsViewModel SelectedParts { get; set; }
        public PartsManagerViewModel SelectedPartsManager { get; set; }

        public void Add()
        {
            var partUsed = new DataLayer.EFClasses.TFBS.Part_Used()
            {
                PartQuantity = QuantityUsed,
                PartUsed_Date = UsedDate,

                PartId = SelectedParts.PartId,
                PartsManagerId = SelectedPartsManager.PartsManagerId,
                MaintenanceId = MaintenancePartsUsed.MaintenanceId,
            };

            _partUsedService.AddPartUsed(partUsed);

            var maintenances =
                new TinyCollegeContext().Maintenances.Where(c => c.MaintenanceId == partUsed.MaintenanceId);
            foreach (var maintenance in maintenances)
            {
                AssociatedMaintenance = new MaintenanceViewModel(maintenance);
            }
        }
    }
}
