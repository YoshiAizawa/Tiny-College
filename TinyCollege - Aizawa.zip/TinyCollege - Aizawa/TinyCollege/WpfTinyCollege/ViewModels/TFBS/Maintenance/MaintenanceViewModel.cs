﻿using DataLayer.EFClasses.Context;
using Hangfire.Annotations;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfTinyCollege.ViewModels.TFBS.Maintenance
{
    public class MaintenanceViewModel : INotifyPropertyChanged
    {
        private string _maintenanceId;
        private string _maintenanceEntryDate;
        private string _maintenanceCompletedDate;
        private string _details;
        private string _maintenanceCompleted;
        private string _mechanicFullName;
        private string _partsManagerFullName;



        public string MaintenanceId
        {
            get => _maintenanceId;
            internal set
            {
                _maintenanceId = value;
                OnPropertyChanged(nameof(MaintenanceId));
            }
        }
        public string MaintenanceEntryDate
        {
            get => _maintenanceEntryDate;
            internal set
            {
                _maintenanceEntryDate = value;
                OnPropertyChanged(nameof(MaintenanceEntryDate));
            }
        }
        public string Details
        {
            get => _details;
            internal set
            {
                _details = value;
                OnPropertyChanged(nameof(Details));
            }
        }
        public string MaintenanceCompleted
        {
            get => _maintenanceCompleted;
            internal set
            {
                _maintenanceCompleted = value;
                OnPropertyChanged(nameof(MaintenanceCompleted));
            }
        }
        public string MaintenanceCompletedDate
        {
            get => _maintenanceCompletedDate;
            internal set
            {
                _maintenanceCompletedDate = value;
                OnPropertyChanged(nameof(MaintenanceCompletedDate));
            }
        }
        public string MechanicFullName
        {
            get => _mechanicFullName;
            internal set
            {
                _mechanicFullName = value;
                OnPropertyChanged(nameof(MechanicFullName));
            }
        }

        public string PartsManagerFullName
        {
            get => _partsManagerFullName;
            internal set
            {
                _partsManagerFullName = value;
                OnPropertyChanged(nameof(PartsManagerFullName));
            }
        }

        public string MechanicId { get; set; }
        public string VehicleId { get; set; }
        public string VehicleType { get; set; }
        public string VehicleIdType { get; set; }
        public string IdSort { get; set; }

        public MaintenanceViewModel(DataLayer.EFClasses.TFBS.Maintenance maintenance)
        {
            MaintenanceId = maintenance.MaintenanceId;
            var sort = MaintenanceId.Split("-");
            IdSort = sort[1];

            MaintenanceEntryDate = maintenance.Maintenance_EntryDate.ToString("MMMM dd, yyyy");
            Details = maintenance.Details;
            
            //MaintenanceComplaints = maintenance.VehicleLink. NOTE: try to link up to the maintenance complaints of completed_reservation entity

            if (maintenance.VehicleLink != null)
            {
                VehicleId = maintenance.VehicleId;
                VehicleType = maintenance.VehicleLink.Vehicle_Type;
            }

            if (maintenance.MechanicLink != null)
            {
                MechanicId = maintenance.MechanicId;
                if (maintenance.MechanicLink.EmployeeLink != null)
                {
                    MechanicFullName = $"{maintenance.MechanicLink.EmployeeLink.Emp_Lastname}, " +
                                       $"{maintenance.MechanicLink.EmployeeLink.Emp_FirstName} " +
                                       $"{maintenance.MechanicLink.EmployeeLink.Emp_MiddleName.Substring(0, 1).ToUpper()}.";
                }
            }

            if (maintenance.Maintenance_CompletedDate != null)
            {
                MaintenanceCompleted = "Completed";

                MaintenanceCompletedDate = 
                    maintenance.Maintenance_CompletedDate != null ? maintenance.Maintenance_CompletedDate.Value.ToString("MMMM dd, yyyy") : "n/a";
            }
            else
            {
                MaintenanceCompleted = "Ongoing";
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        [NotifyPropertyChangedInvocator]

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}