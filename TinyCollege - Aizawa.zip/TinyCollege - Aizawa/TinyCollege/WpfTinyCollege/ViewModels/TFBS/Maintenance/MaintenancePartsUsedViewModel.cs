﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTinyCollege.ViewModels.TFBS.Maintenance
{
    public class MaintenancePartsUsedViewModel
    {
        public string PartUsedId { get; set; }
        public string Part_Description { get; set; }
        public int PartQuantity { get; set; }
        public string Part_UsedDate { get; set; }
        public string PartsManagerFullname { get; set; }

        public MaintenancePartsUsedViewModel(DataLayer.EFClasses.TFBS.Part_Used partUsed)
        {
            PartUsedId = partUsed.PartUsedId;
            PartQuantity = partUsed.PartQuantity;
            Part_UsedDate = partUsed.PartUsed_Date.ToString("MMMM dd, yyyy");

            if (partUsed.PartLink != null)
            {
                Part_Description = partUsed.PartLink.Part_Description;
            }

            if (partUsed.PartsManagerLink?.EmployeeLink != null)
            {
                PartsManagerFullname = $"{partUsed.PartsManagerLink.EmployeeLink.Emp_Lastname}, " +
                                       $"{partUsed.PartsManagerLink.EmployeeLink.Emp_FirstName} " +
                                       $"{partUsed.PartsManagerLink.EmployeeLink.Emp_MiddleName.Substring(0, 1).ToUpper()}.";
            }


        }
    }
}
