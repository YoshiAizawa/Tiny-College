﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ServiceLayer.TC;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TFBS.Employee;
using WpfTinyCollege.ViewModels.TFBS.Reservation;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.ViewModels.TFBS.Maintenance
{
    public class AddMaintenanceViewModel
    {
        private readonly MaintenanceService _maintenanceService;
        private readonly VehicleService _vehicleService;
        private readonly MechanicService _mechanicService;

        public AddMaintenanceViewModel(MaintenanceService maintenanceService, VehicleService vehicleService, MechanicService mechanicService)
        {
            _maintenanceService = maintenanceService;

            _mechanicService = mechanicService;
            MechanicList = new ObservableCollection<MechanicViewModel>(_mechanicService.GetMechanics()
                .OrderBy(c => c.EmployeeLink.Emp_Lastname)
                    .Select(c => new MechanicViewModel(c)));

            _vehicleService = vehicleService;
            VehicleList = new ObservableCollection<VehicleViewModel>(
                _vehicleService.GetVehicles().OrderBy(c => c.Vehicle_Type)
                    .Select(c => new VehicleViewModel(c)));
        }

        public string Details { get; set; }
        public DateTime EntryDate { get; set; }
        public ObservableCollection<MechanicViewModel> MechanicList { get; set; }
        public ObservableCollection<VehicleViewModel> VehicleList { get; set; }
        public MechanicViewModel SelectedMechanic { get; set; }
        public VehicleViewModel SelectedVehicle { get; set; }
        public MaintenanceViewModel AssociatedMaintenance { get; set; }


        public void Add()
        {
            var maintenance = new DataLayer.EFClasses.TFBS.Maintenance()
            {
                Details = char.ToUpper(Details[0]) + Details[1..],
                Maintenance_EntryDate = EntryDate,
                MechanicId = SelectedMechanic.MechanicId,
                VehicleId = SelectedVehicle.VehicleId,
            };

            _maintenanceService.AddMaintenance(maintenance);

            AssociatedMaintenance = new MaintenanceViewModel(maintenance);
        }
    }
}
