﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;
using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;

namespace WpfTinyCollege.ViewModels.TFBS.Maintenance
{
    public class AddCompleteMaintenanceViewModel
    {
        private readonly MaintenanceService _maintenanceService;

        public AddCompleteMaintenanceViewModel(MaintenanceViewModel maintenanceToComplete, MaintenanceService maintenanceService)
        {
            MaintenanceToComplete = maintenanceToComplete;
            _maintenanceService = maintenanceService;

            MaintenanceId = maintenanceToComplete.MaintenanceId;
            EntryDate = maintenanceToComplete.MaintenanceEntryDate;
            MechanicFullName = maintenanceToComplete.MechanicFullName;
            VehicleType = maintenanceToComplete.VehicleType;
            Details = maintenanceToComplete.Details;

        }

        public MaintenanceViewModel MaintenanceToComplete { get; set; }
        public DateTime CompletedDate { get; set; }
        public MaintenanceViewModel AssociatedMaintenance { get; set; }
        public string MaintenanceId { get; set; }
        public string EntryDate { get; set; }
        public string MechanicFullName { get; set; }
        public string VehicleType { get; set; }
        public string Details { get; set; }


        public void Add()
        {
            var completeMaintenance = new DataLayer.EFClasses.TFBS.Maintenance()
            {
                Maintenance_CompletedDate = CompletedDate,
                MaintenanceId = MaintenanceToComplete.MaintenanceId,
            };

            _maintenanceService.AddCompleteMaintenance(completeMaintenance);

            var maintenances =
                new TinyCollegeContext().Maintenances.Where(c => c.MaintenanceId == completeMaintenance.MaintenanceId);
            foreach (var maintenance in maintenances)
            {
                AssociatedMaintenance = new MaintenanceViewModel(maintenance);
            }


        }
    }
}
