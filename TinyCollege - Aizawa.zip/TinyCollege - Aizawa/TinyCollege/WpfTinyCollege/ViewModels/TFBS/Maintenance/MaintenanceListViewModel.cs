﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.ViewModels.TFBS.Maintenance
{
    public class MaintenanceListViewModel
    {
        private readonly MaintenanceService _maintenanceService;
        private MaintenanceViewModel _selectedMaintenance;
        //private string _searchText;

        public MaintenanceListViewModel(MaintenanceService MaintenanceService)
        {
            _maintenanceService = MaintenanceService;

            MaintenanceList = new ObservableCollection<MaintenanceViewModel>(
                _maintenanceService.GetMaintenances()
                    .OrderBy(c=>c.MaintenanceId)
                    .Select(c => new MaintenanceViewModel(c))
            );
        }

        public ObservableCollection<MaintenanceViewModel> MaintenanceList { get; set; }
        public ObservableCollection<MaintenancePartsUsedViewModel> MaintenancePartsUsedList { get; set; } =
            new ObservableCollection<MaintenancePartsUsedViewModel>();

        public MaintenanceViewModel SelectedMaintenance
        {
            get => _selectedMaintenance;
            set
            {
                _selectedMaintenance = value;
                if (_selectedMaintenance != null)
                    DisplayMaintenancePartused(_selectedMaintenance.MaintenanceId);
            }
        }

        private void DisplayMaintenancePartused(string maintenanceId)
        {
            MaintenancePartsUsedList.Clear();

            var PartUses = new PartUsedService(new TinyCollegeContext()).GetMaintenancePartUsed(maintenanceId)
                .Select(c => new MaintenancePartsUsedViewModel(c));

            foreach (var partUsed in PartUses)
                MaintenancePartsUsedList.Add(partUsed);
        }

        //public string SearchText
        //{
        //    get => _searchText;
        //    set
        //    {
        //        _searchText = value;
        //        SearchMaintenance(_searchText);
        //    }
        //}
    }
}
