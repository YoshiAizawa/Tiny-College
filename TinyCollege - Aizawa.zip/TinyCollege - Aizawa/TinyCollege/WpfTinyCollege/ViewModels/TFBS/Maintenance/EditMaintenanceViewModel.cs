﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Employee;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.ViewModels.TFBS.Maintenance
{
    public class EditMaintenanceViewModel
    {
        private readonly MaintenanceService _maintenanceService;
        private readonly VehicleService _vehicleService;
        private readonly MechanicService _mechanicService;

        public EditMaintenanceViewModel(MaintenanceViewModel maintenanceToEdit, MaintenanceService maintenanceService,
            VehicleService vehicleService, MechanicService mechanicService)
        {
            MaintenanceToEdit = maintenanceToEdit;
            _maintenanceService = maintenanceService;
            _vehicleService = vehicleService;
            _mechanicService = mechanicService;

            MechanicList = new ObservableCollection<MechanicViewModel>(
                _mechanicService.GetMechanics().Select(c =>
                    new MechanicViewModel(c)));

            VehicleList = new ObservableCollection<VehicleViewModel>(
                _vehicleService.GetVehicles().Select(c =>
                    new VehicleViewModel(c)));

            MaintenanceId = maintenanceToEdit.MaintenanceId;
            CopyEditableFields(maintenanceToEdit);
        }

        public MaintenanceViewModel MaintenanceToEdit { get; set; }
        public MechanicViewModel SelectedMechanic { get; set; }
        public VehicleViewModel SelectedVehicle { get; set; }

        private void CopyEditableFields(MaintenanceViewModel maintenanceToEdit)
        {
            Details = maintenanceToEdit.Details;
            EntryDate = Convert.ToDateTime(maintenanceToEdit.MaintenanceEntryDate);
            VehicleType = maintenanceToEdit.VehicleType;
            MechanicFullName = maintenanceToEdit.MechanicFullName;
        }

        public string MaintenanceId { get; set; }
        public string Details { get; set; }
        public DateTime EntryDate { get; set; }
        public string VehicleType { get; set; }
        public string MechanicFullName { get; set; }
        public string VehicleId { get; set; }
        public string MechanicId { get; set; }
        public ObservableCollection<MechanicViewModel> MechanicList { get; set; }
        public ObservableCollection<VehicleViewModel> VehicleList { get; set; }

        public void Edit(bool vehicleChange, bool mechChange)
        {
            MaintenanceToEdit.Details = Details;
            MaintenanceToEdit.MaintenanceEntryDate = EntryDate.ToString("MM/dd/yyyy");
            if (vehicleChange)
            {
                MaintenanceToEdit.VehicleId = SelectedVehicle.VehicleId;
            }
            else
            {
                MaintenanceToEdit.VehicleId = VehicleId;
            }

            if (mechChange)
            {
                MaintenanceToEdit.MechanicId = SelectedMechanic.MechanicId;
            }
            else
            {
                MaintenanceToEdit.MechanicId = MechanicId;
            }

            var newMaintenance = new DataLayer.EFClasses.TFBS.Maintenance()
            {
                MaintenanceId = MaintenanceToEdit.MaintenanceId,
                Details = MaintenanceToEdit.Details,
                Maintenance_EntryDate = Convert.ToDateTime(MaintenanceToEdit.MaintenanceEntryDate),
                MechanicId = MaintenanceToEdit.MechanicId,
                VehicleId = MaintenanceToEdit.VehicleId,
            };

            _maintenanceService.UpdateMaintenance(newMaintenance);
        }
    }
}
