﻿namespace WpfTinyCollege.ViewModels
{
    public class HomeViewModel
    {
    }
}