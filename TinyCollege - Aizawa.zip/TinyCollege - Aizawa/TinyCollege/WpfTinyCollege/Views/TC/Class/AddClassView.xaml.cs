﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Class;

namespace WpfTinyCollege.Views.TC.Class
{
    /// <summary>
    /// Interaction logic for AddClassView.xaml
    /// </summary>
    public partial class AddClassView : Window
    {
        public AddClassView()
        {
            InitializeComponent();
        }

        private readonly ClassListViewModel _classListViewModel;
        private readonly ClassService _classService;
        private readonly CourseService _courseService;
        private readonly ScheduleService _scheduleService;
        private readonly RoomService _roomService;
        private readonly AddClassViewModel _classToAdd;

        public AddClassView(ClassListViewModel classListViewModel, ClassService classService) : this()
        {
            _classListViewModel = classListViewModel;
            _classService = classService;
            _courseService = new CourseService(new TinyCollegeContext());
            _scheduleService = new ScheduleService(new TinyCollegeContext());
            _roomService = new RoomService(new TinyCollegeContext());
            _classToAdd = new AddClassViewModel(_classService, _courseService, _scheduleService, _roomService);
            DataContext = _classToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _classToAdd.Add();
                _classListViewModel.ClassList.Add(_classToAdd.AssociatedClass);

                MessageBox.Show("Successfully Added Class");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Class: \n {exception}");
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
