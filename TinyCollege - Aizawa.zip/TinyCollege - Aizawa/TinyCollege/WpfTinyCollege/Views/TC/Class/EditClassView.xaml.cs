﻿#nullable enable
using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Class;

namespace WpfTinyCollege.Views.TC.Class
{
    /// <summary>
    /// Interaction logic for EditClassView.xaml
    /// </summary>
    public partial class EditClassView : Window
    {
        private readonly ClassService _classService;
        private readonly CourseService _courseService;
        private readonly ScheduleService _scheduleService;
        private readonly RoomService _roomService;
        public EditClassView()
        {
            InitializeComponent();

        }
        private EditClassViewModel _editClass;
        public string? ResearchDescription { get; set; } = null;

        public EditClassView(ClassViewModel editClass, ClassService classService) : this()
        {
            _classService = classService;
            _courseService = new CourseService(new TinyCollegeContext());
            _scheduleService = new ScheduleService(new TinyCollegeContext());
            _roomService = new RoomService(new TinyCollegeContext());

            _editClass = new EditClassViewModel(editClass, _classService, _courseService, _scheduleService, _roomService);

            DataContext = _editClass;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool changeSched;
                bool changeRoom;

                var changeProf = ChkProfessor.IsChecked == true;
                if (ChkSchedule.IsChecked == true)
                {
                    changeSched = true;
                }
                else
                {
                    changeSched = false;
                }
                if (ChkRoom.IsChecked == true)
                {
                    changeRoom = true;
                }
                else
                {
                    changeRoom = false;
                }
                var researchDescription = ResearchDescription;
                _editClass.Edit(changeProf, changeSched, changeRoom);
                MessageBox.Show("Class Successfully edited." +
                    "\n Press the Restart Class");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
