﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TC.Class;

namespace WpfTinyCollege.Views.TC.Class
{
    /// <summary>
    /// Interaction logic for ClassView.xaml
    /// </summary>
    public partial class ClassView : UserControl
    {
        private  ClassListViewModel _classListViewModel;
        private  ClassService _classService;
        public ClassView()
        {
            InitializeComponent();
            _classService = new ClassService(new TinyCollegeContext());
            _classListViewModel = new ClassListViewModel(_classService);

            DataContext = _classListViewModel;
        }

        private void BtnAddClass_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addClass = new AddClassView(_classListViewModel, _classService);
            addClass.ShowDialog();
        }

        private void BtnEditClass_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_classListViewModel.SelectedClass != null)
            {
                var editClass = new EditClassView(_classListViewModel.SelectedClass, _classService);
                editClass.ShowDialog();
            }
        }

        private void BtnRestartClass_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _classService = new ClassService(new TinyCollegeContext());
            _classListViewModel = new ClassListViewModel(_classService);

            DataContext = _classListViewModel;
        }
    }
}