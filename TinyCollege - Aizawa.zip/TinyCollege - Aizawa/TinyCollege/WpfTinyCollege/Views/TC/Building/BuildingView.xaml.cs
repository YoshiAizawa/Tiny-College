﻿using System.Windows;
using DataLayer.EFClasses.Context;
using System.Windows.Controls;
using ServiceLayer.TC;
using WpfTinyCollege.ViewModels.TC.Building;

namespace WpfTinyCollege.Views.TC.Building
{
    /// <summary>
    /// Interaction logic for BuildingView.xaml
    /// </summary>
    public partial class BuildingView : UserControl
    {
        private  BuildingListViewModel _buildingListViewModel;
        private  BuildingService _buildingService;


        public BuildingView()
        {
            InitializeComponent();
            _buildingService = new BuildingService(new TinyCollegeContext());
            _buildingListViewModel = new BuildingListViewModel(_buildingService);

            DataContext = _buildingListViewModel;
            //EditBuildingViewInterface.Visibility = Visibility.Collapsed;
        }



        private void BtnEditBuilding_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_buildingListViewModel.SelectedBuilding != null)
            {
                var editBuilding = new EditBuildingView(_buildingListViewModel.SelectedBuilding, _buildingService);
                editBuilding.ShowDialog();
            }
        }

        private void BtnAddBuilding_Click(object sender, RoutedEventArgs e)
        {
            var addBuilding = new AddBuildingView(_buildingListViewModel, _buildingService);
            addBuilding.ShowDialog();
        }

        private void BtnRestartBuilding_Click(object sender, RoutedEventArgs e)
        {
            _buildingService = new BuildingService(new TinyCollegeContext());
            _buildingListViewModel = new BuildingListViewModel(_buildingService);

            DataContext = _buildingListViewModel;
        }
    }
}