﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ServiceLayer;
using ServiceLayer.TC;
using WpfTinyCollege.ViewModels.TC.Building;

namespace WpfTinyCollege.Views.TC.Building
{
    /// <summary>
    /// Interaction logic for AddBuildingView.xaml
    /// </summary>
    public partial class AddBuildingView : Window
    {
        private readonly BuildingListViewModel _buildingListViewModel;
        private readonly BuildingService _buildingService;
        public AddBuildingView()
        {
            InitializeComponent();
        }

        private readonly AddBuildingViewModel _buildingToAdd;

        public AddBuildingView(BuildingListViewModel buildingListViewModel, BuildingService buildingService) : this()
        {
            _buildingListViewModel = buildingListViewModel;
            _buildingService = buildingService;
            _buildingToAdd = new AddBuildingViewModel(buildingService);
            DataContext = _buildingToAdd;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _buildingToAdd.Add();
                _buildingListViewModel.BuildingList.Add(_buildingToAdd.AssociatedBuilding);
                MessageBox.Show("Successfully Added Building");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Building: \n {exception}");
                throw;
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
