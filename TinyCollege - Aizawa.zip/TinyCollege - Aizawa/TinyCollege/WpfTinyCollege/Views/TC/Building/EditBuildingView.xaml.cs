﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ServiceLayer;
using ServiceLayer.TC;
using WpfTinyCollege.ViewModels.TC.Building;
using MessageBox = System.Windows.MessageBox;

namespace WpfTinyCollege.Views.TC.Building
{
    /// <summary>
    /// Interaction logic for EditBuildingView.xaml
    /// </summary>
    public partial class EditBuildingView : Window
    {
        public EditBuildingView()
        {
            InitializeComponent();
        }

        private readonly EditBuildingViewModel _editBuilding;

        public EditBuildingView(BuildingViewModel editBuilding, BuildingService buildingService) : this()
        {
            _editBuilding = new EditBuildingViewModel(editBuilding,buildingService);
            DataContext = _editBuilding;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _editBuilding.Edit();
                MessageBox.Show("Building Successfully edited.");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}
