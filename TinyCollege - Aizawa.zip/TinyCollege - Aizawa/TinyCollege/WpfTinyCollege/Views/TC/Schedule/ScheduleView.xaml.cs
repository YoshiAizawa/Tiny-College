﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TC.Schedule;

namespace WpfTinyCollege.Views.TC.Schedule
{
    /// <summary>
    /// Interaction logic for ScheduleView.xaml
    /// </summary>
    public partial class ScheduleView : UserControl
    {
        private readonly ScheduleListViewModel _scheduleListViewModel;
        private readonly ScheduleService _scheduleService;
        public ScheduleView()
        {
            InitializeComponent();
            _scheduleService = new ScheduleService(new TinyCollegeContext());
            _scheduleListViewModel = new ScheduleListViewModel(_scheduleService);

            DataContext = _scheduleListViewModel;
        }

        private void BtnAddSchedule_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addSchedule = new AddScheduleView(_scheduleListViewModel, _scheduleService);
            addSchedule.ShowDialog();
        }

        private void BtnEditSchedule_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_scheduleListViewModel.SelectedSchedule != null)
            {
                var editSchedule = new EditScheduleView(_scheduleListViewModel.SelectedSchedule, _scheduleService);
                editSchedule.ShowDialog();
            }
        }
    }
}