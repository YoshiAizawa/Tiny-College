﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Schedule;

namespace WpfTinyCollege.Views.TC.Schedule
{
    /// <summary>
    /// Interaction logic for AddScheduleView.xaml
    /// </summary>
    public partial class AddScheduleView : Window
    {
        private readonly ScheduleListViewModel _scheduleListViewModel;
        private readonly ScheduleService _scheduleService;

        public AddScheduleView()
        {
            InitializeComponent();
        }

        private readonly AddScheduleViewModel _scheduleToAdd;

        public AddScheduleView(ScheduleListViewModel scheduleListViewModel, ScheduleService scheduleService) : this()
        {
            _scheduleListViewModel = scheduleListViewModel;
            _scheduleService = scheduleService;
            _scheduleToAdd = new AddScheduleViewModel(scheduleService);
            DataContext = _scheduleToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            DateTime defaultTime = default(DateTime);
            if (DateTime.TryParse(TxtStart.Text, out defaultTime) && DateTime.TryParse(TxtEnd.Text, out defaultTime))
            {
                try
                {

                    _scheduleToAdd.Add();
                    _scheduleListViewModel.ScheduleList.Add(_scheduleToAdd.AssociatedSchedule);
                    MessageBox.Show("Successfully Added Schedule");
                    this.Close();
                }
                catch (Exception exception)
                {
                    MessageBox.Show($"Error Adding Schedule: \n\n {exception}");
                    throw;
                }
            }
            else
            {
                MessageBox.Show("The time is not set properly", "Wrong Time Set", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }

        }
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
