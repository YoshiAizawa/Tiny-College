﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Schedule;

namespace WpfTinyCollege.Views.TC.Schedule
{
    /// <summary>
    /// Interaction logic for EditScheduleView.xaml
    /// </summary>
    public partial class EditScheduleView : Window
    {
        public EditScheduleView()
        {
            InitializeComponent();
        }

        private readonly EditScheduleViewModel _editSchedule;

        public EditScheduleView(ScheduleViewModel editSchedule, ScheduleService scheduleService) : this()
        {
            _editSchedule = new EditScheduleViewModel(editSchedule, scheduleService);
            DataContext = _editSchedule;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            DateTime defaultTime = default(DateTime);
            if (DateTime.TryParse(TxtStart.Text, out defaultTime) && DateTime.TryParse(TxtEnd.Text, out defaultTime))
            {
                try
                {
                    _editSchedule.Edit();
                    MessageBox.Show("Schedule Successfully edited.");
                    this.Close();
                }
                catch (Exception exception)
                {
                    MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                }
            }
            else
            {
                MessageBox.Show("The time is not set properly", "Wrong Time Set", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
