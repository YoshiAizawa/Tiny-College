﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.School;

namespace WpfTinyCollege.Views.TC.School
{
    /// <summary>
    /// Interaction logic for AddSchoolView.xaml
    /// </summary>
    public partial class AddSchoolView : Window
    {
        private readonly SchoolListViewModel _schoolListViewModel;
        private readonly SchoolService _schoolService;
        public AddSchoolView()
        {
            InitializeComponent();
        }

        private readonly AddSchoolViewModel _schoolToAdd;

        public AddSchoolView(SchoolListViewModel SchoolListViewModel, SchoolService SchoolService) : this()
        {
            _schoolListViewModel = SchoolListViewModel;
            _schoolService = SchoolService;
            _schoolToAdd = new AddSchoolViewModel(SchoolService);
            DataContext = _schoolToAdd;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _schoolToAdd.Add();
                _schoolListViewModel.SchoolList.Add(_schoolToAdd.AssociatedSchool);
                MessageBox.Show("Successfully Added School");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding School: \n {exception}");
                throw;
            }

        }
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

