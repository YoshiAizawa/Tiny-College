﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.School;

namespace WpfTinyCollege.Views.TC.School
{
    /// <summary>
    /// Interaction logic for EditSchoolView.xaml
    /// </summary>
    public partial class EditSchoolView : Window
    {
        public EditSchoolView()
        {
            InitializeComponent();
        }

        private readonly EditSchoolViewModel _editSchool;

        public EditSchoolView(SchoolViewModel editSchool, SchoolService schoolService) : this()
        {
            _editSchool = new EditSchoolViewModel(editSchool, schoolService);
            DataContext = _editSchool;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _editSchool.Edit();
                MessageBox.Show("School Successfully edited.");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
