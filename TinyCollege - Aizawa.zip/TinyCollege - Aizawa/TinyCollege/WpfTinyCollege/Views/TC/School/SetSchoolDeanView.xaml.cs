﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.School;

namespace WpfTinyCollege.Views.TC.School
{
    /// <summary>
    /// Interaction logic for SetSchoolDeanView.xaml
    /// </summary>
    public partial class SetSchoolDeanView : Window
    {
        public SetSchoolDeanView()
        {
            InitializeComponent();
        }
        private readonly SetSchoolDeanViewModel _setDean;
        private readonly RemoveSchoolDeanViewModel _removeDean;
        private readonly DeanService _deanService;

        public SetSchoolDeanView(SchoolViewModel editSchool, SchoolService schoolService) : this()
        {
            _deanService = new DeanService(new DataLayer.EFClasses.Context.TinyCollegeContext());
            _setDean = new SetSchoolDeanViewModel(editSchool);
            _removeDean = new RemoveSchoolDeanViewModel(editSchool);
            DataContext = _setDean;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _setDean.Set();
                MessageBox.Show("Successful to Set the Dean");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n\n\n {exception}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _removeDean.Remove();
                MessageBox.Show("Successful to remove the Dean");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n\n\n {exception}");
            }
        }
    }
}
