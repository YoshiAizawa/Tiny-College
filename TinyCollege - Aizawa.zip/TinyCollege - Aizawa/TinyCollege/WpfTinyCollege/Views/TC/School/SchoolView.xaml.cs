﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TC.School;

namespace WpfTinyCollege.Views.TC.School
{
    /// <summary>
    /// Interaction logic for SchoolView.xaml
    /// </summary>
    public partial class SchoolView : UserControl
    {
        private SchoolListViewModel _schoolListViewModel;
        private SchoolService _schoolService;


        public SchoolView()
        {
            InitializeComponent();
            _schoolService = new SchoolService(new TinyCollegeContext());
            _schoolListViewModel = new SchoolListViewModel(_schoolService);

            DataContext = _schoolListViewModel;

        }

        private void BtnAddSchool_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addSchool = new AddSchoolView(_schoolListViewModel, _schoolService);
            addSchool.ShowDialog();
        }

        private void BtnEditSchool_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_schoolListViewModel.SelectedSchool != null)
            {
                var editSchool = new EditSchoolView(_schoolListViewModel.SelectedSchool, _schoolService);
                editSchool.ShowDialog();
            }
        }

        private void BtnRestartSchool_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _schoolService = new SchoolService(new TinyCollegeContext());
            _schoolListViewModel = new SchoolListViewModel(_schoolService);

            DataContext = _schoolListViewModel;
        }

        private void BtnSetDean_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_schoolListViewModel.SelectedSchool != null)
            {
                var editDeanSchool = new SetSchoolDeanView(_schoolListViewModel.SelectedSchool, _schoolService);
                editDeanSchool.ShowDialog();
            }
        }
    }
}