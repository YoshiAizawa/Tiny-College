﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TC.Student;

namespace WpfTinyCollege.Views.TC.Student
{
    /// <summary>
    /// Interaction logic for StudentView.xaml
    /// </summary>
    public partial class StudentView : UserControl
    {
        private  StudentListViewModel _studentListViewModel;
        private  StudentService _studentService;
        public StudentView()
        {
            InitializeComponent();
            _studentService = new StudentService(new TinyCollegeContext());
            _studentListViewModel = new StudentListViewModel(_studentService);

            DataContext = _studentListViewModel;
        }

        private void BtnAddStudent_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addStudent = new AddStudentView(_studentListViewModel, _studentService);
            addStudent.ShowDialog();
        }

        private void BtnEditStudent_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_studentListViewModel.SelectedStudent != null)
            {
                var editStudent = new EditStudentView(_studentListViewModel.SelectedStudent, _studentService);
                editStudent.ShowDialog();
            }
        }

        private void BtnRestartStudent_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _studentService = new StudentService(new TinyCollegeContext());
            _studentListViewModel = new StudentListViewModel(_studentService);

            DataContext = _studentListViewModel;
        }

        private void BtnAddClass_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_studentListViewModel.SelectedStudent != null)
            {
                var editClassesStudent = new AddStudentClassView(_studentListViewModel.SelectedStudent, _studentService);
                editClassesStudent.ShowDialog();
            }
        }
    }
}