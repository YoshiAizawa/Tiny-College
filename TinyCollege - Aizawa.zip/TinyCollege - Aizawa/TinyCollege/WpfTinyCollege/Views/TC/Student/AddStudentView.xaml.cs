﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Student;

namespace WpfTinyCollege.Views.TC.Student
{
    /// <summary>
    /// Interaction logic for AddStudentView.xaml
    /// </summary>
    public partial class AddStudentView : Window
    {
        public AddStudentView()
        {
            InitializeComponent();
        }
        private readonly StudentListViewModel _studentListViewModel;
        private readonly StudentService _studentService;
        private readonly DepartmentService _departmentService;

        private readonly AddStudentViewModel _studentToAdd;

        public AddStudentView(StudentListViewModel studentListViewModel, StudentService studentService) : this()
        {
            _studentListViewModel = studentListViewModel;
            _studentService = studentService;
            _departmentService = new DepartmentService(new TinyCollegeContext());
            _studentToAdd = new AddStudentViewModel(studentService,_departmentService);
            DataContext = _studentToAdd;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _studentToAdd.Add();
                _studentListViewModel.StudentList.Add(_studentToAdd.AssociatedStudent);
                MessageBox.Show("Successfully Added Student");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Student: \n {exception}");
            }

        }
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
