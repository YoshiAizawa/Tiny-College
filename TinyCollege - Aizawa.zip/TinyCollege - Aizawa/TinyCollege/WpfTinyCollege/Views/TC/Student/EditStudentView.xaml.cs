﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Student;

namespace WpfTinyCollege.Views.TC.Student
{
    /// <summary>
    /// Interaction logic for EditStudentView.xaml
    /// </summary>
    public partial class EditStudentView : Window
    {
        public EditStudentView()
        {
            InitializeComponent();
        }

        private EditStudentViewModel _editStudent;
        private readonly DepartmentService _departmentService;

        public EditStudentView(StudentViewModel editStudent, StudentService studentService) : this()
        {
            _departmentService = new DepartmentService(new TinyCollegeContext());

            _editStudent = new EditStudentViewModel(editStudent, studentService, _departmentService);

            DataContext = _editStudent;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool changeDept;
                bool changeAdvisor;

                if (ChkDepartment.IsChecked == true)
                {
                    changeDept = true;
                }
                else
                {
                    changeDept = false;
                }
                if (ChkAdvisor.IsChecked == true)
                {
                    changeAdvisor = true;
                }
                else
                {
                    changeAdvisor = false;
                }
                _editStudent.Edit(changeDept,changeAdvisor);
                MessageBox.Show("Student Successfully edited." +
                    "\n Press the Restart Student");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
