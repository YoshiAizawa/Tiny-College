﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Student;

namespace WpfTinyCollege.Views.TC.Student
{
    /// <summary>
    /// Interaction logic for AddStudentClassView.xaml
    /// </summary>
    public partial class AddStudentClassView : Window
    {
        public AddStudentClassView()
        {
            InitializeComponent();
        }

        private readonly AddStudentClassViewModel _addEnroll;
        private readonly EnrollService _enrollService;

        public AddStudentClassView(StudentViewModel selectedStudent, StudentService studentService) : this()
        {
            _enrollService = new EnrollService(new DataLayer.EFClasses.Context.TinyCollegeContext());
            _addEnroll = new AddStudentClassViewModel(selectedStudent);
            DataContext = _addEnroll;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (TxtSemester.Text == "1st" || TxtSemester.Text == "2nd" || TxtSemester.Text == "Summer")
            {
                try
                {
                    _addEnroll.Add();
                    MessageBox.Show("Successful to Set the Enroll");
                    this.Close();
                }
                catch (Exception exception)
                {
                    MessageBox.Show($"Fill in the empty boxes. \n\n\n {exception}");
                }
            }
            else
            {
                MessageBox.Show("You can only input 1st,2nd,Summer in Textbox of Semester");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
