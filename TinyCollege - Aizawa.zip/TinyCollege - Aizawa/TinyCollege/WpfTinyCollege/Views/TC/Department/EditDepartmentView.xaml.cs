﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Department;
using WpfTinyCollege.ViewModels.TC.School;

namespace WpfTinyCollege.Views.TC.Department
{
    /// <summary>
    /// Interaction logic for EditDepartmentView.xaml
    /// </summary>
    public partial class EditDepartmentView : Window
    {
        public EditDepartmentView()
        {
            InitializeComponent();
        }

        private EditDepartmentViewModel _editDepartment;

        public EditDepartmentView(DepartmentViewModel editDepartment, DepartmentService DepartmentService, SchoolService schoolService) : this()
        {
            _editDepartment = new EditDepartmentViewModel(editDepartment, DepartmentService, schoolService);


            var _context = new TinyCollegeContext();

            DataContext = _editDepartment;


        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool changeSchool;

                if (ChkSchool.IsChecked == true)
                {
                    changeSchool = true;
                }
                else
                {
                    changeSchool = false;
                }
                _editDepartment.Edit(changeSchool);
                MessageBox.Show("Department Successfully edited." +
                    "\n\n Press the Restart Department");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
