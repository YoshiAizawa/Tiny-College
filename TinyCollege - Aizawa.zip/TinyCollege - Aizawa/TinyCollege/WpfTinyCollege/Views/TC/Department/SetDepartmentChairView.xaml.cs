﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Department;

namespace WpfTinyCollege.Views.TC.Department
{
    /// <summary>
    /// Interaction logic for SetDepartmentChairView.xaml
    /// </summary>
    public partial class SetDepartmentChairView : Window
    {
        public SetDepartmentChairView()
        {
            InitializeComponent();
        }

        private readonly SetDepartmentChairViewModel _setChair;
        private readonly RemoveDepartmentChairViewModel _removeChair;
        private readonly ChairService _chairService;

        public SetDepartmentChairView(DepartmentViewModel editDepartment, DepartmentService departmentService) : this()
        {
            _chairService = new ChairService(new DataLayer.EFClasses.Context.TinyCollegeContext());
            _setChair = new SetDepartmentChairViewModel(editDepartment);
            _removeChair = new RemoveDepartmentChairViewModel(editDepartment);
            DataContext = _setChair;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _setChair.Set();
                MessageBox.Show("Successful to Set the Chair");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n\n\n {exception}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _removeChair.Remove();
                MessageBox.Show("Successful to remove the Chair");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n\n\n {exception}");
            }
        }
    }
}
