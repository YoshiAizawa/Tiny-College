﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Department;

namespace WpfTinyCollege.Views.TC.Department
{
    /// <summary>
    /// Interaction logic for AddDepartmentView.xaml
    /// </summary>
    public partial class AddDepartmentView : Window
    {
        private readonly DepartmentListViewModel _departmentListViewModel;
        private readonly DepartmentService _departmentService;
        private readonly SchoolService _schoolService;
        public AddDepartmentView()
        {
            InitializeComponent();
        }

        private readonly AddDepartmentViewModel _departmentToAdd;

        public AddDepartmentView(DepartmentListViewModel departmentListViewModel, DepartmentService departmentService, SchoolService schoolService) : this()
        {
            _departmentListViewModel = departmentListViewModel;
            _departmentService = departmentService;
            _schoolService = schoolService;
            _departmentToAdd = new AddDepartmentViewModel(departmentService, schoolService);
            DataContext = _departmentToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                _departmentToAdd.Add();
                _departmentListViewModel.DepartmentList.Add(_departmentToAdd.AssociatedDepartment);

                MessageBox.Show("Successfully Added Department");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Department: \n {exception}");
                throw;
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
