﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Department;

namespace WpfTinyCollege.Views.TC.Department
{
    /// <summary>
    /// Interaction logic for DepartmentView.xaml
    /// </summary>
    public partial class DepartmentView : UserControl
    {
        private  DepartmentListViewModel _departmentListViewModel;
        private  DepartmentService _departmentService;
        private readonly SchoolService _schoolService;


        public DepartmentView()
        {
            InitializeComponent();
            _departmentService = new DepartmentService(new TinyCollegeContext());
            _schoolService = new SchoolService(new TinyCollegeContext());
            _departmentListViewModel = new DepartmentListViewModel(_departmentService);

            DataContext = _departmentListViewModel;
        }

        private void BtnEditDepartment_Click(object sender, RoutedEventArgs e)
        {
            if (_departmentListViewModel.SelectedDepartment != null)
            {
                var editDepartment = new EditDepartmentView(_departmentListViewModel.SelectedDepartment, _departmentService, _schoolService);
                editDepartment.ShowDialog();
            }
        }

        private void BtnAddDepartment_Click(object sender, RoutedEventArgs e)
        {
            var addDepartment = new AddDepartmentView(_departmentListViewModel, _departmentService, _schoolService);
            addDepartment.ShowDialog();
        }

        private void BtnEditCourse_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAddCourse_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnRefreshDepartment_Click(object sender, RoutedEventArgs e)
        {
            _departmentService = new DepartmentService(new TinyCollegeContext());
            _departmentListViewModel = new DepartmentListViewModel(_departmentService);

            DataContext = _departmentListViewModel;
        }

        private void BtnSetChair_Click(object sender, RoutedEventArgs e)
        {
            if (_departmentListViewModel.SelectedDepartment != null)
            {
                var editChairDepartment = new SetDepartmentChairView(_departmentListViewModel.SelectedDepartment, _departmentService);
                editChairDepartment.ShowDialog();
            }
        }
    }
}


