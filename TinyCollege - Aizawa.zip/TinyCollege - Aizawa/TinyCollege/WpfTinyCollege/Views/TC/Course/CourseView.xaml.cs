﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TC.Course;

namespace WpfTinyCollege.Views.TC.Course
{
    /// <summary>
    /// Interaction logic for CourseView.xaml
    /// </summary>
    public partial class CourseView : UserControl
    {
        private  CourseListViewModel _courseListViewModel;
        private  CourseService _courseService;
        private readonly DepartmentService _departmentService;
        public CourseView()
        {
            InitializeComponent();
            _courseService = new CourseService(new TinyCollegeContext());
            _departmentService = new DepartmentService(new TinyCollegeContext());
            _courseListViewModel = new CourseListViewModel(_courseService);

            DataContext = _courseListViewModel;
        }

        private void BtnAddCourse_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addCourse = new AddCourseView(_courseListViewModel, _courseService, _departmentService);
            addCourse.ShowDialog();
        }

        private void BtnEditCourse_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_courseListViewModel.SelectedCourse != null)
            {
                var editDepartment = new EditCourseView(_courseListViewModel.SelectedCourse, _courseService, _departmentService);
                editDepartment.ShowDialog();
            }
        }

        private void BtnRefreshCourse_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _courseService = new CourseService(new TinyCollegeContext());
            _courseListViewModel = new CourseListViewModel(_courseService);

            DataContext = _courseListViewModel;
        }
    }
}