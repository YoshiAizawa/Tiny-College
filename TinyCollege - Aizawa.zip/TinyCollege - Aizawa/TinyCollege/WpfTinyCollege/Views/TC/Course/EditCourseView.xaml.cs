﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Course;

namespace WpfTinyCollege.Views.TC.Course
{
    /// <summary>
    /// Interaction logic for EditCourseView.xaml
    /// </summary>
    public partial class EditCourseView : Window
    {
        public EditCourseView()
        {
            InitializeComponent();
        }

        private readonly EditCourseViewModel _editCourse;

        public EditCourseView(CourseViewModel editCourse, CourseService courseService, DepartmentService departmentService) : this()
        {
            _editCourse = new EditCourseViewModel(editCourse, courseService, departmentService);


            var _context = new TinyCollegeContext();

            DataContext = _editCourse;


        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _editCourse.Edit();
                MessageBox.Show("Course Successfully edited." +
                    "\n\n Press the refresh to see the changes");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
