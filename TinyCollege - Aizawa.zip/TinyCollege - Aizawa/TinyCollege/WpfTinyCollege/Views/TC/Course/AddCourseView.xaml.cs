﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Course;

namespace WpfTinyCollege.Views.TC.Course
{
    /// <summary>
    /// Interaction logic for AddCourseView.xaml
    /// </summary>
    public partial class AddCourseView : Window
    {
        private readonly CourseListViewModel _courseListViewModel;
        private readonly CourseService _courseService;
        private readonly DepartmentService _departmentService;
        public AddCourseView()
        {
            InitializeComponent();
        }

        private readonly AddCourseViewModel _courseToAdd;

        public AddCourseView(CourseListViewModel CourseListViewModel, CourseService CourseService, DepartmentService DepartmentService) : this()
        {
            _courseListViewModel = CourseListViewModel;
            _courseService = CourseService;
            _departmentService = DepartmentService;
            _courseToAdd = new AddCourseViewModel(CourseService, DepartmentService);
            DataContext = _courseToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                _courseToAdd.Add();
                _courseListViewModel.CourseList.Add(_courseToAdd.AssociatedCourse);

                MessageBox.Show("Successfully Added Course");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Course: \n {exception}");
                throw;
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
