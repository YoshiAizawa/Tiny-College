﻿#nullable enable
using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Professor;

namespace WpfTinyCollege.Views.TC.Professor
{
    /// <summary>
    /// Interaction logic for EditProfessorView.xaml
    /// </summary>
    public partial class EditProfessorView : Window
    {
        public EditProfessorView()
        {
            InitializeComponent();
        }

        private EditProfessorViewModel _editProfessor;
        public string? ResearchDescription { get; set; } = null;

        public EditProfessorView(ProfessorViewModel editProfessor, ProfessorService professorService, DepartmentService departmentService) : this()
        {
            _editProfessor = new EditProfessorViewModel(editProfessor, professorService, departmentService);          
            

            var _context = new TinyCollegeContext();

            CmbDepartmentName.SelectedItem = editProfessor.NameOfDepartment;
            // Checking if the Professor is Advisor and/or Researcher 
            var researchers = _context.ResearchContracts.Where(c => c.ProfessorId == _editProfessor.ProfessorId);
            if (researchers.Count() != 0)
            {
                foreach (var researcher in researchers)
                {
                    if (researcher.Contract_EndedDate == null)
                    {
                        ChkResearcher.IsChecked = true;
                        TxtDescription.Text = researcher.Research_Description;
                    }
                }
            }
            DataContext = _editProfessor;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool changeDept;
                bool isAdvisor;
                bool isResearcher;

                if (ChkDepartment.IsChecked == true)
                {
                    changeDept = true;
                }
                else
                {
                    changeDept = false;
                }
                if (ChkAdvisor.IsChecked == true)
                {
                    isAdvisor = true;
                }
                else
                {
                    isAdvisor = false;
                }
                if (ChkResearcher.IsChecked == true)
                {
                    isResearcher = true;
                    ResearchDescription = TxtDescription.Text;
                }
                else
                {
                    isResearcher = false;
                }
                var researchDescription = ResearchDescription;
                _editProfessor.Edit(isAdvisor,isResearcher,researchDescription,changeDept);
                MessageBox.Show("Professor Successfully edited." +
                    "\n Press the Restart Professor");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
