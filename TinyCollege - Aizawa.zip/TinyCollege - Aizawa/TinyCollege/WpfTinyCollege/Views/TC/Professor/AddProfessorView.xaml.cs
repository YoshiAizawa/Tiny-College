﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TC.Professor;

namespace WpfTinyCollege.Views.TC.Professor
{
    /// <summary>
    /// Interaction logic for AddProfessorView.xaml
    /// </summary>
    public partial class AddProfessorView : Window
    {
        private readonly ProfessorListViewModel _professorListViewModel;
        private readonly ProfessorService _professorService;
        private readonly DepartmentService _departmentService;
        public AddProfessorView()
        {
            InitializeComponent();
        }

        private readonly AddProfessorViewModel _professorToAdd;

        public AddProfessorView(ProfessorListViewModel professorListViewModel, ProfessorService professorService, DepartmentService departmentService, ResearchService researchService) : this()
        {
            _professorListViewModel = professorListViewModel;
            _professorService = professorService;
            _departmentService = departmentService;
            _professorToAdd = new AddProfessorViewModel(professorService,departmentService);
            DataContext = _professorToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool isAdvisor = false;
                bool isResearcher = false;
                string researchDescription = null;

                if (ChkAdvisor.IsChecked == true)
                {
                    isAdvisor = true;
                }
                if (ChkResearcher.IsChecked == true)
                {
                    isResearcher = true;
                    researchDescription = TxtDescription.Text;
                }

                _professorToAdd.Add(isAdvisor,isResearcher,researchDescription);
                _professorListViewModel.ProfessorList.Add(_professorToAdd.AssociatedProfessor);
                
                MessageBox.Show("Successfully Added Professor");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Professor: \n {exception}");               
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
