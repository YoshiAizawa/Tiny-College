﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TC.Professor;

namespace WpfTinyCollege.Views.TC.Professor
{
    /// <summary>
    /// Interaction logic for ProfessorView.xaml
    /// </summary>
    public partial class ProfessorView : UserControl
    {
        private  ProfessorListViewModel _professorListViewModel;
        private  ProfessorService _professorService;
        private readonly DepartmentService _departmentService;
        private readonly ResearchService _researchService;
        public ProfessorView()
        {
            InitializeComponent();
            _professorService = new ProfessorService(new TinyCollegeContext());
            _professorListViewModel = new ProfessorListViewModel(_professorService);

            _departmentService = new DepartmentService(new TinyCollegeContext());

            DataContext = _professorListViewModel;
        }

        private void BtnAddProfessor_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addProfessor = new AddProfessorView(_professorListViewModel, _professorService, _departmentService, _researchService);
            addProfessor.ShowDialog();
        }

        private void BtnEditProfessor_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_professorListViewModel.SelectedProfessor != null)
            {
                var editProfessor = new EditProfessorView(_professorListViewModel.SelectedProfessor, _professorService, _departmentService);
                editProfessor.ShowDialog();
            }
        }

        private void BtnRestartProfessor_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _professorService = new ProfessorService(new TinyCollegeContext());
            _professorListViewModel = new ProfessorListViewModel(_professorService);

            DataContext = _professorListViewModel;
        }
    }
}