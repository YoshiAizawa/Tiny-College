﻿using ServiceLayer.TFBS;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.Views.TFBS.Vehicle
{
    /// <summary>
    /// Interaction logic for AddProfessorView.xaml
    /// </summary>
    public partial class AddVehicleView : Window
    {
        private readonly VehicleListViewModel _vehicleListViewModel;
        private readonly VehicleService _vehicleService;
        public AddVehicleView()
        {
            InitializeComponent();
        }

        private readonly AddVehicleViewModel _vehicleToAdd;

        public AddVehicleView(VehicleListViewModel vehicleListViewModel, VehicleService vehicleService) : this()
        {
            _vehicleListViewModel = vehicleListViewModel;
            _vehicleService = vehicleService;
            
            _vehicleToAdd = new AddVehicleViewModel(vehicleService);
            DataContext = _vehicleToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _vehicleToAdd.Add();
                _vehicleListViewModel.VehicleList.Add(_vehicleToAdd.AssociatedVehicle);
                
                MessageBox.Show("Successfully Added Vehicle \n Refresh the list to see the update");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Vehicle: \n {exception}");               
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
