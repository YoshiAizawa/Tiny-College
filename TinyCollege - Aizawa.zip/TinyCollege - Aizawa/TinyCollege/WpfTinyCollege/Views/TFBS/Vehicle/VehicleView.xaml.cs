﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.Views.TFBS.Vehicle
{
    /// <summary>
    /// Interaction logic for VehicleView.xaml
    /// </summary>
    public partial class VehicleView : UserControl
    {
        private VehicleListViewModel _vehicleListViewModel;
        private VehicleService _vehicleService;
        public VehicleView()
        {
            InitializeComponent();
            _vehicleService = new VehicleService(new TinyCollegeContext());
            _vehicleListViewModel = new VehicleListViewModel(_vehicleService);

            DataContext = _vehicleListViewModel;
        }

        private void BtnRestartVehicle_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _vehicleService = new VehicleService(new TinyCollegeContext());
            _vehicleListViewModel = new VehicleListViewModel(_vehicleService);

            DataContext = _vehicleListViewModel;
        }

        private void BtnAddVehicle_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addVehicle = new AddVehicleView(_vehicleListViewModel, _vehicleService);
            addVehicle.ShowDialog();
        }

        private void BtnEditVehicle_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_vehicleListViewModel.SelectedVehicle != null)
            {
                var editVehicle = new EditVehicleView(_vehicleListViewModel.SelectedVehicle, _vehicleService);
                editVehicle.ShowDialog();
            }
        }

    }
}