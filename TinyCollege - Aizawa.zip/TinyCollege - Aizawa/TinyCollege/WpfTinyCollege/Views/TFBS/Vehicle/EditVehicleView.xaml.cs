﻿#nullable enable
using DataLayer.EFClasses.Context;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.EntityFrameworkCore;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Vehicle;

namespace WpfTinyCollege.Views.TFBS.Vehicle
{
    /// <summary>
    /// Interaction logic for EditVehicleView.xaml
    /// </summary>
    public partial class EditVehicleView : Window
    {
        public EditVehicleView()
        {
            InitializeComponent();
        }

        private EditVehicleViewModel _editVehicle;

        public EditVehicleView(VehicleViewModel editVehicle, VehicleService vehicleService) : this()
        {
            _editVehicle = new EditVehicleViewModel(editVehicle, vehicleService);          
            

            var _context = new TinyCollegeContext();
            DataContext = _editVehicle;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _editVehicle.Edit();
                MessageBox.Show("Vehicle Successfully edited." +
                    "\n Please refresh the table to see the update");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        //cannot edit, it says there is a textbox not filled in
        
    }
}
