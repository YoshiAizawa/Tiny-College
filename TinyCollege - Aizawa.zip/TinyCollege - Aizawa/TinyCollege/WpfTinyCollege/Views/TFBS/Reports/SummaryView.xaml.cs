﻿using System.Windows.Controls;
using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Maintenance;

namespace WpfTinyCollege.Views.TFBS.Summary
{
    /// <summary>
    /// Interaction logic for SummaryView.xaml
    /// </summary>
    public partial class SummaryView : UserControl
    {
        private MaintenanceListViewModel _maintenanceListViewModel;
        private MaintenanceService _maintenanceService;
        public SummaryView()
        {
            InitializeComponent();

            _maintenanceService = new MaintenanceService(new TinyCollegeContext());
            _maintenanceListViewModel = new MaintenanceListViewModel(_maintenanceService);

            DataContext = _maintenanceListViewModel;
        }
    }
}