﻿using ServiceLayer.TFBS;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TFBS.Parts;

namespace WpfTinyCollege.Views.TFBS.Parts
{
    /// <summary>
    /// Interaction logic for AddPartsView.xaml
    /// </summary>
    public partial class AddPartsView : Window
    {
        private readonly PartsListViewModel _partsListViewModel;
        private readonly PartsService _partsService;
        public AddPartsView()
        {
            InitializeComponent();
        }

        private readonly AddPartsViewModel _partsToAdd;

        public AddPartsView(PartsListViewModel partsListViewModel, PartsService partsService) : this()
        {
            _partsListViewModel = partsListViewModel;
            _partsService = partsService;
            
            _partsToAdd = new AddPartsViewModel(partsService);
            DataContext = _partsToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _partsToAdd.Add();
                _partsListViewModel.PartsList.Add(_partsToAdd.AssociatedParts);
                
                MessageBox.Show("Successfully Added Vehicle \n Refresh the list to see the update");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Vehicle: \n {exception}");               
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
