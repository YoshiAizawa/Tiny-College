﻿using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TFBS.Parts;

namespace WpfTinyCollege.Views.TFBS.Parts
{
    /// <summary>
    /// Interaction logic for PartsView.xaml
    /// </summary>
    public partial class PartsView : UserControl
    {
        private PartsListViewModel _partsListViewModel;
        private PartsService _partsService;
        public PartsView()
        {
            InitializeComponent();
            _partsService = new PartsService(new TinyCollegeContext());
            _partsListViewModel = new PartsListViewModel(_partsService);

            DataContext = _partsListViewModel;
        }

        private void BtnAddPart_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addParts = new AddPartsView(_partsListViewModel, _partsService);
            addParts.ShowDialog();
        }

        private void BtnEditPart_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_partsListViewModel.SelectedPart != null)
            {
                var editProfessor = new EditPartsView(_partsListViewModel.SelectedPart, _partsService);
                editProfessor.ShowDialog();
            }
        }

        private void BtnRestartPart_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _partsService = new PartsService(new TinyCollegeContext());
            _partsListViewModel = new PartsListViewModel(_partsService);

            DataContext = _partsListViewModel;
        }
    }
}