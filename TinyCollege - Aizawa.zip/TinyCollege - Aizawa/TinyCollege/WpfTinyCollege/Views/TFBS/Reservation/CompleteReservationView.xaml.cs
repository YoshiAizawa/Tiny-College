﻿#nullable enable
using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TFBS.Reservation;

namespace WpfTinyCollege.Views.TFBS.Reservation
{
    /// <summary>
    /// Interaction logic for EditProfessorView.xaml
    /// </summary>
    public partial class CompleteReservationView : Window
    {
        public CompleteReservationView()
        {
            InitializeComponent();
        }

        private readonly AddCompleteReservationViewModel _completeReservation;
        private readonly ReservationListViewModel _reservationListViewModel;


        public CompleteReservationView(ReservationViewModel completeReservation, ReservationService reservationService, VehicleService vehicleService, ProfessorService professorService, EmployeeService employeeService) : this()
        {
            _reservationListViewModel = new ReservationListViewModel(reservationService);
            _completeReservation = new AddCompleteReservationViewModel(completeReservation, reservationService, professorService,
                vehicleService, employeeService);

            DataContext = _completeReservation;
        }

        private void BtnComplete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _completeReservation.Add();
                MessageBox.Show("Completed a reservation successfully." +
                    "\n\t Refresh to see the update");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
