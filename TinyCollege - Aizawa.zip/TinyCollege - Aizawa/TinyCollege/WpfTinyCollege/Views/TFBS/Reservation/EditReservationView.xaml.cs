﻿#nullable enable
using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TFBS.Reservation;

namespace WpfTinyCollege.Views.TFBS.Reservation
{
    /// <summary>
    /// Interaction logic for EditProfessorView.xaml
    /// </summary>
    public partial class EditReservationView : Window
    {
        public EditReservationView()
        {
            InitializeComponent();
        }

        private EditReservationViewModel _editReservation;

        public EditReservationView(ReservationViewModel editReservation, ReservationService reservationService, VehicleService vehicleService, ProfessorService professorService) : this()
        {
            _editReservation = new EditReservationViewModel(editReservation, reservationService, vehicleService, professorService);          
            

            var _context = new TinyCollegeContext();

            CmbProfessorName.SelectedItem = editReservation.ProfessorFullName;
            CmbVehicleName.SelectedItem = editReservation.VehicleType;
            // Checking if the Professor is Advisor and/or Researcher 
            
            DataContext = _editReservation;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var changeProf = false;
            var changeVehicle = false;

            if (ChkProfessor.IsChecked == true)
            {
                changeProf = true;
            }
            else
            {
                changeProf = false;
            }
            if (ChkVehicle.IsChecked == true)
            {
                changeVehicle = true;
            }
            else
            {
                changeVehicle = false;
            }

            try
            {
                _editReservation.Edit(changeVehicle, changeProf);
                MessageBox.Show("Reservation Successfully edited." +
                    "\n Refresh to see the update");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
