﻿using System.Windows;
using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System.Windows.Controls;
using ServiceLayer.TC;
using WpfTinyCollege.ViewModels.TFBS.Reservation;

namespace WpfTinyCollege.Views.TFBS.Reservation
{
    /// <summary>
    /// Interaction logic for ReservationView.xaml
    /// </summary>
    public partial class ReservationView : UserControl
    {
        private ReservationListViewModel _reservationListViewModel;
        private ReservationService _reservationService;
        private readonly VehicleService _vehicleService;
        private readonly ProfessorService _professorService;
        private readonly EmployeeService _employeeService;
        public ReservationView()
        {
            InitializeComponent();
            _reservationService = new ReservationService(new TinyCollegeContext());
            _reservationListViewModel = new ReservationListViewModel(_reservationService);

            _vehicleService = new VehicleService(new TinyCollegeContext());
            _professorService = new ProfessorService(new TinyCollegeContext());
            _employeeService = new EmployeeService(new TinyCollegeContext());

            DataContext = _reservationListViewModel;
        }

        private void BtnAddReservation_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addReservations = new AddReservationView(_reservationListViewModel, _reservationService, _professorService, _vehicleService);
            addReservations.ShowDialog();
        }

        private void BtnEditReservation_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_reservationListViewModel.SelectedReservation != null)
            {
                var editReservation = new EditReservationView(_reservationListViewModel.SelectedReservation, _reservationService, _vehicleService, _professorService);
                editReservation.ShowDialog();
            }
        }

        private void BtnRefreshReservation_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _reservationService = new ReservationService(new TinyCollegeContext());
            _reservationListViewModel = new ReservationListViewModel(_reservationService);

            DataContext = _reservationListViewModel;
        }

        private void BtnCompleteReservation_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_reservationListViewModel.SelectedReservation != null)
            {
                if (_reservationListViewModel.SelectedReservation.DateCompleted == null)
                {
                    var completeReservation = new CompleteReservationView(_reservationListViewModel.SelectedReservation,
                        _reservationService, _vehicleService, _professorService, _employeeService);
                    completeReservation.ShowDialog();
                }
                else
                {
                    MessageBox.Show("The reservation is already complete");
                }
            }
        }

        private void BtnAddReceipt_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_reservationListViewModel.SelectedReservation != null)
            {
                var receipt = new AddReceiptView(_reservationListViewModel.SelectedReservation, _reservationService);
                receipt.ShowDialog();
            }
        }

        private void BtnEditReceipt_Click(object sender, System.Windows.RoutedEventArgs e)
        {

        }
    }
}