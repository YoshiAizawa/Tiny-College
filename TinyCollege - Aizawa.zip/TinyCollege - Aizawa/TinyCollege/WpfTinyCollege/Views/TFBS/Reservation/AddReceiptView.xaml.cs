﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Reservation;

namespace WpfTinyCollege.Views.TFBS.Reservation
{
    /// <summary>
    /// Interaction logic for AddReceiptView.xaml
    /// </summary>
    public partial class AddReceiptView : Window
    {
        public AddReceiptView()
        {
            InitializeComponent();
        }

        private readonly AddReceiptViewModel _addReceipt;
        private readonly ReceiptService _receiptService;

        public AddReceiptView(ReservationViewModel selectedReservation, ReservationService reservationService) : this()
        {
            _receiptService = new ReceiptService(new DataLayer.EFClasses.Context.TinyCollegeContext());


            _addReceipt = new AddReceiptViewModel(selectedReservation, reservationService);
            DataContext = _addReceipt;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _addReceipt.Add();
                MessageBox.Show("Receipt added successfully");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n\n\n {exception}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
