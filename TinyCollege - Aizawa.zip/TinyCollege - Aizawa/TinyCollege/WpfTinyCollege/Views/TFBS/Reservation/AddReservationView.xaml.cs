﻿using ServiceLayer.TFBS;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TFBS.Reservation;

namespace WpfTinyCollege.Views.TFBS.Reservation
{
    /// <summary>
    /// Interaction logic for AddProfessorView.xaml
    /// </summary>
    public partial class AddReservationView : Window
    {
        private readonly ReservationListViewModel _reservationListViewModel;
        private readonly ReservationService _reservationService;
        private readonly ProfessorService _professorService;
        private readonly VehicleService _vehicleService;

        public AddReservationView()
        {
            InitializeComponent();

            DpDeparture.SelectedDate = DateTime.Today;
        }

        private readonly AddReservationViewModel _reservationToAdd;

        public AddReservationView(ReservationListViewModel reservationListViewModel, ReservationService reservationService, ProfessorService professorService, VehicleService vehicleService) : this()
        {
            _reservationListViewModel = reservationListViewModel;
            _reservationService = reservationService;
            _professorService = professorService;
            _vehicleService = vehicleService;
            _reservationToAdd = new AddReservationViewModel(reservationService, vehicleService, professorService);
            DataContext = _reservationToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _reservationToAdd.Add();
                _reservationListViewModel.ReservationList.Add(_reservationToAdd.AssociatedReservation);

                MessageBox.Show("Successfully Added Reservation");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Reservation: \n {exception}");               
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
