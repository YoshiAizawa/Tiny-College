﻿#nullable enable
using DataLayer.EFClasses.Context;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.EntityFrameworkCore;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Employee;

namespace WpfTinyCollege.Views.TFBS.Employee
{
    /// <summary>
    /// Interaction logic for EditProfessorView.xaml
    /// </summary>
    public partial class EditEmployeeView : Window
    {
        public EditEmployeeView()
        {
            InitializeComponent();
        }

        private EditEmployeeViewModel _editEmployee;
        public string? ResearchDescription { get; set; } = null;

        public EditEmployeeView(EmployeeViewModel editEmployee, EmployeeService employeeService) : this()
        {
            _editEmployee = new EditEmployeeViewModel(editEmployee, employeeService);          
            

            var _context = new TinyCollegeContext();

            //checks the current role of the employee
            var mechanics = _context.Mechanics.Where(c => c.EmployeeId == _editEmployee.EmployeeId);
            if (mechanics.Count() != 0)
            {
                foreach (var mechanic in mechanics)
                {
                    if (mechanic.Mec_EndedDate == null)
                    {
                        ChkMechanic.IsChecked = true;
                    }
                }
            }

            var partsManagers = _context.PartsManagers.Where(c => c.EmployeeId == _editEmployee.EmployeeId);
            if (partsManagers.Count() != 0)
            {
                foreach (var partsManager in partsManagers)
                {
                    if (partsManager.PartMgr_EndedDate == null)
                    {
                        ChkPartsManager.IsChecked = true;
                    }
                }
            }

            DataContext = _editEmployee;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var isMechanic = false;
                var isPartsManager = false;

                if (ChkMechanic.IsChecked == true) isMechanic = true;
                if (ChkPartsManager.IsChecked == true) isPartsManager = true;

                _editEmployee.Edit(isMechanic,isPartsManager);
                MessageBox.Show("Employee Successfully edited." +
                    "\n Please refresh the table to see the update");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}
