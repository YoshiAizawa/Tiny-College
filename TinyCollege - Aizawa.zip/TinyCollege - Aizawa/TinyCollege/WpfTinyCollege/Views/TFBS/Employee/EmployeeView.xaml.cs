﻿using System.Windows;
using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TFBS.Employee;

namespace WpfTinyCollege.Views.TFBS.Employee
{
    /// <summary>
    /// Interaction logic for EmployeeView.xaml
    /// </summary>
    public partial class EmployeeView : UserControl
    {
        private EmployeeListViewModel _employeeListViewModel;
        private EmployeeService _employeeService;
        public EmployeeView()
        {
            InitializeComponent();
            _employeeService = new EmployeeService(new TinyCollegeContext());
            _employeeListViewModel = new EmployeeListViewModel(_employeeService);

            DataContext = _employeeListViewModel;
        }

        private void BtnRestartEmployee_Click(object sender, RoutedEventArgs e)
        {
            _employeeService = new EmployeeService(new TinyCollegeContext());
            _employeeListViewModel = new EmployeeListViewModel(_employeeService);

            DataContext = _employeeListViewModel;
        }

        private void BtnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            var addEmployee = new AddEmployeeView(_employeeListViewModel, _employeeService);
            addEmployee.ShowDialog();
        }

        private void BtnEditEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (_employeeListViewModel.SelectedEmployee != null)
            {
                var editProfessor = new EditEmployeeView(_employeeListViewModel.SelectedEmployee, _employeeService);
                editProfessor.ShowDialog();
            }
        }
    }
}