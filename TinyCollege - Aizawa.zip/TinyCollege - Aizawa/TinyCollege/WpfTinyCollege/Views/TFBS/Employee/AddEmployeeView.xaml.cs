﻿using ServiceLayer.TFBS;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TFBS.Employee;

namespace WpfTinyCollege.Views.TFBS.Employee
{
    /// <summary>
    /// Interaction logic for AddProfessorView.xaml
    /// </summary>
    public partial class AddEmployeeView : Window
    {
        private readonly EmployeeListViewModel _employeeListViewModel;
        private readonly EmployeeService _employeeService;
        public AddEmployeeView()
        {
            InitializeComponent();
        }

        private readonly AddEmployeeViewModel _employeeToAdd;

        public AddEmployeeView(EmployeeListViewModel employeeListViewModel, EmployeeService employeeService) : this()
        {
            _employeeListViewModel = employeeListViewModel;
            _employeeService = employeeService;
            
            _employeeToAdd = new AddEmployeeViewModel(employeeService);
            DataContext = _employeeToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var isMechanic = false;
                var isPartsManager = false;

                if (ChkMechanic.IsChecked == true)
                {
                    isMechanic = true;
                }
                if (ChkPartsManager.IsChecked == true)
                {
                    isPartsManager = true;
                }
                _employeeToAdd.Add(isMechanic,isPartsManager);
                _employeeListViewModel.EmployeeList.Add(_employeeToAdd.AssociatedEmployee);
                
                MessageBox.Show("Successfully Added Professor");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Professor: \n {exception}");               
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
