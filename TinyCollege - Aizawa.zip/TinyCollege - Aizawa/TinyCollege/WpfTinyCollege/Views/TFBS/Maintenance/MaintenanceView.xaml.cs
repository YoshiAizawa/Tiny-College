﻿using System.Windows;
using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using System.Windows.Controls;
using WpfTinyCollege.ViewModels.TFBS.Maintenance;

namespace WpfTinyCollege.Views.TFBS.Maintenance
{
    /// <summary>
    /// Interaction logic for MaintenanceView.xaml
    /// </summary>
    public partial class MaintenanceView : UserControl
    {
        private MaintenanceListViewModel _maintenanceListViewModel;
        private MaintenanceService _maintenanceService;
        private readonly VehicleService _vehicleService;
        private readonly MechanicService _mechanicService;
        private readonly PartManagerService _partsManagerService;
        private readonly PartsService _partsService;

        public MaintenanceView()
        {
            InitializeComponent();
            _maintenanceService = new MaintenanceService(new TinyCollegeContext());
            _maintenanceListViewModel = new MaintenanceListViewModel(_maintenanceService);

            _vehicleService = new VehicleService(new TinyCollegeContext());
            _mechanicService = new MechanicService(new TinyCollegeContext());
            _partsManagerService = new PartManagerService(new TinyCollegeContext());
            _partsService = new PartsService(new TinyCollegeContext());

            DataContext = _maintenanceListViewModel;
        }

        private void BtnCompleteMaintenance_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_maintenanceListViewModel.SelectedMaintenance != null)
            {
                if (_maintenanceListViewModel.SelectedMaintenance.MaintenanceCompletedDate == null)
                {
                    var completeReservation = new CompleteMaintenanceView(_maintenanceListViewModel.SelectedMaintenance,
                        _maintenanceService, _vehicleService, _mechanicService);
                    completeReservation.ShowDialog();
                }
                else
                {
                    MessageBox.Show("The maintenance is already complete.");
                }
            }
        }

        private void BtnAddMaintenance_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            var addMaintenance = new AddMaintenanceView(_maintenanceListViewModel, _maintenanceService, _mechanicService, _vehicleService);
            addMaintenance.ShowDialog();
        }

        private void BtnEditMaintenance_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_maintenanceListViewModel.SelectedMaintenance != null)
            {
                var editMaintenance = new EditMaintenanceView(_maintenanceListViewModel.SelectedMaintenance, _maintenanceService, _vehicleService, _mechanicService);
                editMaintenance.ShowDialog();
            }
        }

        private void BtnRefreshMaintenance_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            _maintenanceService = new MaintenanceService(new TinyCollegeContext());
            _maintenanceListViewModel = new MaintenanceListViewModel(_maintenanceService);

            DataContext = _maintenanceListViewModel;
        }

        private void BtnAddParts_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (_maintenanceListViewModel.SelectedMaintenance != null)
            {
                var addPartsUsedView = new AddPartsUsedView(_maintenanceListViewModel.SelectedMaintenance, _maintenanceService, _partsService, _partsManagerService);
                addPartsUsedView.ShowDialog();
            }
        }
    }
}