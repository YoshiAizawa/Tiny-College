﻿#nullable enable
using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TFBS.Maintenance;

namespace WpfTinyCollege.Views.TFBS.Maintenance
{
    /// <summary>
    /// Interaction logic for EditProfessorView.xaml
    /// </summary>
    public partial class CompleteMaintenanceView : Window
    {
        public CompleteMaintenanceView()
        {
            InitializeComponent();
        }

        private readonly AddCompleteMaintenanceViewModel _completeMaintenance;
        private readonly MaintenanceListViewModel _maintenanceListViewModel;


        public CompleteMaintenanceView(MaintenanceViewModel completeMaintenance, MaintenanceService maintenanceService, VehicleService vehicleService, MechanicService mechanicService) : this()
        {
            _maintenanceListViewModel = new MaintenanceListViewModel(maintenanceService);
            _completeMaintenance = new AddCompleteMaintenanceViewModel(completeMaintenance, maintenanceService);

            DataContext = _completeMaintenance;
        }

        private void BtnComplete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _completeMaintenance.Add();
                MessageBox.Show("Completed a maintenance successfully." +
                    "\n\t Refresh to see the update");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
