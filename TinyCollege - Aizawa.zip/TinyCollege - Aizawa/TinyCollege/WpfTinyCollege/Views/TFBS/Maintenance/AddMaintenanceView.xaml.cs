﻿using ServiceLayer.TFBS;
using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfTinyCollege.ViewModels.TFBS.Maintenance;

namespace WpfTinyCollege.Views.TFBS.Maintenance
{
    /// <summary>
    /// Interaction logic for AddProfessorView.xaml
    /// </summary>
    public partial class AddMaintenanceView : Window
    {
        private readonly MaintenanceListViewModel _maintenanceListViewModel;
        private readonly VehicleService _vehicleService;
        private readonly MechanicService _mechanicService;

        public AddMaintenanceView()
        {
            InitializeComponent();

            DpDeparture.SelectedDate = DateTime.Today;
        }

        private readonly AddMaintenanceViewModel _maintenanceToAdd;

        public AddMaintenanceView(MaintenanceListViewModel maintenanceListViewModel, MaintenanceService maintenanceService, MechanicService mechanicService, VehicleService vehicleService) : this()
        {
            _maintenanceListViewModel = maintenanceListViewModel;
            _vehicleService = vehicleService;
            _mechanicService = mechanicService;

            _maintenanceToAdd = new AddMaintenanceViewModel(maintenanceService, vehicleService, mechanicService);
            DataContext = _maintenanceToAdd;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _maintenanceToAdd.Add();
                _maintenanceListViewModel.MaintenanceList.Add(_maintenanceToAdd.AssociatedMaintenance);

                MessageBox.Show("Successfully Added Maintenance");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Error Adding Maintenance: \n {exception}");               
            }

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
