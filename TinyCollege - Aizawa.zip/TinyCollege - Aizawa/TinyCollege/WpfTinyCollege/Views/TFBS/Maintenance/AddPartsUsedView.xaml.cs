﻿using ServiceLayer.TC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataLayer.EFClasses.Context;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TFBS.Maintenance;

namespace WpfTinyCollege.Views.TFBS.Maintenance
{
    /// <summary>
    /// Interaction logic for AddReceiptView.xaml
    /// </summary>
    public partial class AddPartsUsedView : Window
    {
        public AddPartsUsedView()
        {
            InitializeComponent();
        }

        private readonly AddPartsUsedViewModel _addPartsUsed;
        private readonly PartUsedService _partsUsedService;

        public AddPartsUsedView(MaintenanceViewModel selectedMaintenance, MaintenanceService maintenanceService, PartsService partsService, PartManagerService partManagerService) : this()
        {
            _partsUsedService = new PartUsedService(new DataLayer.EFClasses.Context.TinyCollegeContext());

            _addPartsUsed = new AddPartsUsedViewModel(selectedMaintenance, maintenanceService, _partsUsedService, partsService, partManagerService);

            DataContext = _addPartsUsed;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _addPartsUsed.Add();
                MessageBox.Show("Part used for maintenance added successfully");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n\n\n {exception}");
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
