﻿#nullable enable
using DataLayer.EFClasses.Context;
using ServiceLayer.TC;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ServiceLayer.TFBS;
using WpfTinyCollege.ViewModels.TC.Professor;
using WpfTinyCollege.ViewModels.TFBS.Maintenance;

namespace WpfTinyCollege.Views.TFBS.Maintenance
{
    /// <summary>
    /// Interaction logic for EditProfessorView.xaml
    /// </summary>
    public partial class EditMaintenanceView : Window
    {
        public EditMaintenanceView()
        {
            InitializeComponent();
        }

        private EditMaintenanceViewModel _editMaintenance;

        public EditMaintenanceView(MaintenanceViewModel editMechanic, MaintenanceService reservationService, VehicleService vehicleService, MechanicService mechanicService) : this()
        {
            _editMaintenance = new EditMaintenanceViewModel(editMechanic, reservationService, vehicleService, mechanicService);          
            

            var _context = new TinyCollegeContext();

            CmbMechanicName.SelectedItem = editMechanic.MechanicFullName;
            CmbVehicleName.SelectedItem = editMechanic.VehicleIdType;
            // Checking if the Professor is Advisor and/or Researcher 
            
            DataContext = _editMaintenance;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var changeMech = false;
            var changeVehicle = false;

            if (ChkMechanic.IsChecked == true)
            {
                changeMech = true;
            }
            else
            {
                changeMech = false;
            }
            if (ChkVehicle.IsChecked == true)
            {
                changeVehicle = true;
            }
            else
            {
                changeVehicle = false;
            }

            try
            {
                _editMaintenance.Edit(changeVehicle, changeMech);
                MessageBox.Show("Maintenance Successfully edited." +
                    "\n\t Refresh to see the update");
                this.Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show($"Fill in the empty boxes. \n {exception}");
                throw;
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
